-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2017 at 02:11 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `benvin_old`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_admin_history`
--

CREATE TABLE `wp_shc_admin_history` (
  `id` bigint(20) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `update_in` int(11) NOT NULL,
  `detail` text NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_admin_history`
--

INSERT INTO `wp_shc_admin_history` (`id`, `updated_by`, `update_in`, `detail`, `updated_at`, `active`) VALUES
(1, 1, 1, 'customer_create', '2017-09-14 10:38:55', 1),
(2, 1, 1, 'site_create', '2017-09-14 10:45:46', 1),
(3, 1, 1, 'master_create', '2017-09-14 10:47:15', 1),
(4, 1, 1, 'quotation_create', '2017-09-14 10:55:03', 1),
(5, 1, 1, 'quotation_update', '2017-09-14 10:55:30', 1),
(6, 1, 1, 'deposit_create', '2017-09-14 12:02:17', 1),
(7, 1, 1, 'obc_create', '2017-09-14 12:07:55', 1),
(8, 1, 10, 'lot_update', '2017-09-14 12:13:07', 1),
(9, 1, 11, 'lot_update', '2017-09-14 12:13:52', 1),
(10, 1, 11, 'lot_update', '2017-09-14 12:22:33', 1),
(11, 1, 10, 'lot_update', '2017-09-14 12:22:38', 1),
(12, 1, 3, 'lot_update', '2017-09-14 12:24:46', 1),
(13, 1, 15, 'lot_update', '2017-09-14 12:26:11', 1),
(14, 1, 6, 'lot_update', '2017-09-14 12:26:41', 1),
(15, 1, 7, 'lot_update', '2017-09-14 12:27:15', 1),
(16, 1, 1, 'delivery_create', '2017-09-14 12:27:38', 1),
(17, 1, 2, 'delivery_create', '2017-09-14 12:29:25', 1),
(18, 1, 9, 'lot_update', '2017-09-14 12:30:42', 1),
(19, 1, 2, 'lot_update', '2017-09-14 12:30:51', 1),
(20, 1, 3, 'delivery_create', '2017-09-14 12:32:27', 1),
(21, 1, 1, 'return_create', '2017-09-14 12:35:43', 1),
(22, 1, 1, 'hiring_create', '2017-09-14 12:39:15', 1),
(23, 1, 2, 'hiring_create', '2017-09-14 12:42:09', 1),
(24, 1, 3, 'hiring_create', '2017-09-14 12:42:51', 1),
(25, 1, 4, 'hiring_create', '2017-09-14 12:43:21', 1),
(26, 1, 5, 'hiring_create', '2017-09-14 12:45:20', 1),
(27, 1, 2, 'obc_create', '2017-09-14 12:54:04', 1),
(28, 1, 3, 'obc_create', '2017-09-14 12:54:45', 1),
(29, 1, 2, 'deposit_create', '2017-09-14 13:00:29', 1),
(30, 1, 3, 'deposit_create', '2017-09-14 13:07:09', 1),
(31, 1, 2, 'customer_create', '2017-09-14 14:08:54', 1),
(32, 1, 2, 'site_create', '2017-09-14 14:22:36', 1),
(33, 1, 3, 'customer_create', '2017-09-14 14:41:03', 1),
(34, 1, 3, 'site_create', '2017-09-14 14:42:29', 1),
(35, 1, 3, 'site_update', '2017-09-14 14:43:47', 1),
(36, 1, 0, 'special_price_create', '2017-09-14 14:43:47', 1),
(37, 1, 2, 'master_create', '2017-09-14 14:43:59', 1),
(38, 1, 4, 'deposit_create', '2017-09-14 14:47:51', 1),
(39, 1, 5, 'deposit_create', '2017-09-14 14:49:04', 1),
(40, 1, 5, 'deposit_update', '2017-09-14 14:49:33', 1),
(41, 1, 4, 'deposit_update', '2017-09-14 14:49:54', 1),
(42, 1, 5, 'deposit_update', '2017-09-14 14:50:51', 1),
(43, 1, 6, 'deposit_create', '2017-09-14 14:52:00', 1),
(44, 1, 7, 'deposit_create', '2017-09-14 14:55:14', 1),
(45, 1, 8, 'deposit_create', '2017-09-14 14:56:55', 1),
(46, 1, 9, 'deposit_create', '2017-09-14 14:57:45', 1),
(47, 1, 10, 'deposit_create', '2017-09-14 14:58:42', 1),
(48, 1, 11, 'deposit_create', '2017-09-14 15:01:56', 1),
(49, 1, 0, 'lot_create', '2017-09-14 15:07:43', 1),
(50, 1, 0, 'lot_create', '2017-09-14 15:24:29', 1),
(51, 1, 40, 'lot_create', '2017-09-14 15:32:47', 1),
(52, 1, 41, 'lot_create', '2017-09-14 15:33:52', 1),
(53, 1, 3, 'site_update', '2017-09-14 15:43:10', 1),
(54, 1, 0, 'special_price_create', '2017-09-14 15:43:10', 1),
(55, 1, 3, 'site_update', '2017-09-14 15:49:06', 1),
(56, 1, 1, 'special_price_create', '2017-09-14 15:49:06', 1),
(57, 1, 3, 'site_update', '2017-09-14 15:49:10', 1),
(58, 1, 3, 'site_update', '2017-09-14 15:51:16', 1),
(59, 1, 3, 'site_update', '2017-09-14 15:51:59', 1),
(60, 1, 3, 'site_update', '2017-09-14 15:54:14', 1),
(61, 1, 39, 'lot_update', '2017-09-14 16:01:00', 1),
(62, 1, 3, 'site_update', '2017-09-14 16:01:54', 1),
(63, 1, 2, 'special_price_create', '2017-09-14 16:01:54', 1),
(64, 1, 3, 'site_update', '2017-09-14 16:03:00', 1),
(65, 1, 3, 'special_price_create', '2017-09-14 16:03:00', 1),
(66, 1, 3, 'site_update', '2017-09-14 16:03:30', 1),
(67, 1, 12, 'deposit_create', '2017-09-14 16:04:43', 1),
(68, 1, 12, 'deposit_update', '2017-09-14 16:04:57', 1),
(69, 1, 13, 'deposit_create', '2017-09-14 16:06:01', 1),
(70, 1, 4, 'delivery_create', '2017-09-14 16:07:52', 1),
(71, 1, 5, 'delivery_create', '2017-09-14 16:08:46', 1),
(72, 1, 6, 'delivery_create', '2017-09-14 16:10:14', 1),
(73, 1, 7, 'delivery_create', '2017-09-14 16:11:23', 1),
(74, 1, 8, 'delivery_create', '2017-09-14 16:23:58', 1),
(75, 1, 9, 'delivery_create', '2017-09-14 16:26:47', 1),
(76, 1, 10, 'delivery_create', '2017-09-14 16:27:13', 1),
(77, 1, 11, 'delivery_create', '2017-09-14 16:42:53', 1),
(78, 1, 12, 'delivery_create', '2017-09-14 16:44:01', 1),
(79, 1, 13, 'delivery_create', '2017-09-14 16:44:47', 1),
(80, 1, 14, 'delivery_create', '2017-09-14 16:45:13', 1),
(81, 1, 15, 'delivery_create', '2017-09-14 16:46:05', 1),
(82, 1, 6, 'hiring_create', '2017-09-14 16:49:05', 1),
(83, 1, 4, 'customer_create', '2017-09-14 16:56:25', 1),
(84, 1, 4, 'site_create', '2017-09-14 17:01:15', 1),
(85, 1, 3, 'master_create', '2017-09-14 17:03:58', 1),
(86, 1, 14, 'deposit_create', '2017-09-14 17:12:35', 1),
(87, 1, 15, 'deposit_create', '2017-09-14 17:14:05', 1),
(88, 1, 16, 'delivery_create', '2017-09-14 17:16:01', 1),
(89, 1, 17, 'delivery_create', '2017-09-14 17:16:51', 1),
(90, 1, 18, 'delivery_create', '2017-09-14 17:17:26', 1),
(91, 1, 19, 'delivery_create', '2017-09-14 17:18:35', 1),
(92, 1, 20, 'delivery_create', '2017-09-14 17:21:32', 1),
(93, 1, 2, 'return_create', '2017-09-14 17:24:59', 1),
(94, 1, 3, 'return_create', '2017-09-15 09:41:05', 1),
(95, 1, 4, 'return_create', '2017-09-15 09:42:04', 1),
(96, 1, 5, 'return_create', '2017-09-15 09:43:13', 1),
(97, 1, 6, 'return_create', '2017-09-15 09:47:33', 1),
(98, 1, 7, 'return_create', '2017-09-15 09:48:58', 1),
(99, 1, 7, 'hiring_create', '2017-09-15 09:54:43', 1),
(100, 1, 8, 'hiring_create', '2017-09-15 09:56:45', 1),
(101, 1, 9, 'hiring_create', '2017-09-15 10:01:02', 1),
(102, 1, 10, 'hiring_create', '2017-09-15 10:40:22', 1),
(103, 1, 8, 'return_create', '2017-09-15 10:47:20', 1),
(104, 1, 1, 'lost_create', '2017-09-15 10:47:20', 1),
(105, 1, 5, 'customer_create', '2017-09-15 10:51:10', 1),
(106, 1, 5, 'site_create', '2017-09-15 10:53:18', 1),
(107, 1, 4, 'master_create', '2017-09-15 10:53:47', 1),
(108, 1, 16, 'deposit_create', '2017-09-15 11:05:59', 1),
(109, 1, 21, 'delivery_create', '2017-09-15 11:15:40', 1),
(110, 1, 11, 'hiring_create', '2017-09-15 11:16:35', 1),
(111, 1, 6, 'customer_create', '2017-09-15 11:19:11', 1),
(112, 1, 6, 'site_create', '2017-09-15 11:23:04', 1),
(113, 1, 5, 'master_create', '2017-09-15 11:23:21', 1),
(114, 1, 6, 'site_update', '2017-09-15 11:25:28', 1),
(115, 1, 4, 'special_price_create', '2017-09-15 11:25:28', 1),
(116, 1, 17, 'deposit_create', '2017-09-15 11:29:39', 1),
(117, 1, 22, 'delivery_create', '2017-09-15 11:30:11', 1),
(118, 1, 12, 'hiring_create', '2017-09-15 11:32:16', 1),
(119, 1, 4, 'obc_create', '2017-09-15 11:38:57', 1),
(120, 1, 5, 'obc_create', '2017-09-15 11:51:03', 1),
(121, 1, 6, 'obc_create', '2017-09-15 11:52:08', 1),
(122, 1, 7, 'obc_create', '2017-09-15 11:55:48', 1),
(123, 1, 8, 'obc_create', '2017-09-15 11:56:23', 1),
(124, 1, 8, 'obc_update', '2017-09-15 11:57:16', 1),
(125, 1, 9, 'obc_create', '2017-09-15 11:59:43', 1),
(126, 1, 10, 'obc_create', '2017-09-15 12:00:20', 1),
(127, 1, 5, 'obc_update', '2017-09-15 12:05:52', 1),
(128, 1, 2, 'return_update', '2017-09-15 12:12:24', 1),
(129, 1, 3, 'return_update', '2017-09-15 12:13:13', 1),
(130, 1, 4, 'return_update', '2017-09-15 12:13:29', 1),
(131, 1, 5, 'return_update', '2017-09-15 12:13:48', 1),
(132, 1, 9, 'hiring_update', '2017-09-15 12:17:56', 1),
(133, 1, 10, 'hiring_update', '2017-09-15 12:19:42', 1),
(134, 1, 6, 'return_update', '2017-09-15 12:22:59', 1),
(135, 1, 13, 'hiring_create', '2017-09-15 12:23:45', 1),
(136, 1, 11, 'obc_create', '2017-09-15 12:25:04', 1),
(137, 1, 7, 'customer_create', '2017-09-15 12:36:36', 1),
(138, 1, 7, 'site_create', '2017-09-15 12:44:16', 1),
(139, 1, 7, 'site_update', '2017-09-15 12:44:36', 1),
(140, 1, 5, 'special_price_create', '2017-09-15 12:44:36', 1),
(141, 1, 6, 'master_create', '2017-09-15 12:45:07', 1),
(142, 1, 18, 'deposit_create', '2017-09-15 12:57:36', 1),
(143, 1, 23, 'delivery_create', '2017-09-15 13:47:49', 1),
(144, 1, 14, 'hiring_create', '2017-09-15 13:49:11', 1),
(145, 1, 12, 'obc_create', '2017-09-15 13:53:07', 1),
(146, 1, 8, 'customer_create', '2017-09-15 13:56:24', 1),
(147, 1, 8, 'site_create', '2017-09-15 13:58:41', 1),
(148, 1, 7, 'master_create', '2017-09-15 14:01:49', 1),
(149, 1, 19, 'deposit_create', '2017-09-15 14:10:34', 1),
(150, 1, 20, 'deposit_create', '2017-09-15 14:16:49', 1),
(151, 1, 24, 'delivery_create', '2017-09-15 14:18:53', 1),
(152, 1, 25, 'delivery_create', '2017-09-15 14:19:51', 1),
(153, 1, 13, 'obc_create', '2017-09-15 14:21:34', 1),
(154, 1, 14, 'obc_create', '2017-09-15 14:28:23', 1),
(155, 1, 15, 'obc_create', '2017-09-15 14:29:01', 1),
(156, 1, 16, 'obc_create', '2017-09-15 14:29:27', 1),
(157, 1, 17, 'obc_create', '2017-09-15 14:30:57', 1),
(158, 1, 15, 'hiring_create', '2017-09-15 14:32:00', 1),
(159, 1, 9, 'customer_create', '2017-09-15 14:37:00', 1),
(160, 1, 9, 'site_create', '2017-09-15 14:39:22', 1),
(161, 1, 8, 'master_create', '2017-09-15 14:40:27', 1),
(162, 1, 21, 'deposit_create', '2017-09-15 14:42:40', 1),
(163, 1, 26, 'delivery_create', '2017-09-15 14:44:50', 1),
(164, 1, 18, 'obc_create', '2017-09-15 14:45:47', 1),
(165, 1, 10, 'customer_create', '2017-09-15 14:49:11', 1),
(166, 1, 10, 'site_create', '2017-09-15 14:52:10', 1),
(167, 1, 9, 'master_create', '2017-09-15 14:52:41', 1),
(168, 1, 22, 'deposit_create', '2017-09-15 14:55:39', 1),
(169, 1, 42, 'lot_create', '2017-09-15 15:06:31', 1),
(170, 1, 43, 'lot_create', '2017-09-15 15:07:21', 1),
(171, 1, 43, 'lot_update', '2017-09-15 15:07:56', 1),
(172, 1, 42, 'lot_update', '2017-09-15 15:08:11', 1),
(173, 1, 44, 'lot_create', '2017-09-15 15:08:35', 1),
(174, 1, 23, 'deposit_create', '2017-09-15 15:10:41', 1),
(175, 1, 27, 'delivery_create', '2017-09-15 15:12:21', 1),
(176, 1, 28, 'delivery_create', '2017-09-15 15:16:14', 1),
(177, 1, 29, 'delivery_create', '2017-09-15 15:16:49', 1),
(178, 1, 16, 'hiring_create', '2017-09-15 15:18:27', 1),
(179, 1, 19, 'obc_create', '2017-09-15 15:19:56', 1),
(180, 1, 20, 'obc_create', '2017-09-15 15:20:40', 1),
(181, 1, 21, 'obc_create', '2017-09-15 15:21:26', 1),
(182, 1, 11, 'customer_create', '2017-09-15 15:34:07', 1),
(183, 1, 11, 'site_create', '2017-09-15 15:36:49', 1),
(184, 1, 10, 'master_create', '2017-09-15 15:37:28', 1),
(185, 1, 24, 'deposit_create', '2017-09-15 15:38:41', 1),
(186, 1, 30, 'delivery_create', '2017-09-15 15:42:16', 1),
(187, 1, 31, 'delivery_create', '2017-09-15 15:42:52', 1),
(188, 1, 22, 'obc_create', '2017-09-15 15:44:33', 1),
(189, 1, 25, 'deposit_create', '2017-09-15 15:48:36', 1),
(190, 1, 12, 'customer_create', '2017-09-15 15:50:06', 1),
(191, 1, 12, 'site_create', '2017-09-15 15:53:23', 1),
(192, 1, 11, 'master_create', '2017-09-15 15:53:43', 1),
(193, 1, 45, 'lot_create', '2017-09-15 16:00:02', 1),
(194, 1, 46, 'lot_create', '2017-09-15 16:01:35', 1),
(195, 1, 26, 'deposit_create', '2017-09-15 16:26:40', 1),
(196, 1, 32, 'delivery_create', '2017-09-15 16:27:53', 1),
(197, 1, 12, 'customer_update', '2017-09-15 16:29:17', 1),
(198, 1, 32, 'delivery_update', '2017-09-15 16:29:46', 1),
(199, 1, 33, 'delivery_create', '2017-09-15 16:37:57', 1),
(200, 1, 34, 'delivery_create', '2017-09-15 16:38:31', 1),
(201, 1, 35, 'delivery_create', '2017-09-15 16:38:58', 1),
(202, 1, 36, 'delivery_create', '2017-09-15 16:39:41', 1),
(203, 1, 37, 'delivery_create', '2017-09-15 16:40:11', 1),
(204, 1, 38, 'delivery_create', '2017-09-15 16:40:57', 1),
(205, 1, 39, 'delivery_create', '2017-09-15 16:41:26', 1),
(206, 1, 40, 'delivery_create', '2017-09-15 16:41:57', 1),
(207, 1, 41, 'delivery_create', '2017-09-15 16:42:23', 1),
(208, 1, 42, 'delivery_create', '2017-09-15 16:42:54', 1),
(209, 1, 43, 'delivery_create', '2017-09-15 16:43:38', 1),
(210, 1, 44, 'delivery_create', '2017-09-15 16:44:04', 1),
(211, 1, 45, 'delivery_create', '2017-09-15 16:44:28', 1),
(212, 1, 46, 'delivery_create', '2017-09-15 16:44:52', 1),
(213, 1, 47, 'delivery_create', '2017-09-15 16:45:21', 1),
(214, 1, 48, 'delivery_create', '2017-09-15 16:45:55', 1),
(215, 1, 49, 'delivery_create', '2017-09-15 16:46:31', 1),
(216, 1, 50, 'delivery_create', '2017-09-15 16:47:23', 1),
(217, 1, 51, 'delivery_create', '2017-09-15 16:47:51', 1),
(218, 1, 52, 'delivery_create', '2017-09-15 16:48:29', 1),
(219, 1, 53, 'delivery_create', '2017-09-15 16:49:08', 1),
(220, 1, 54, 'delivery_create', '2017-09-15 16:50:15', 1),
(221, 1, 13, 'customer_create', '2017-09-15 17:06:13', 1),
(222, 1, 13, 'site_create', '2017-09-15 17:11:02', 1),
(223, 1, 12, 'master_create', '2017-09-15 17:11:23', 1),
(224, 1, 27, 'deposit_create', '2017-09-15 17:14:27', 1),
(225, 1, 55, 'delivery_create', '2017-09-15 17:28:35', 1),
(226, 1, 14, 'customer_create', '2017-09-25 09:54:39', 1),
(227, 1, 14, 'site_create', '2017-09-25 09:58:52', 1),
(228, 1, 13, 'master_create', '2017-09-25 10:00:36', 1),
(229, 1, 28, 'deposit_create', '2017-09-25 10:05:43', 1),
(230, 1, 56, 'delivery_create', '2017-09-25 10:08:29', 1),
(231, 1, 9, 'return_create', '2017-09-25 10:12:53', 1),
(232, 1, 17, 'hiring_create', '2017-09-25 10:14:39', 1),
(233, 1, 18, 'hiring_create', '2017-09-25 10:17:47', 1),
(234, 1, 23, 'obc_create', '2017-09-25 10:20:15', 1),
(235, 1, 23, 'obc_update', '2017-09-25 10:20:57', 1),
(236, 1, 23, 'obc_update', '2017-09-25 10:21:58', 1),
(237, 1, 9, 'return_update', '2017-09-25 10:26:56', 1),
(238, 1, 18, 'hiring_update', '2017-09-25 10:27:55', 1),
(239, 1, 15, 'customer_create', '2017-09-25 10:38:25', 1),
(240, 1, 15, 'site_create', '2017-09-25 10:40:56', 1),
(241, 1, 15, 'site_update', '2017-09-25 10:41:14', 1),
(242, 1, 6, 'special_price_create', '2017-09-25 10:41:15', 1),
(243, 1, 14, 'master_create', '2017-09-25 10:42:11', 1),
(244, 1, 47, 'lot_create', '2017-09-25 10:45:59', 1),
(245, 1, 15, 'site_update', '2017-09-25 10:46:48', 1),
(246, 1, 7, 'special_price_create', '2017-09-25 10:46:48', 1),
(247, 1, 15, 'site_update', '2017-09-25 10:47:38', 1),
(248, 1, 29, 'deposit_create', '2017-09-25 10:51:57', 1),
(249, 1, 29, 'deposit_update', '2017-09-25 11:01:40', 1),
(250, 1, 15, 'site_update', '2017-09-25 11:03:16', 1),
(251, 1, 57, 'delivery_create', '2017-09-25 11:03:41', 1),
(252, 1, 58, 'delivery_create', '2017-09-25 11:04:31', 1),
(253, 1, 59, 'delivery_create', '2017-09-25 11:06:15', 1),
(254, 1, 10, 'return_create', '2017-09-25 11:07:06', 1),
(255, 1, 57, 'delivery_update', '2017-09-25 11:11:23', 1),
(256, 1, 10, 'return_update', '2017-09-25 11:12:24', 1),
(257, 1, 15, 'site_update', '2017-09-25 11:27:11', 1),
(258, 1, 8, 'special_price_create', '2017-09-25 11:27:11', 1),
(259, 1, 58, 'delivery_update', '2017-09-25 11:28:11', 1),
(260, 1, 59, 'delivery_update', '2017-09-25 11:29:10', 1),
(261, 1, 16, 'customer_create', '2017-09-25 11:37:32', 1),
(262, 1, 16, 'site_create', '2017-09-25 11:41:10', 1),
(263, 1, 15, 'master_create', '2017-09-25 11:41:35', 1),
(264, 1, 48, 'lot_create', '2017-09-25 11:45:00', 1),
(265, 1, 30, 'deposit_create', '2017-09-25 11:47:04', 1),
(266, 1, 60, 'delivery_create', '2017-09-25 11:48:54', 1),
(267, 1, 17, 'customer_create', '2017-09-25 11:51:47', 1),
(268, 1, 17, 'site_create', '2017-09-25 11:53:59', 1),
(269, 1, 17, 'site_update', '2017-09-25 11:54:47', 1),
(270, 1, 9, 'special_price_create', '2017-09-25 11:54:47', 1),
(271, 1, 10, 'special_price_create', '2017-09-25 11:54:47', 1),
(272, 1, 11, 'special_price_create', '2017-09-25 11:54:47', 1),
(273, 1, 17, 'site_update', '2017-09-25 11:55:31', 1),
(274, 1, 12, 'special_price_create', '2017-09-25 11:55:31', 1),
(275, 1, 13, 'special_price_create', '2017-09-25 11:55:31', 1),
(276, 1, 17, 'site_update', '2017-09-25 11:56:04', 1),
(277, 1, 14, 'special_price_create', '2017-09-25 11:56:04', 1),
(278, 1, 17, 'site_update', '2017-09-25 11:57:08', 1),
(279, 1, 16, 'master_create', '2017-09-25 11:57:36', 1),
(280, 1, 61, 'delivery_create', '2017-09-25 12:08:43', 1),
(281, 1, 62, 'delivery_create', '2017-09-25 12:09:13', 1),
(282, 1, 63, 'delivery_create', '2017-09-25 12:10:11', 1),
(283, 1, 64, 'delivery_create', '2017-09-25 12:10:47', 1),
(284, 1, 65, 'delivery_create', '2017-09-25 12:11:28', 1),
(285, 1, 66, 'delivery_create', '2017-09-25 12:12:06', 1),
(286, 1, 67, 'delivery_create', '2017-09-25 12:12:45', 1),
(287, 1, 68, 'delivery_create', '2017-09-25 12:13:17', 1),
(288, 1, 11, 'return_create', '2017-09-25 12:14:40', 1),
(289, 1, 12, 'return_create', '2017-09-25 12:15:46', 1),
(290, 1, 13, 'return_create', '2017-09-25 12:16:32', 1),
(291, 1, 14, 'return_create', '2017-09-25 12:18:23', 1),
(292, 1, 15, 'return_create', '2017-09-25 12:19:18', 1),
(293, 1, 24, 'obc_create', '2017-09-25 12:20:48', 1),
(294, 1, 25, 'obc_create', '2017-09-25 12:21:24', 1),
(295, 1, 25, 'obc_update', '2017-09-25 12:21:33', 1),
(296, 1, 19, 'hiring_create', '2017-09-25 12:25:41', 1),
(297, 1, 20, 'hiring_create', '2017-09-25 12:26:44', 1),
(298, 1, 21, 'hiring_create', '2017-09-25 12:46:25', 1),
(299, 1, 12, 'site_update', '2017-09-25 14:24:28', 1),
(300, 1, 15, 'special_price_create', '2017-09-25 14:24:28', 1),
(301, 1, 47, 'delivery_update', '2017-09-25 14:27:33', 1),
(302, 1, 32, 'delivery_update', '2017-09-25 14:35:25', 1),
(303, 1, 12, 'site_update', '2017-09-25 14:35:53', 1),
(304, 1, 16, 'special_price_create', '2017-09-25 14:35:54', 1),
(305, 1, 32, 'delivery_update', '2017-09-25 14:36:19', 1),
(306, 1, 16, 'return_create', '2017-09-25 14:46:24', 1),
(307, 1, 12, 'site_update', '2017-09-25 14:49:18', 1),
(308, 1, 17, 'special_price_create', '2017-09-25 14:49:18', 1),
(309, 1, 49, 'delivery_update', '2017-09-25 14:49:39', 1),
(310, 1, 17, 'return_create', '2017-09-25 14:51:18', 1),
(311, 1, 22, 'hiring_create', '2017-09-25 14:53:06', 1),
(312, 1, 12, 'site_update', '2017-09-25 14:53:33', 1),
(313, 1, 18, 'customer_create', '2017-09-25 15:52:46', 1),
(314, 1, 18, 'customer_update', '2017-09-25 15:54:02', 1),
(315, 1, 18, 'site_create', '2017-09-25 15:54:46', 1),
(316, 1, 17, 'master_create', '2017-09-25 15:57:50', 1),
(317, 1, 31, 'deposit_create', '2017-09-25 16:00:25', 1),
(318, 1, 69, 'delivery_create', '2017-09-25 16:01:58', 1),
(319, 1, 70, 'delivery_create', '2017-09-25 16:05:44', 1),
(320, 1, 71, 'delivery_create', '2017-09-25 16:06:22', 1),
(321, 1, 18, 'site_update', '2017-09-25 16:08:28', 1),
(322, 1, 18, 'special_price_create', '2017-09-25 16:08:28', 1),
(323, 1, 72, 'delivery_create', '2017-09-25 16:08:50', 1),
(324, 1, 18, 'site_update', '2017-09-25 16:09:05', 1),
(325, 1, 18, 'return_create', '2017-09-25 16:23:45', 1),
(326, 1, 19, 'return_create', '2017-09-25 16:25:42', 1),
(327, 1, 23, 'hiring_create', '2017-09-25 16:27:02', 1),
(328, 1, 23, 'hiring_update', '2017-09-25 16:33:01', 1),
(329, 1, 19, 'return_update', '2017-09-25 16:47:53', 1),
(330, 1, 19, 'return_update', '2017-09-25 16:49:47', 1),
(331, 1, 24, 'hiring_create', '2017-09-25 16:57:44', 1),
(332, 1, 19, 'customer_create', '2017-09-25 17:00:52', 1),
(333, 1, 19, 'site_create', '2017-09-25 17:02:57', 1),
(334, 1, 18, 'master_create', '2017-09-25 17:03:15', 1),
(335, 1, 19, 'site_update', '2017-09-25 17:06:37', 1),
(336, 1, 19, 'special_price_create', '2017-09-25 17:06:38', 1),
(337, 1, 19, 'site_update', '2017-09-25 17:08:32', 1),
(338, 1, 20, 'special_price_create', '2017-09-25 17:08:32', 1),
(339, 1, 32, 'deposit_create', '2017-09-25 17:10:22', 1),
(340, 1, 73, 'delivery_create', '2017-09-25 17:19:27', 1),
(341, 1, 25, 'hiring_create', '2017-09-25 17:19:56', 1),
(342, 1, 20, 'customer_create', '2017-09-25 17:22:41', 1),
(343, 1, 20, 'site_create', '2017-09-25 17:29:44', 1),
(344, 1, 19, 'master_create', '2017-09-25 17:30:24', 1),
(345, 1, 20, 'customer_update', '2017-09-25 17:30:37', 1),
(346, 1, 20, 'site_update', '2017-09-25 17:30:47', 1),
(347, 1, 21, 'special_price_create', '2017-09-25 17:30:47', 1),
(348, 1, 49, 'lot_create', '2017-09-25 17:35:10', 1),
(349, 1, 33, 'deposit_create', '2017-09-25 17:36:46', 1),
(350, 1, 50, 'lot_create', '2017-09-25 17:38:43', 1),
(351, 1, 20, 'site_update', '2017-09-25 17:38:57', 1),
(352, 1, 22, 'special_price_create', '2017-09-25 17:38:57', 1),
(353, 1, 74, 'delivery_create', '2017-09-25 17:40:16', 1),
(354, 1, 21, 'customer_create', '2017-09-25 17:47:41', 1),
(355, 1, 21, 'site_create', '2017-09-25 17:50:49', 1),
(356, 1, 20, 'master_create', '2017-09-25 17:51:16', 1),
(357, 1, 34, 'deposit_create', '2017-09-25 17:53:05', 1),
(358, 1, 75, 'delivery_create', '2017-09-25 17:54:03', 1),
(359, 1, 76, 'delivery_create', '2017-09-25 17:54:48', 1),
(360, 1, 77, 'delivery_create', '2017-09-25 17:58:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_companies`
--

CREATE TABLE `wp_shc_companies` (
  `id` int(11) NOT NULL,
  `company_id` varchar(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `mobile` text NOT NULL,
  `tin_number` text NOT NULL,
  `gst_number` text NOT NULL,
  `current_year` int(4) NOT NULL,
  `financial_year` varchar(255) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_companies`
--

INSERT INTO `wp_shc_companies` (`id`, `company_id`, `company_name`, `address`, `phone`, `mobile`, `tin_number`, `gst_number`, `current_year`, `financial_year`, `active`) VALUES
(1, 'BEN', 'Benvin Associates', '5 V.G.P Santhanammal Nagar, Velachery Main Road, Gowrivakkam, Chennai 600073', '2278 0605 / 2278 1866', '94440 50664', '', '33AALPF8569L1Z5', 2017, '2017 - 2018', 1),
(2, 'JVB', 'JVB Associates', '1 V.G.P Santhanammal Nagar, Velachery Main Road, Gowrivakkam, Chennai 600073', '2278 0605 / 2278 1866', '94440 50664', '', '33AEBPC6423Q1ZJ', 2017, '2017 - 2018', 1),
(3, 'JBC', 'JBC Associates', 'Plot No 28 Mambakkam Main Road, Ponmar, Chennai - 600 048', '2278 0605 / 2278 1866', '94440 50664', '33446373536', '33BGIPC3084P1Z6', 2017, '2017 - 2018', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_companies_master`
--

CREATE TABLE `wp_shc_companies_master` (
  `id` int(11) NOT NULL,
  `company_id` varchar(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `mobile` text NOT NULL,
  `tin_number` text NOT NULL,
  `gst_number` text NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_companies_master`
--

INSERT INTO `wp_shc_companies_master` (`id`, `company_id`, `company_name`, `address`, `phone`, `mobile`, `tin_number`, `gst_number`, `active`) VALUES
(1, 'BEN', 'Benvin Associates', '5 V.G.P Santhanammal Nagar, Velachery Main Road, Gowrivakkam, Chennai 600073', '2278 0605 / 2278 1866', '94440 50664', '', '33AALPF8569L1Z5', 1),
(2, 'JVB', 'JVB Associates', '1 V.G.P Santhanammal Nagar, Velachery Main Road, Gowrivakkam, Chennai 600073', '2278 0605 / 2278 1866', '94440 50664', '', '33AEBPC6423Q1ZJ', 1),
(3, 'JBC', 'JBC Associates', 'Plot No 28 Mambakkam Main Road, Ponmar, Chennai - 600 048', '2278 0605 / 2278 1866', '94440 50664', '33446373536', '33BGIPC3084P1Z6', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_customers`
--

CREATE TABLE `wp_shc_customers` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'retail',
  `bill_from_comp` int(2) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_customers`
--

INSERT INTO `wp_shc_customers` (`id`, `name`, `mobile`, `address`, `type`, `bill_from_comp`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 'Balaji Engineering', '9824111232', 'No 6, 1st Main Road,\r\nVOC Nagar, Kodambakkam, \r\nChennai 600024', 'retail', 3, '2017-09-14 10:38:55', '0000-00-00 00:00:00', 1, 1),
(2, 'Shapoorji Pallonji & Co Ltd', '7358420156', 'SP Infocity,Module 4-A,\r\n2nd Floor, A-Block, No-40,\r\nMGR Salai, Kandanchavadi, Perungudi,\r\nChennai 600096', 'retail', 3, '2017-09-14 14:08:54', '0000-00-00 00:00:00', 1, 1),
(3, 'Jai Udhayan Foundation', '26503635', 'No 18, Anusaya Nagar, Kolathur,\r\nChennai - 600099', 'retail', 3, '2017-09-14 14:41:02', '0000-00-00 00:00:00', 1, 1),
(4, 'M.Arunachalam Projects And Infrastructure Co.Pvt.Ltd', '28112881', '107/76, Lloyds Road, ( Avvai Shanmugam Road  ),\r\nRoyapettah, Chennai - 600014', 'retail', 3, '2017-09-14 16:56:25', '0000-00-00 00:00:00', 1, 1),
(5, 'Sescon Builders PVT. Ltd', '8695553297', 'Vallam Vadagal Industrial,\r\nSriperumandur,\r\nChennai', 'retail', 3, '2017-09-15 10:51:10', '0000-00-00 00:00:00', 1, 1),
(6, 'Vijay Nirman Company Pvt. Ltd', '7674855139', '#11-09-16, Dasapalla Hills,\r\nopp. To - Tree House Kids School)\r\nVisakhapatnam', 'retail', 3, '2017-09-15 11:19:11', '0000-00-00 00:00:00', 1, 1),
(7, 'CRR Constructions', '25200069', 'No. 8, 1st Cross, Doctor layout, Kasthuri Nagar,\r\nBangalore - 560 043', 'retail', 3, '2017-09-15 12:36:36', '0000-00-00 00:00:00', 1, 1),
(8, 'Haffiz Enterprises', '09699750010', 'Flat No : 101, Khosshbu Appartment,\r\nPlot No : 210/003, Behind Gaon Devi Mandir,\r\nSector M, Juhu Gaon, Vashi,\r\nNavi Mumbai - 400703', 'retail', 3, '2017-09-15 13:56:24', '0000-00-00 00:00:00', 1, 1),
(9, 'Savani Construction Co. Pvt. Ltd', '07893784633', 'Bldg. No. 8, Rajabahadur Mansion,\r\n2nd Floor, Ambalal Doshi Marg,\r\nBehind Bombay Stock Exchange,\r\nFort, Mumbai 400023', 'retail', 3, '2017-09-15 14:37:00', '0000-00-00 00:00:00', 1, 1),
(10, 'United Construction', '9551587947', 'Adumbar, 1st Floor, Next To Anushka Society,\r\nMoshi - Alaandi Road,Moshi T.K,\r\nHaveli D.T,\r\nPune - 412105', 'retail', 3, '2017-09-15 14:49:11', '0000-00-00 00:00:00', 1, 1),
(11, 'G.R Mega Engineering', '9444489636', 'No 9, V Block, TCB Complex,New No. 111,\r\nHumballaman Koil St, Tondiarpet,\r\nChennai 600081', 'retail', 3, '2017-09-15 15:34:07', '0000-00-00 00:00:00', 1, 1),
(12, 'R. Sugumaran', '9840024516', '10, 2nd Street, Telephone Colony,\r\nAdambakkam,\r\nChennai 600088', 'retail', 3, '2017-09-15 15:50:06', '2017-09-15 10:59:17', 1, 1),
(13, 'Ganesan Builders Limited', '9176675187', 'New No : 46 A, C.P Ramasamy Road,\r\nAbiramapuram, Chennai - 600018', 'retail', 3, '2017-09-15 17:06:13', '0000-00-00 00:00:00', 1, 1),
(14, 'Microtech Industries', '9840190709', 'Plot No : 18/4A, Part 11,\r\nTass Industrial Estate,\r\nNear Ambathur Estate, Telephone Exchange,\r\nAmbathur, Chennai - 600098', 'retail', 3, '2017-09-25 09:54:39', '0000-00-00 00:00:00', 1, 1),
(15, 'RSP United Infra Construction PVT. LTD.', '7812823331', 'Sankleche Utsav Project, Cooks Road, Chennai', 'retail', 3, '2017-09-25 10:38:25', '0000-00-00 00:00:00', 1, 1),
(16, 'GND Enterprises', '9600566826', 'Old No: 6/179, New No: 8/208,\r\n7th Cross Street, Jeeva Nagar,\r\nPaareri,Singaperumal Koil,\r\nKancheepuram Dt. 603204', 'retail', 1, '2017-09-25 11:37:32', '0000-00-00 00:00:00', 1, 1),
(17, 'Chinna Thambi', '9840866177', 'S/o. Gangatharan,\r\nNo: 3/339, Govindasamy Nagar,\r\n9th Street, Madipakkam,\r\nChennai - 600091', 'retail', 1, '2017-09-25 11:51:47', '0000-00-00 00:00:00', 1, 1),
(18, 'Star Homes', '7299087025', 'Star Homes, Kamaraja puram', 'retail', 1, '2017-09-25 15:52:46', '2017-09-25 10:24:02', 1, 1),
(19, 'Wollaque Ventilation & Conditioning PVT. LTD.', '09810070142', '4-45, Sector - 83, Phase - 11,\r\nDistt. Gautam Budh Nagar,\r\nNoida. U.P - 201301', 'retail', 1, '2017-09-25 17:00:51', '0000-00-00 00:00:00', 1, 1),
(20, 'SRI Venkateswara Engineering & Contractors', '9849988679', '244/1,2,3, Padipeta Road, Near Tiruchanoor, Tirupati', 'retail', 1, '2017-09-25 17:22:41', '2017-09-25 12:00:37', 1, 1),
(21, 'Sunil Steel Fabricators', '9803444773', 'Mohalla Dr. Ambedkar Nagar,\r\nP.O. Chuggitti, Jalandhar,', 'retail', 1, '2017-09-25 17:47:41', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_customer_site`
--

CREATE TABLE `wp_shc_customer_site` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `site_address` text NOT NULL,
  `phone_number` varchar(250) NOT NULL,
  `extra_contact` text NOT NULL,
  `gst_number` varchar(255) NOT NULL,
  `gst_for` varchar(10) NOT NULL,
  `vat_number` varchar(255) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_customer_site`
--

INSERT INTO `wp_shc_customer_site` (`id`, `customer_id`, `site_name`, `site_address`, `phone_number`, `extra_contact`, `gst_number`, `gst_for`, `vat_number`, `discount`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 1, 'Thirumangalam', 'VR Mall, Thirumangalam,\r\nAnnanagagar West', '9824111232', '', '33AAJPA2411Q1ZX', 'cgst', '33856453908', '5.00', '2017-09-14 10:45:46', '0000-00-00 00:00:00', 1, 1),
(2, 2, 'Vellore', 'Christian Medical College,\r\nKannigapuram, Rathnagiri,\r\nVellore - 632157', '7358420156', '', '', 'cgst', '', '0.00', '2017-09-14 14:22:36', '0000-00-00 00:00:00', 1, 1),
(3, 3, 'Vadapalani', '', '917659005, 9444166365', '', '33AAIPE7126K1ZS', 'cgst', '', '10.00', '2017-09-14 14:42:29', '2017-09-14 14:43:47', 1, 1),
(4, 4, 'RSS Building, Central', 'RSS Building, Chennai Park Central', '9840097149', '', '33AAGCM0106J1ZX', 'cgst', '33580782126', '0.00', '2017-09-14 17:01:15', '0000-00-00 00:00:00', 1, 1),
(5, 5, 'Mahabalipuram', 'Kunnapathu Village', '7845698003', '', '33AAPCS9101C1ZK', 'cgst', '', '0.00', '2017-09-15 10:53:18', '0000-00-00 00:00:00', 1, 1),
(6, 6, 'Thada (Sri City)', 'IIITDM,\r\nSri City,\r\nThada', '09550745566', '', '37AABCV6001E1ZQ', 'igst', '', '0.00', '2017-09-15 11:23:04', '0000-00-00 00:00:00', 1, 1),
(7, 7, 'Arakkonam', 'INS Rajali, Arakkonam', '7010137670', '', '33AAHFC0207G1Z5', 'cgst', '', '10.00', '2017-09-15 12:44:16', '2017-09-15 12:44:36', 1, 1),
(8, 8, 'Port Gate - 7', 'Port Gate - 7,\r\nChennai', '07506288374', '', '27AFSPA5045E2ZJ', 'cgst', '', '0.00', '2017-09-15 13:58:41', '0000-00-00 00:00:00', 1, 1),
(9, 9, 'Parrys (Beach Road)', 'Chennai Beach', '7893784633', '', '33AAJCS4567L1ZV', 'cgst', '', '0.00', '2017-09-15 14:39:22', '0000-00-00 00:00:00', 1, 1),
(10, 10, 'Perungalathur', 'No 16, G.S.T Road,\r\nPerungalathur,\r\nChennai 600083', '9551587947', '', '27AGQPB2908N1Z2', 'cgst', '', '0.00', '2017-09-15 14:52:10', '0000-00-00 00:00:00', 1, 1),
(11, 11, 'Walajabad', 'AVS Industrial Park,\r\nNo 90, SP Road,\r\nKattavakkam Village,\r\nWalajabad,\r\nKanchipuram', '9940684001', '', '33ALBPR8971K1ZK', 'igst', '', '0.00', '2017-09-15 15:36:49', '0000-00-00 00:00:00', 1, 1),
(12, 12, 'Akkarai', 'No 10, Kunal Gardan,\r\nAkkarai', '8508087569', '', '33ALZPS9851P1ZO', 'cgst', '', '10.00', '2017-09-15 15:53:23', '2017-09-25 14:24:28', 1, 1),
(13, 13, 'Sriperumandur', 'Sain Gobain India Glass Ltd,\r\nDolamite Processing Unit,\r\nA-1 Sipcot Industrial Park,\r\nSriperumandur - 602105', '9176675187', '', '33AAACG8971D1ZP', 'cgst', '33440760184', '0.00', '2017-09-15 17:11:02', '0000-00-00 00:00:00', 1, 1),
(14, 14, 'Kunnavakkam', 'No. 110/07,\r\nKunnavakkam, Walajabad,\r\nKancheepuram', '7299046981', '', '', 'cgst', '33631344553', '0.00', '2017-09-25 09:58:52', '0000-00-00 00:00:00', 1, 1),
(15, 15, 'Pattalam', 'Sankleche Utsav Project, Cooks Road, Otteri, Chennai 600012', '9446112709', '', '33AAFCR2625G1ZO', 'cgst', '33380991659', '5.00', '2017-09-25 10:40:56', '2017-09-25 10:41:14', 1, 1),
(16, 16, 'Maraimalai Nagar', 'Faurecia Interier Systems India Pvt. Ltd,\r\nPlot No D.1, CMDA Industrial Estate,\r\nMaraimalai Nagar, Chennai - 603209', '9840370280', '', '33AREPG4810B1ZL', 'cgst', '', '0.00', '2017-09-25 11:41:10', '0000-00-00 00:00:00', 1, 1),
(17, 17, 'Harini Builders, Camp Road', 'Harini Builders, Camp Road', '9840866177', '', '', 'cgst', '', '0.00', '2017-09-25 11:53:59', '0000-00-00 00:00:00', 1, 1),
(18, 18, 'Kamarajapuram', 'Kamarajapuram', '7299087025', '', '', 'cgst', '', '0.00', '2017-09-25 15:54:46', '0000-00-00 00:00:00', 1, 1),
(19, 19, 'DLF, Ramapuram', 'DLF, Ramapuram', '09821946307', '', '', 'cgst', '', '0.00', '2017-09-25 17:02:57', '0000-00-00 00:00:00', 1, 1),
(20, 20, 'Gudur', 'Ph #II, Meenakshi Energy Ltd. (MEL), Thamminapatnam, Nellore', '9849988679', '', '', 'cgst', '', '0.00', '2017-09-25 17:29:44', '2017-09-25 17:30:47', 1, 1),
(21, 21, 'HPCL, Chennai Port', 'HPCL, Kasimedu,\r\nRoyapuram', '9599904293', '', '', 'cgst', '', '5.00', '2017-09-25 17:50:49', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_delivery`
--

CREATE TABLE `wp_shc_delivery` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `delivery_date` datetime NOT NULL,
  `last_billed_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `vehicle_number` varchar(255) NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `driver_mobile` varchar(255) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_delivery`
--

INSERT INTO `wp_shc_delivery` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `delivery_date`, `last_billed_date`, `created_at`, `vehicle_number`, `driver_name`, `driver_mobile`, `updated_by`, `active`) VALUES
(1, 3, 2016, 1, '', 1, '2017-03-25 06:39:00', '2017-03-24', '2017-09-14 12:27:38', 'TN21AX3011', 'Manimaran', '', 1, 1),
(2, 3, 2017, 1, '', 1, '2017-04-18 06:57:00', '2017-04-17', '2017-09-14 12:29:25', 'TN20BJ2909', 'Murugan', '', 1, 1),
(3, 3, 2017, 2, '', 1, '2017-04-27 06:59:00', '2017-04-26', '2017-09-14 12:32:27', 'TN11T0470', 'Nagaraj', '', 1, 1),
(4, 3, 2017, 3, '', 2, '2017-07-29 10:36:00', '2017-07-28', '2017-09-14 16:07:52', 'TN22AC2075', 'Sudahar', '', 1, 1),
(5, 3, 2017, 4, '', 2, '2017-08-08 10:38:00', '2017-08-07', '2017-09-14 16:08:46', 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(6, 3, 2017, 5, '', 2, '2017-08-09 10:38:00', '2017-08-08', '2017-09-14 16:10:14', 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(7, 3, 2017, 6, '', 2, '2017-08-11 10:40:00', '2017-08-10', '2017-09-14 16:11:23', 'TN20BJ2909', 'Murugan', '', 1, 1),
(8, 3, 2017, 7, '', 2, '2017-08-15 10:50:00', '2017-08-14', '2017-09-14 16:23:58', 'TN20BJ2909', 'Murugan', '', 1, 1),
(9, 3, 2017, 8, '', 2, '2017-08-15 10:55:00', '2017-08-14', '2017-09-14 16:26:47', 'TN22CR2113', 'Murugan', '', 1, 1),
(10, 3, 2017, 9, '', 2, '2017-08-17 10:56:00', '2017-08-16', '2017-09-14 16:27:13', 'TN22AC2075', 'Ananth', '', 1, 1),
(11, 3, 2017, 10, '', 2, '2017-08-19 10:57:00', '2017-08-18', '2017-09-14 16:42:53', 'TN21AX3011', 'Manimaran', '', 1, 1),
(12, 3, 2017, 11, '', 2, '2017-08-26 11:12:00', '2017-08-25', '2017-09-14 16:44:01', 'TN22AY7711', 'Ananth', '', 1, 1),
(13, 3, 2017, 12, '', 2, '2017-08-30 11:14:00', '2017-08-29', '2017-09-14 16:44:47', 'TN11T0470', 'Nagaraj', '', 1, 1),
(14, 3, 2017, 13, '', 2, '2017-09-02 11:14:00', '2017-09-01', '2017-09-14 16:45:13', 'TN20BJ2909', 'Murugan', '', 1, 1),
(15, 3, 2017, 14, '', 2, '2017-09-02 11:15:00', '2017-09-01', '2017-09-14 16:46:05', 'TN18L8701', 'Murugan', '', 1, 1),
(16, 3, 2017, 15, '', 3, '2017-05-09 11:44:00', '2017-05-08', '2017-09-14 17:16:01', 'TN22BP4749', '', '', 1, 1),
(17, 3, 2017, 16, '', 3, '2017-05-10 11:46:00', '2017-05-09', '2017-09-14 17:16:51', 'TN22BP4749', '', '', 1, 1),
(18, 3, 2017, 17, '', 3, '2017-05-11 11:46:00', '2017-05-10', '2017-09-14 17:17:26', 'TN22BP4749', '', '', 1, 1),
(19, 3, 2017, 18, '', 3, '2017-05-24 11:47:00', '2017-05-23', '2017-09-14 17:18:35', 'TN22BP4749', '', '', 1, 1),
(20, 3, 2017, 19, '', 3, '2017-06-28 11:48:00', '2017-06-27', '2017-09-14 17:21:32', 'TN07AD3080', '', '', 1, 1),
(21, 3, 2017, 20, '', 4, '2017-08-08 05:44:00', '2017-08-07', '2017-09-15 11:15:40', 'TN90Q1604', '', '', 1, 1),
(22, 3, 2017, 21, '', 5, '2017-08-05 05:59:00', '2017-08-04', '2017-09-15 11:30:11', 'AP26TT6759', '', '', 1, 1),
(23, 3, 2017, 22, '', 6, '2017-08-10 08:15:00', '2017-08-09', '2017-09-15 13:47:49', 'TN01Y6291', '', '', 1, 1),
(24, 3, 2017, 23, '', 7, '2017-07-24 08:46:00', '2017-07-23', '2017-09-15 14:18:53', 'TN21AX3011', 'Manimaran', '', 1, 1),
(25, 3, 2017, 24, '', 7, '2017-09-15 08:49:00', '2017-09-14', '2017-09-15 14:19:51', 'TN21AX3011', 'Manimaran', '', 1, 1),
(26, 3, 2017, 25, '', 8, '2017-09-01 09:13:00', '2017-08-31', '2017-09-15 14:44:50', 'TN11T0470', '', '', 1, 1),
(27, 3, 2017, 26, '', 9, '2017-07-22 09:40:00', '2017-07-21', '2017-09-15 15:12:21', 'TN22AC2075', 'Ananth', '', 1, 1),
(28, 3, 2017, 27, '', 9, '2017-09-01 09:42:00', '2017-08-31', '2017-09-15 15:16:14', 'TN21AX3011', 'Manimaran', '', 1, 1),
(29, 3, 2017, 28, '', 9, '2017-09-09 09:46:00', '2017-09-08', '2017-09-15 15:16:49', 'TN22CR2113', 'Murugan', '', 1, 1),
(30, 3, 2017, 29, '', 10, '2017-08-19 10:09:00', '2017-08-18', '2017-09-15 15:42:16', 'TN18L8701', 'Murugan', '', 1, 1),
(31, 3, 2017, 30, '', 10, '2017-09-06 10:12:00', '2017-09-05', '2017-09-15 15:42:52', 'TN22CR2113', 'Murugan', '', 1, 1),
(32, 3, 2017, 31, '', 11, '2017-08-17 10:56:00', '2017-08-16', '2017-09-15 16:27:53', 'TN20BJ2909', 'Murugan', '', 1, 1),
(33, 3, 2017, 32, '', 11, '2017-08-17 11:07:00', '2017-08-16', '2017-09-15 16:37:56', 'TN18L8701', 'Pawan', '', 1, 1),
(34, 3, 2017, 33, '', 11, '2017-08-17 11:08:00', '2017-08-16', '2017-09-15 16:38:31', 'TN18L8701', 'Murugan', '', 1, 1),
(35, 3, 2017, 34, '', 11, '2017-08-17 11:08:00', '2017-08-16', '2017-09-15 16:38:58', 'TN20BJ2909', 'Murugan', '', 1, 1),
(36, 3, 2017, 35, '', 11, '2017-08-18 11:09:00', '2017-08-17', '2017-09-15 16:39:41', 'TN18L8701', 'Pawan', '', 1, 1),
(37, 3, 2017, 36, '', 11, '2017-08-19 11:09:00', '2017-08-18', '2017-09-15 16:40:11', 'TN21AX3011', 'Manimaran', '', 1, 1),
(38, 3, 2017, 37, '', 11, '2017-08-21 11:10:00', '2017-08-20', '2017-09-15 16:40:57', 'TN21Ax3011', 'Manimaran', '', 1, 1),
(39, 3, 2017, 38, '', 11, '2017-08-21 11:11:00', '2017-08-20', '2017-09-15 16:41:26', 'TN18L8701', 'Murugan', '', 1, 1),
(40, 3, 2017, 39, '', 11, '2017-08-22 11:11:00', '2017-08-21', '2017-09-15 16:41:57', 'TN20BJ2909', 'Pawan', '', 1, 1),
(41, 3, 2017, 40, '', 11, '2017-08-22 11:11:00', '2017-08-21', '2017-09-15 16:42:23', 'TN18L8701', '', '', 1, 1),
(42, 3, 2017, 41, '', 11, '2017-08-23 11:12:00', '2017-08-22', '2017-09-15 16:42:54', 'TN18L8701', 'Murugan', '', 1, 1),
(43, 3, 2017, 42, '', 11, '2017-08-23 11:12:00', '2017-08-22', '2017-09-15 16:43:38', 'TN20BJ2909', 'Pawan', '', 1, 1),
(44, 3, 2017, 43, '', 11, '2017-08-23 11:13:00', '2017-08-22', '2017-09-15 16:44:04', 'TN20BJ2909', 'Murugan', '', 1, 1),
(45, 3, 2017, 44, '', 11, '2017-08-25 11:14:00', '2017-08-24', '2017-09-15 16:44:28', 'TN20BJ2909', 'Pawan', '', 1, 1),
(46, 3, 2017, 45, '', 11, '2017-08-25 11:14:00', '2017-08-24', '2017-09-15 16:44:52', 'TN118L8701', 'Murugan', '', 1, 1),
(47, 3, 2017, 46, '', 11, '2017-08-25 11:14:00', '2017-08-24', '2017-09-15 16:45:21', 'TN20BJ2909', 'Pawan', '', 1, 1),
(48, 3, 2017, 47, '', 11, '2017-08-26 11:15:00', '2017-08-25', '2017-09-15 16:45:55', 'TN20BJ2909', 'Murugan', '', 1, 1),
(49, 3, 2017, 48, '', 11, '2017-08-26 11:15:00', '2017-08-25', '2017-09-15 16:46:31', 'TN18L8701', 'Murugan', '', 1, 1),
(50, 3, 2017, 49, '', 11, '2017-08-29 11:16:00', '2017-08-28', '2017-09-15 16:47:22', 'TN21AX3011', 'Manimaran', '', 1, 1),
(51, 3, 2017, 50, '', 11, '2017-08-29 11:17:00', '2017-08-28', '2017-09-15 16:47:51', 'TN20BJ2909', 'Pawan', '', 1, 1),
(52, 3, 2017, 51, '', 11, '2017-09-01 11:17:00', '2017-08-31', '2017-09-15 16:48:29', 'TN22CR2113', 'Murugan', '', 1, 1),
(53, 3, 2017, 52, '', 11, '2017-09-04 11:18:00', '2017-09-03', '2017-09-15 16:49:08', 'TN20BJ2909', 'Murugan', '', 1, 1),
(54, 3, 2017, 53, '', 11, '2017-09-07 11:19:00', '2017-09-06', '2017-09-15 16:50:15', 'TN22CR2113', 'Murugan', '', 1, 1),
(55, 3, 2017, 54, '', 12, '2017-06-30 11:48:00', '2017-06-29', '2017-09-15 17:28:35', 'TN20BJ2909', 'Murugan', '', 1, 1),
(56, 3, 2017, 55, '', 13, '2017-04-22 04:36:00', '2017-04-21', '2017-09-25 10:08:29', 'TN11T0470', 'Nagarajan', '', 1, 1),
(57, 3, 2017, 56, '', 14, '2017-07-29 05:31:00', '2017-07-28', '2017-09-25 11:03:41', 'TN20BJ2909', 'Murugan', '', 1, 1),
(58, 3, 2017, 57, '', 14, '2017-07-31 05:33:00', '2017-07-30', '2017-09-25 11:04:31', 'TN18L8701', 'Murugan', '', 1, 1),
(59, 3, 2017, 58, '', 14, '2017-08-01 05:34:00', '2017-07-31', '2017-09-25 11:06:15', 'TN20BJ2909', 'Murugan', '', 1, 1),
(60, 1, 2017, 1, '', 15, '2017-09-16 06:17:00', '2017-09-15', '2017-09-25 11:48:54', 'TN22CR2113', 'Murugan', '', 1, 1),
(61, 1, 2016, 1, '', 16, '2017-02-03 06:37:00', '2017-02-02', '2017-09-25 12:08:43', 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(62, 1, 2016, 2, '', 16, '2017-03-17 06:38:00', '2017-03-16', '2017-09-25 12:09:13', 'TN20BJ2909', 'Murugan', '', 1, 1),
(63, 1, 2016, 3, '', 16, '2017-03-25 06:39:00', '2017-03-24', '2017-09-25 12:10:11', 'TN22CR2113', 'Murugan', '', 1, 1),
(64, 1, 2016, 4, '', 16, '2017-03-29 06:40:00', '2017-03-28', '2017-09-25 12:10:47', 'TN18L8701', 'Murugan', '', 1, 1),
(65, 1, 2016, 5, '', 16, '2017-03-29 06:40:00', '2017-03-28', '2017-09-25 12:11:28', 'TN20BJ2909', 'Murugan', '', 1, 1),
(66, 1, 2016, 6, '', 16, '2017-03-30 06:41:00', '2017-03-29', '2017-09-25 12:12:06', 'TN20BJ2909', 'Murugan', '', 1, 1),
(67, 1, 2017, 2, '', 16, '2017-04-08 06:42:00', '2017-04-07', '2017-09-25 12:12:45', 'TN18L8701', 'Murugan', '', 1, 1),
(68, 1, 2017, 3, '', 16, '2017-05-16 06:42:00', '2017-05-15', '2017-09-25 12:13:16', 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(69, 1, 2017, 4, '', 17, '2017-06-26 10:30:00', '2017-06-25', '2017-09-25 16:01:58', 'TN22CR2113', 'Murugan', '', 1, 1),
(70, 1, 2017, 5, '', 17, '2017-06-27 10:32:00', '2017-06-26', '2017-09-25 16:05:44', 'TN18L8701', 'Murugan', '', 1, 1),
(71, 1, 2017, 6, '', 17, '2017-06-28 10:35:00', '2017-06-27', '2017-09-25 16:06:22', 'TN18L8701', 'Murugan', '', 1, 1),
(72, 1, 2017, 7, '', 17, '2017-08-11 10:36:00', '2017-08-10', '2017-09-25 16:08:50', 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(73, 1, 2017, 8, '', 18, '2017-07-17 11:40:00', '2017-07-16', '2017-09-25 17:19:27', 'TN20BJ2909', 'Murugan', '', 1, 1),
(74, 1, 2017, 9, '', 19, '2017-08-19 12:06:00', '2017-08-18', '2017-09-25 17:40:16', 'AP16TU3160', '', '', 1, 1),
(75, 1, 2017, 10, '', 20, '2017-09-07 12:23:00', '2017-09-06', '2017-09-25 17:54:03', 'TN21AX3011', 'Manimaran', '', 1, 1),
(76, 1, 2017, 11, '', 20, '2017-09-08 12:24:00', '2017-09-07', '2017-09-25 17:54:48', 'TN18L8701', 'Murugan', '', 1, 1),
(77, 1, 2017, 12, '', 20, '2017-09-09 12:24:00', '2017-09-08', '2017-09-25 17:58:05', 'TN21AX3011', 'Manimaran', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_delivery_detail`
--

CREATE TABLE `wp_shc_delivery_detail` (
  `id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `master_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `rate_per_unit` decimal(15,2) NOT NULL,
  `delivery_date` date NOT NULL,
  `last_billed_date` date NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_delivery_detail`
--

INSERT INTO `wp_shc_delivery_detail` (`id`, `delivery_id`, `master_id`, `lot_id`, `qty`, `rate_per_unit`, `delivery_date`, `last_billed_date`, `active`) VALUES
(1, 1, 1, 1, 20, '1.10', '2017-03-25', '2017-03-24', 1),
(2, 1, 1, 8, 80, '1.40', '2017-03-25', '2017-03-24', 1),
(3, 1, 1, 11, 25, '3.50', '2017-03-25', '2017-03-24', 1),
(4, 1, 1, 5, 60, '3.00', '2017-03-25', '2017-03-24', 1),
(5, 1, 1, 15, 40, '0.25', '2017-03-25', '2017-03-24', 1),
(6, 1, 1, 6, 60, '0.70', '2017-03-25', '2017-03-24', 1),
(7, 1, 1, 7, 30, '0.70', '2017-03-25', '2017-03-24', 1),
(8, 2, 1, 1, 10, '1.10', '2017-04-18', '2017-04-17', 1),
(9, 2, 1, 8, 20, '1.40', '2017-04-18', '2017-04-17', 1),
(10, 2, 1, 11, 16, '3.50', '2017-04-18', '2017-04-17', 1),
(11, 2, 1, 5, 75, '3.00', '2017-04-18', '2017-04-17', 1),
(12, 3, 1, 1, 20, '1.10', '2017-04-27', '2017-04-26', 1),
(13, 3, 1, 8, 30, '1.40', '2017-04-27', '2017-04-26', 1),
(14, 3, 1, 2, 5, '0.80', '2017-04-27', '2017-04-26', 1),
(15, 3, 1, 9, 10, '0.90', '2017-04-27', '2017-04-26', 1),
(16, 3, 1, 11, 10, '3.50', '2017-04-27', '2017-04-26', 1),
(17, 3, 1, 4, 25, '2.00', '2017-04-27', '2017-04-26', 1),
(18, 3, 1, 14, 50, '1.80', '2017-04-27', '2017-04-26', 1),
(19, 3, 1, 17, 150, '0.30', '2017-04-27', '2017-04-26', 1),
(20, 4, 2, 1, 150, '1.10', '2017-07-29', '2017-07-28', 1),
(21, 4, 2, 8, 39, '1.40', '2017-07-29', '2017-07-28', 1),
(22, 4, 2, 10, 15, '3.00', '2017-07-29', '2017-07-28', 1),
(23, 4, 2, 4, 50, '2.00', '2017-07-29', '2017-07-28', 1),
(24, 5, 2, 1, 80, '1.10', '2017-08-08', '2017-08-07', 1),
(25, 5, 2, 10, 15, '3.00', '2017-08-08', '2017-08-07', 1),
(26, 5, 2, 4, 20, '2.00', '2017-08-08', '2017-08-07', 1),
(27, 6, 2, 1, 50, '1.10', '2017-08-09', '2017-08-08', 1),
(28, 6, 2, 2, 20, '0.80', '2017-08-09', '2017-08-08', 1),
(29, 6, 2, 10, 25, '3.00', '2017-08-09', '2017-08-08', 1),
(30, 6, 2, 4, 20, '2.00', '2017-08-09', '2017-08-08', 1),
(31, 7, 2, 1, 100, '1.10', '2017-08-11', '2017-08-10', 1),
(32, 7, 2, 10, 25, '3.00', '2017-08-11', '2017-08-10', 1),
(33, 7, 2, 4, 80, '2.00', '2017-08-11', '2017-08-10', 1),
(34, 8, 2, 1, 80, '1.10', '2017-08-15', '2017-08-14', 1),
(35, 8, 2, 10, 25, '3.00', '2017-08-15', '2017-08-14', 1),
(36, 8, 2, 4, 70, '2.00', '2017-08-15', '2017-08-14', 1),
(37, 9, 2, 4, 60, '2.00', '2017-08-15', '2017-08-14', 1),
(38, 10, 2, 4, 200, '2.00', '2017-08-17', '2017-08-16', 1),
(39, 11, 2, 1, 200, '1.10', '2017-08-19', '2017-08-18', 1),
(40, 11, 2, 10, 50, '3.00', '2017-08-19', '2017-08-18', 1),
(41, 11, 2, 4, 100, '2.00', '2017-08-19', '2017-08-18', 1),
(42, 12, 2, 1, 150, '1.10', '2017-08-26', '2017-08-25', 1),
(43, 12, 2, 4, 100, '2.00', '2017-08-26', '2017-08-25', 1),
(44, 12, 2, 40, 3, '1.30', '2017-08-26', '2017-08-25', 1),
(45, 12, 2, 39, 35, '0.50', '2017-08-26', '2017-08-25', 1),
(46, 12, 2, 41, 4, '1.67', '2017-08-26', '2017-08-25', 1),
(47, 13, 2, 4, 100, '2.00', '2017-08-30', '2017-08-29', 1),
(48, 14, 2, 4, 200, '2.00', '2017-09-02', '2017-09-01', 1),
(49, 15, 2, 1, 200, '1.10', '2017-09-02', '2017-09-01', 1),
(50, 15, 2, 10, 35, '3.00', '2017-09-02', '2017-09-01', 1),
(51, 16, 3, 1, 10, '1.10', '2017-05-09', '2017-05-08', 1),
(52, 16, 3, 33, 650, '0.70', '2017-05-09', '2017-05-08', 1),
(53, 16, 3, 26, 300, '1.00', '2017-05-09', '2017-05-08', 1),
(54, 16, 3, 7, 130, '0.70', '2017-05-09', '2017-05-08', 1),
(55, 17, 3, 33, 500, '0.70', '2017-05-10', '2017-05-09', 1),
(56, 17, 3, 26, 300, '1.00', '2017-05-10', '2017-05-09', 1),
(57, 17, 3, 7, 200, '0.70', '2017-05-10', '2017-05-09', 1),
(58, 17, 3, 34, 150, '0.70', '2017-05-10', '2017-05-09', 1),
(59, 18, 3, 1, 340, '1.10', '2017-05-11', '2017-05-10', 1),
(60, 18, 3, 33, 450, '0.70', '2017-05-11', '2017-05-10', 1),
(61, 19, 3, 1, 200, '1.10', '2017-05-24', '2017-05-23', 1),
(62, 19, 3, 25, 24, '1.20', '2017-05-24', '2017-05-23', 1),
(63, 19, 3, 26, 160, '1.00', '2017-05-24', '2017-05-23', 1),
(64, 19, 3, 7, 200, '0.70', '2017-05-24', '2017-05-23', 1),
(65, 19, 3, 27, 142, '0.90', '2017-05-24', '2017-05-23', 1),
(66, 20, 3, 25, 190, '1.20', '2017-06-28', '2017-06-27', 1),
(67, 20, 3, 33, 850, '0.70', '2017-06-28', '2017-06-27', 1),
(68, 20, 3, 27, 90, '0.90', '2017-06-28', '2017-06-27', 1),
(69, 21, 4, 4, 40, '2.00', '2017-08-08', '2017-08-07', 1),
(70, 22, 5, 1, 1000, '1.00', '2017-08-05', '2017-08-04', 1),
(71, 23, 6, 1, 220, '1.10', '2017-08-10', '2017-08-09', 1),
(72, 23, 6, 2, 20, '0.80', '2017-08-10', '2017-08-09', 1),
(73, 23, 6, 10, 82, '3.00', '2017-08-10', '2017-08-09', 1),
(74, 23, 6, 5, 250, '3.00', '2017-08-10', '2017-08-09', 1),
(75, 23, 6, 3, 7, '4.00', '2017-08-10', '2017-08-09', 1),
(76, 23, 6, 11, 1, '3.50', '2017-08-10', '2017-08-09', 1),
(77, 24, 7, 14, 332, '1.80', '2017-07-24', '2017-07-23', 1),
(78, 24, 7, 18, 550, '0.30', '2017-07-24', '2017-07-23', 1),
(79, 24, 7, 13, 142, '1.00', '2017-07-24', '2017-07-23', 1),
(80, 24, 7, 16, 100, '0.25', '2017-07-24', '2017-07-23', 1),
(81, 24, 7, 17, 650, '0.30', '2017-07-24', '2017-07-23', 1),
(82, 25, 7, 14, 500, '1.80', '2017-09-15', '2017-09-14', 1),
(83, 25, 7, 17, 1000, '0.30', '2017-09-15', '2017-09-14', 1),
(84, 25, 7, 18, 200, '0.30', '2017-09-15', '2017-09-14', 1),
(85, 26, 8, 34, 400, '0.70', '2017-09-01', '2017-08-31', 1),
(86, 26, 8, 7, 50, '0.70', '2017-09-01', '2017-08-31', 1),
(87, 27, 9, 33, 225, '0.70', '2017-07-22', '2017-07-21', 1),
(88, 27, 9, 26, 260, '1.00', '2017-07-22', '2017-07-21', 1),
(89, 27, 9, 7, 90, '0.70', '2017-07-22', '2017-07-21', 1),
(90, 27, 9, 31, 420, '1.00', '2017-07-22', '2017-07-21', 1),
(91, 28, 9, 1, 184, '1.10', '2017-09-01', '2017-08-31', 1),
(92, 28, 9, 13, 8, '1.00', '2017-09-01', '2017-08-31', 1),
(93, 28, 9, 14, 32, '1.80', '2017-09-01', '2017-08-31', 1),
(94, 28, 9, 43, 40, '0.60', '2017-09-01', '2017-08-31', 1),
(95, 28, 9, 6, 170, '0.70', '2017-09-01', '2017-08-31', 1),
(96, 28, 9, 42, 85, '0.80', '2017-09-01', '2017-08-31', 1),
(97, 28, 9, 29, 40, '0.60', '2017-09-01', '2017-08-31', 1),
(98, 29, 9, 44, 85, '0.60', '2017-09-09', '2017-09-08', 1),
(99, 30, 10, 33, 150, '0.70', '2017-08-19', '2017-08-18', 1),
(100, 30, 10, 26, 200, '1.00', '2017-08-19', '2017-08-18', 1),
(101, 30, 10, 14, 10, '1.80', '2017-08-19', '2017-08-18', 1),
(102, 30, 10, 7, 36, '0.70', '2017-08-19', '2017-08-18', 1),
(103, 30, 10, 31, 280, '1.00', '2017-08-19', '2017-08-18', 1),
(104, 31, 10, 33, 80, '0.70', '2017-09-06', '2017-09-05', 1),
(105, 31, 10, 31, 60, '1.00', '2017-09-06', '2017-09-05', 1),
(106, 32, 11, 10, 62, '3.00', '2017-08-17', '2017-08-16', 1),
(107, 33, 11, 1, 300, '1.10', '2017-08-17', '2017-08-16', 1),
(108, 34, 11, 1, 300, '1.10', '2017-08-17', '2017-08-16', 1),
(109, 35, 11, 6, 1400, '0.70', '2017-08-17', '2017-08-16', 1),
(110, 36, 11, 10, 20, '3.00', '2017-08-18', '2017-08-17', 1),
(111, 36, 11, 1, 100, '1.10', '2017-08-18', '2017-08-17', 1),
(112, 36, 11, 6, 100, '0.70', '2017-08-18', '2017-08-17', 1),
(113, 37, 11, 10, 150, '3.00', '2017-08-19', '2017-08-18', 1),
(114, 38, 11, 45, 200, '2.50', '2017-08-21', '2017-08-20', 1),
(115, 38, 11, 19, 19, '2.50', '2017-08-21', '2017-08-20', 1),
(116, 38, 11, 20, 89, '4.50', '2017-08-21', '2017-08-20', 1),
(117, 39, 11, 45, 150, '2.50', '2017-08-21', '2017-08-20', 1),
(118, 40, 11, 45, 150, '2.50', '2017-08-22', '2017-08-21', 1),
(119, 40, 11, 46, 750, '0.30', '2017-08-22', '2017-08-21', 1),
(120, 41, 11, 10, 100, '3.00', '2017-08-22', '2017-08-21', 1),
(121, 42, 11, 45, 175, '2.50', '2017-08-23', '2017-08-22', 1),
(122, 43, 11, 45, 150, '2.50', '2017-08-23', '2017-08-22', 1),
(123, 44, 11, 45, 150, '2.50', '2017-08-23', '2017-08-22', 1),
(124, 45, 11, 45, 175, '2.50', '2017-08-25', '2017-08-24', 1),
(125, 46, 11, 45, 175, '2.50', '2017-08-25', '2017-08-24', 1),
(126, 47, 11, 10, 15, '3.00', '2017-08-25', '2017-08-24', 1),
(127, 47, 11, 45, 145, '2.50', '2017-08-25', '2017-08-24', 1),
(128, 48, 11, 45, 175, '2.50', '2017-08-26', '2017-08-25', 1),
(129, 49, 11, 45, 75, '2.50', '2017-08-26', '2017-08-25', 1),
(130, 49, 11, 11, 45, '3.50', '2017-08-26', '2017-08-25', 1),
(131, 50, 11, 10, 65, '3.00', '2017-08-29', '2017-08-28', 1),
(132, 50, 11, 45, 140, '2.50', '2017-08-29', '2017-08-28', 1),
(133, 50, 11, 19, 43, '2.50', '2017-08-29', '2017-08-28', 1),
(134, 50, 11, 20, 54, '4.50', '2017-08-29', '2017-08-28', 1),
(135, 51, 11, 45, 140, '2.50', '2017-08-29', '2017-08-28', 1),
(136, 52, 11, 10, 21, '3.00', '2017-09-01', '2017-08-31', 1),
(137, 52, 11, 46, 731, '0.30', '2017-09-01', '2017-08-31', 1),
(138, 53, 11, 10, 18, '3.00', '2017-09-04', '2017-09-03', 1),
(139, 53, 11, 1, 150, '1.10', '2017-09-04', '2017-09-03', 1),
(140, 53, 11, 11, 4, '3.50', '2017-09-04', '2017-09-03', 1),
(141, 54, 11, 6, 150, '0.70', '2017-09-07', '2017-09-06', 1),
(142, 54, 11, 17, 750, '0.30', '2017-09-07', '2017-09-06', 1),
(143, 55, 12, 26, 100, '1.00', '2017-06-30', '2017-06-29', 1),
(144, 55, 12, 33, 100, '0.70', '2017-06-30', '2017-06-29', 1),
(145, 55, 12, 31, 150, '1.00', '2017-06-30', '2017-06-29', 1),
(146, 55, 12, 15, 20, '0.25', '2017-06-30', '2017-06-29', 1),
(147, 56, 13, 26, 108, '1.00', '2017-04-22', '2017-04-21', 1),
(148, 56, 13, 33, 81, '0.70', '2017-04-22', '2017-04-21', 1),
(149, 56, 13, 31, 144, '1.00', '2017-04-22', '2017-04-21', 1),
(150, 56, 13, 7, 18, '0.70', '2017-04-22', '2017-04-21', 1),
(151, 57, 14, 28, 300, '0.80', '2017-07-29', '2017-07-28', 1),
(152, 57, 14, 6, 500, '0.70', '2017-07-29', '2017-07-28', 1),
(153, 57, 14, 47, 300, '0.60', '2017-07-29', '2017-07-28', 0),
(154, 57, 14, 16, 400, '0.25', '2017-07-29', '2017-07-28', 1),
(155, 58, 14, 28, 110, '0.80', '2017-07-31', '2017-07-30', 1),
(156, 58, 14, 27, 300, '0.90', '2017-07-31', '2017-07-30', 0),
(157, 58, 14, 6, 500, '0.70', '2017-07-31', '2017-07-30', 1),
(158, 58, 14, 16, 200, '0.25', '2017-07-31', '2017-07-30', 1),
(159, 59, 14, 28, 90, '0.80', '2017-08-01', '2017-07-31', 1),
(160, 59, 14, 27, 200, '0.90', '2017-08-01', '2017-07-31', 0),
(161, 59, 14, 16, 150, '0.25', '2017-08-01', '2017-07-31', 1),
(162, 57, 14, 47, 300, '0.00', '2017-07-29', '2017-07-28', 1),
(163, 58, 14, 27, 300, '0.80', '2017-07-31', '2017-07-30', 1),
(164, 59, 14, 27, 200, '0.80', '2017-08-01', '2017-07-31', 1),
(165, 60, 15, 26, 65, '1.00', '2017-09-16', '2017-09-15', 1),
(166, 60, 15, 33, 55, '0.70', '2017-09-16', '2017-09-15', 1),
(167, 60, 15, 31, 55, '1.00', '2017-09-16', '2017-09-15', 1),
(168, 60, 15, 13, 6, '1.00', '2017-09-16', '2017-09-15', 1),
(169, 60, 15, 48, 10, '1.00', '2017-09-16', '2017-09-15', 1),
(170, 60, 15, 18, 25, '0.30', '2017-09-16', '2017-09-15', 1),
(171, 60, 15, 7, 12, '0.70', '2017-09-16', '2017-09-15', 1),
(172, 61, 16, 4, 50, '1.66', '2017-02-03', '2017-02-02', 1),
(173, 62, 16, 4, 200, '1.66', '2017-03-17', '2017-03-16', 1),
(174, 63, 16, 4, 50, '1.66', '2017-03-25', '2017-03-24', 1),
(175, 64, 16, 4, 200, '1.66', '2017-03-29', '2017-03-28', 1),
(176, 65, 16, 1, 150, '0.90', '2017-03-29', '2017-03-28', 1),
(177, 65, 16, 10, 30, '2.66', '2017-03-29', '2017-03-28', 1),
(178, 65, 16, 5, 20, '2.66', '2017-03-29', '2017-03-28', 1),
(179, 66, 16, 1, 150, '0.90', '2017-03-30', '2017-03-29', 1),
(180, 66, 16, 4, 50, '1.66', '2017-03-30', '2017-03-29', 1),
(181, 66, 16, 5, 30, '2.66', '2017-03-30', '2017-03-29', 1),
(182, 67, 16, 2, 30, '0.70', '2017-04-08', '2017-04-07', 1),
(183, 67, 16, 9, 30, '0.80', '2017-04-08', '2017-04-07', 1),
(184, 68, 16, 4, 80, '1.66', '2017-05-16', '2017-05-15', 1),
(185, 32, 11, 10, 38, '0.00', '2017-08-17', '2017-08-16', 1),
(186, 49, 11, 10, 5, '0.00', '2017-08-26', '2017-08-25', 1),
(187, 69, 17, 4, 100, '2.00', '2017-06-26', '2017-06-25', 1),
(188, 70, 17, 1, 205, '1.10', '2017-06-27', '2017-06-26', 1),
(189, 70, 17, 2, 20, '0.80', '2017-06-27', '2017-06-26', 1),
(190, 70, 17, 10, 25, '3.00', '2017-06-27', '2017-06-26', 1),
(191, 70, 17, 10, 15, '3.00', '2017-06-27', '2017-06-26', 1),
(192, 71, 17, 4, 120, '2.00', '2017-06-28', '2017-06-27', 1),
(193, 72, 17, 4, 10, '2.00', '2017-08-11', '2017-08-10', 1),
(194, 72, 17, 11, 6, '3.50', '2017-08-11', '2017-08-10', 1),
(195, 72, 17, 1, 10, '0.00', '2017-08-11', '2017-08-10', 1),
(196, 73, 18, 31, 215, '0.70', '2017-07-17', '2017-07-16', 1),
(197, 73, 18, 28, 25, '1.00', '2017-07-17', '2017-07-16', 1),
(198, 73, 18, 7, 25, '0.70', '2017-07-17', '2017-07-16', 1),
(199, 73, 18, 26, 90, '1.00', '2017-07-17', '2017-07-16', 1),
(200, 74, 19, 10, 50, '3.00', '2017-08-19', '2017-08-18', 1),
(201, 74, 19, 33, 1200, '0.70', '2017-08-19', '2017-08-18', 1),
(202, 74, 19, 25, 700, '1.20', '2017-08-19', '2017-08-18', 1),
(203, 74, 19, 14, 50, '1.80', '2017-08-19', '2017-08-18', 1),
(204, 74, 19, 50, 150, '0.70', '2017-08-19', '2017-08-18', 1),
(205, 74, 19, 49, 200, '0.80', '2017-08-19', '2017-08-18', 1),
(206, 74, 19, 6, 50, '0.70', '2017-08-19', '2017-08-18', 1),
(207, 75, 20, 33, 1500, '0.70', '2017-09-07', '2017-09-06', 1),
(208, 75, 20, 26, 400, '1.00', '2017-09-07', '2017-09-06', 1),
(209, 75, 20, 31, 300, '1.00', '2017-09-07', '2017-09-06', 1),
(210, 75, 20, 50, 50, '0.80', '2017-09-07', '2017-09-06', 1),
(211, 76, 20, 31, 450, '1.00', '2017-09-08', '2017-09-07', 1),
(212, 76, 20, 50, 65, '0.80', '2017-09-08', '2017-09-07', 1),
(213, 77, 20, 33, 270, '0.70', '2017-09-09', '2017-09-08', 1),
(214, 77, 20, 26, 500, '1.00', '2017-09-09', '2017-09-08', 1),
(215, 77, 20, 31, 350, '1.00', '2017-09-09', '2017-09-08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_deposit`
--

CREATE TABLE `wp_shc_deposit` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `amt_times` int(2) NOT NULL,
  `total_thirty_days` decimal(15,2) NOT NULL,
  `total_ninety_days` decimal(15,2) NOT NULL,
  `deposit_date` datetime NOT NULL,
  `discount_avail` varchar(5) NOT NULL,
  `discount_percentage` decimal(10,2) NOT NULL,
  `discount_amt` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_deposit`
--

INSERT INTO `wp_shc_deposit` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `customer_id`, `site_id`, `amt_times`, `total_thirty_days`, `total_ninety_days`, `deposit_date`, `discount_avail`, `discount_percentage`, `discount_amt`, `total`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 3, 2016, 1, '', 1, 1, 1, 3, '319.50', '42705.00', '2017-03-30 06:21:00', 'no', '0.00', '0.00', '42705.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1, 1),
(2, 3, 2017, 1, '', 1, 1, 1, 3, '270.00', '28800.00', '2017-04-18 07:25:00', 'no', '0.00', '0.00', '28800.00', '2017-09-14 13:00:29', '0000-00-00 00:00:00', 1, 1),
(3, 3, 2017, 2, '', 1, 1, 1, 3, '354.00', '26730.00', '2017-04-27 07:34:00', 'no', '0.00', '0.00', '26730.00', '2017-09-14 13:07:08', '0000-00-00 00:00:00', 1, 1),
(4, 3, 2017, 3, '', 2, 3, 3, 2, '225.00', '22800.00', '2017-07-29 09:15:00', 'yes', '10.00', '2280.00', '20520.00', '2017-09-14 14:47:51', '0000-00-00 00:00:00', 1, 1),
(5, 3, 2017, 4, '', 2, 3, 3, 2, '207.00', '21540.00', '2017-08-08 09:17:00', 'yes', '10.00', '2154.00', '19386.00', '2017-09-14 14:49:04', '0000-00-00 00:00:00', 1, 1),
(6, 3, 2017, 5, '', 2, 3, 3, 2, '183.00', '20700.00', '2017-08-11 09:20:00', 'yes', '10.00', '2070.00', '18630.00', '2017-09-14 14:52:00', '0000-00-00 00:00:00', 1, 1),
(7, 3, 2017, 6, '', 2, 3, 3, 2, '183.00', '18180.00', '2017-08-14 09:22:00', 'yes', '10.00', '1818.00', '16362.00', '2017-09-14 14:55:14', '0000-00-00 00:00:00', 1, 1),
(8, 3, 2017, 7, '', 2, 3, 3, 2, '60.00', '7200.00', '2017-08-14 09:25:00', 'yes', '10.00', '720.00', '6480.00', '2017-09-14 14:56:55', '0000-00-00 00:00:00', 1, 1),
(9, 3, 2017, 8, '', 2, 3, 3, 2, '60.00', '24000.00', '2017-08-19 09:26:00', 'yes', '10.00', '2400.00', '21600.00', '2017-09-14 14:57:45', '0000-00-00 00:00:00', 1, 1),
(10, 3, 2017, 9, '', 2, 3, 3, 2, '183.00', '34200.00', '2017-08-19 09:27:00', 'yes', '10.00', '3420.00', '30780.00', '2017-09-14 14:58:42', '0000-00-00 00:00:00', 1, 1),
(11, 3, 2017, 10, '', 2, 3, 3, 2, '93.00', '21900.00', '2017-08-30 09:28:00', 'yes', '10.00', '2190.00', '19710.00', '2017-09-14 15:01:56', '0000-00-00 00:00:00', 1, 1),
(12, 3, 2017, 11, '', 2, 3, 3, 2, '164.10', '13684.80', '2017-08-30 10:21:00', 'yes', '10.00', '1368.48', '12316.32', '2017-09-14 16:04:43', '2017-09-14 16:04:57', 1, 1),
(13, 3, 2017, 12, '', 2, 3, 3, 2, '183.00', '43500.00', '2017-09-02 10:35:00', 'yes', '10.00', '4350.00', '39150.00', '2017-09-14 16:06:01', '0000-00-00 00:00:00', 1, 1),
(14, 3, 2017, 13, '', 3, 4, 4, 3, '126.00', '219690.00', '2017-05-18 11:40:00', 'no', '0.00', '0.00', '219690.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1, 1),
(15, 3, 2017, 14, '', 3, 4, 4, 3, '147.00', '60894.00', '2017-05-24 11:42:00', 'no', '0.00', '0.00', '60894.00', '2017-09-14 17:14:04', '0000-00-00 00:00:00', 1, 1),
(16, 3, 2017, 15, '', 4, 5, 5, 3, '60.00', '7200.00', '2017-08-08 05:26:00', 'no', '0.00', '0.00', '7200.00', '2017-09-15 11:05:59', '0000-00-00 00:00:00', 1, 1),
(17, 3, 2017, 16, '', 5, 6, 6, 3, '30.00', '90000.00', '2017-08-05 05:57:00', 'no', '0.00', '0.00', '90000.00', '2017-09-15 11:29:39', '0000-00-00 00:00:00', 1, 1),
(18, 3, 2017, 17, '', 6, 7, 7, 6, '357.00', '231480.00', '2017-08-08 07:15:00', 'yes', '10.00', '23148.00', '208332.00', '2017-09-15 12:57:36', '0000-00-00 00:00:00', 1, 1),
(19, 3, 2017, 18, '', 7, 8, 8, 3, '93.00', '100800.00', '2017-07-20 08:34:00', 'no', '0.00', '0.00', '100800.00', '2017-09-15 14:10:33', '0000-00-00 00:00:00', 1, 1),
(20, 3, 2017, 19, '', 7, 8, 8, 3, '63.00', '113400.00', '2017-09-12 08:42:00', 'no', '0.00', '0.00', '113400.00', '2017-09-15 14:16:49', '0000-00-00 00:00:00', 1, 1),
(21, 3, 2017, 20, '', 8, 9, 9, 4, '42.00', '37800.00', '2017-08-31 09:10:00', 'no', '0.00', '0.00', '37800.00', '2017-09-15 14:42:40', '0000-00-00 00:00:00', 1, 1),
(22, 3, 2017, 21, '', 9, 10, 10, 3, '102.00', '81045.00', '2017-07-20 09:23:00', 'no', '0.00', '0.00', '81045.00', '2017-09-15 14:55:39', '0000-00-00 00:00:00', 1, 1),
(23, 3, 2017, 22, '', 9, 10, 10, 3, '198.00', '45270.00', '2017-09-01 09:26:00', 'no', '0.00', '0.00', '45270.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1, 1),
(24, 3, 2017, 23, '', 10, 11, 11, 3, '156.00', '56538.00', '2017-08-21 10:07:00', 'no', '0.00', '0.00', '56538.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1, 1),
(25, 3, 2017, 24, '', 10, 11, 11, 3, '51.00', '10440.00', '2017-09-06 10:14:00', 'no', '0.00', '0.00', '10440.00', '2017-09-15 15:48:36', '0000-00-00 00:00:00', 1, 1),
(26, 3, 2017, 25, '', 11, 12, 12, 3, '438.00', '860760.00', '2017-08-16 10:27:00', 'yes', '10.00', '86076.00', '774684.00', '2017-09-15 16:26:40', '2017-09-15 16:32:18', 1, 1),
(27, 3, 2017, 26, '', 12, 13, 13, 3, '88.50', '29250.00', '2017-06-30 11:41:00', 'no', '0.00', '0.00', '29250.00', '2017-09-15 17:14:27', '0000-00-00 00:00:00', 1, 1),
(28, 3, 2017, 27, '', 13, 14, 14, 3, '102.00', '28917.00', '2017-04-22 04:30:00', 'no', '0.00', '0.00', '28917.00', '2017-09-25 10:05:43', '0000-00-00 00:00:00', 1, 1),
(29, 3, 2017, 28, '', 14, 15, 15, 3, '70.50', '142875.00', '2017-07-27 05:12:00', 'yes', '5.00', '7143.75', '135731.25', '2017-09-25 10:51:57', '0000-00-00 00:00:00', 1, 1),
(30, 1, 2017, 1, '', 15, 16, 16, 3, '171.00', '17136.00', '2017-09-14 06:11:00', 'no', '0.00', '0.00', '17136.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1, 1),
(31, 1, 2017, 2, '', 17, 18, 18, 2, '207.00', '48090.00', '2017-06-27 10:28:00', 'no', '0.00', '0.00', '48090.00', '2017-09-25 16:00:25', '0000-00-00 00:00:00', 1, 1),
(32, 1, 2017, 3, '', 18, 19, 19, 1, '102.00', '8490.00', '2017-07-08 11:33:00', 'no', '0.00', '0.00', '8490.00', '2017-09-25 17:10:22', '0000-00-00 00:00:00', 1, 1),
(33, 1, 2017, 4, '', 19, 20, 20, 4, '297.00', '247200.00', '2017-08-18 12:02:00', 'no', '0.00', '0.00', '247200.00', '2017-09-25 17:36:46', '0000-00-00 00:00:00', 1, 1),
(34, 1, 2017, 5, '', 20, 21, 21, 3, '102.00', '191565.00', '2017-09-05 12:21:00', 'no', '0.00', '0.00', '191565.00', '2017-09-25 17:53:04', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_deposit_cheque`
--

CREATE TABLE `wp_shc_deposit_cheque` (
  `id` int(11) NOT NULL,
  `master_id` int(11) NOT NULL,
  `deposit_id` int(11) NOT NULL,
  `cheque_no` varchar(255) NOT NULL,
  `cheque_date` date NOT NULL,
  `cheque_amount` decimal(10,0) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_deposit_cheque`
--

INSERT INTO `wp_shc_deposit_cheque` (`id`, `master_id`, `deposit_id`, `cheque_no`, `cheque_date`, `cheque_amount`, `active`) VALUES
(1, 1, 1, 'NEFT', '2017-03-31', '50055', 1),
(2, 1, 2, '0.00', '0000-00-00', '0', 1),
(3, 1, 3, '0.00', '0000-00-00', '0', 1),
(4, 2, 4, '0.00', '2017-07-29', '21000', 1),
(5, 2, 5, '0.00', '0000-00-00', '0', 1),
(6, 2, 6, '0.00', '0000-00-00', '0', 1),
(7, 2, 7, '0.00', '0000-00-00', '0', 1),
(8, 2, 8, '0.00', '0000-00-00', '0', 1),
(9, 2, 9, '0.00', '0000-00-00', '0', 1),
(10, 2, 10, '0.00', '0000-00-00', '0', 1),
(11, 2, 11, '0.00', '0000-00-00', '0', 1),
(12, 2, 12, '0.00', '0000-00-00', '0', 1),
(13, 2, 13, '0.00', '0000-00-00', '0', 1),
(14, 3, 14, '0.00', '0000-00-00', '0', 1),
(15, 3, 15, '0.00', '0000-00-00', '0', 1),
(16, 4, 16, '0.00', '0000-00-00', '0', 1),
(17, 5, 17, '0.00', '0000-00-00', '0', 1),
(18, 6, 18, '0.00', '0000-00-00', '0', 1),
(19, 7, 19, '0.00', '0000-00-00', '0', 1),
(20, 7, 20, '84469', '2017-09-13', '79000', 1),
(21, 8, 21, 'NEFT/KVB', '2017-09-01', '40450', 1),
(22, 9, 22, '166781', '2017-07-22', '86295', 1),
(23, 9, 23, '0.00', '0000-00-00', '0', 1),
(24, 10, 24, '0.00', '0000-00-00', '0', 1),
(25, 10, 25, '0.00', '0000-00-00', '0', 1),
(26, 11, 26, '0.00', '0000-00-00', '0', 1),
(27, 12, 27, '0.00', '0000-00-00', '0', 1),
(28, 13, 28, '0.00', '0000-00-00', '0', 1),
(29, 14, 29, 'NEFT', '2017-07-28', '142875', 1),
(30, 15, 30, 'IMPS', '2017-09-15', '18963', 1),
(31, 17, 31, '0.00', '0000-00-00', '0', 1),
(32, 18, 32, 'NEFT', '2017-07-15', '28720', 1),
(33, 19, 33, '0.00', '0000-00-00', '0', 1),
(34, 20, 34, '0.00', '0000-00-00', '0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_deposit_detail`
--

CREATE TABLE `wp_shc_deposit_detail` (
  `id` int(11) NOT NULL,
  `deposit_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `rate_thirty` decimal(15,2) NOT NULL,
  `rate_ninety` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_deposit_detail`
--

INSERT INTO `wp_shc_deposit_detail` (`id`, `deposit_id`, `lot_id`, `qty`, `unit_price`, `rate_thirty`, `rate_ninety`, `created_at`, `modified_at`, `active`) VALUES
(1, 1, 1, 20, '1.10', '33.00', '1980.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(2, 1, 8, 80, '1.40', '42.00', '10080.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(3, 1, 11, 25, '3.50', '105.00', '7875.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(4, 1, 5, 60, '3.00', '90.00', '16200.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(5, 1, 15, 40, '0.25', '7.50', '900.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(6, 1, 7, 30, '0.70', '21.00', '1890.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(7, 1, 6, 60, '0.70', '21.00', '3780.00', '2017-09-14 12:02:17', '0000-00-00 00:00:00', 1),
(8, 2, 1, 10, '1.10', '33.00', '990.00', '2017-09-14 13:00:29', '0000-00-00 00:00:00', 1),
(9, 2, 8, 20, '1.40', '42.00', '2520.00', '2017-09-14 13:00:29', '0000-00-00 00:00:00', 1),
(10, 2, 11, 16, '3.50', '105.00', '5040.00', '2017-09-14 13:00:29', '0000-00-00 00:00:00', 1),
(11, 2, 5, 75, '3.00', '90.00', '20250.00', '2017-09-14 13:00:29', '0000-00-00 00:00:00', 1),
(12, 3, 1, 20, '1.10', '33.00', '1980.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(13, 3, 8, 30, '1.40', '42.00', '3780.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(14, 3, 2, 5, '0.80', '24.00', '360.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(15, 3, 9, 10, '0.90', '27.00', '810.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(16, 3, 11, 10, '3.50', '105.00', '3150.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(17, 3, 4, 25, '2.00', '60.00', '4500.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(18, 3, 14, 50, '1.80', '54.00', '8100.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(19, 3, 17, 150, '0.30', '9.00', '4050.00', '2017-09-14 13:07:09', '0000-00-00 00:00:00', 1),
(20, 4, 1, 150, '1.10', '33.00', '9900.00', '2017-09-14 14:47:51', '2017-09-14 14:49:54', 1),
(21, 4, 8, 50, '1.40', '42.00', '4200.00', '2017-09-14 14:47:51', '2017-09-14 14:49:54', 1),
(22, 4, 10, 15, '3.00', '90.00', '2700.00', '2017-09-14 14:47:52', '2017-09-14 14:49:54', 1),
(23, 4, 4, 50, '2.00', '60.00', '6000.00', '2017-09-14 14:47:52', '2017-09-14 14:49:54', 1),
(24, 5, 1, 130, '1.10', '33.00', '8580.00', '2017-09-14 14:49:05', '2017-09-14 14:50:52', 1),
(25, 5, 2, 20, '0.80', '24.00', '960.00', '2017-09-14 14:49:05', '2017-09-14 14:50:52', 1),
(26, 5, 10, 40, '3.00', '90.00', '7200.00', '2017-09-14 14:49:05', '2017-09-14 14:50:52', 1),
(27, 5, 4, 40, '2.00', '60.00', '4800.00', '2017-09-14 14:49:05', '2017-09-14 14:50:52', 1),
(28, 6, 1, 100, '1.10', '33.00', '6600.00', '2017-09-14 14:52:00', '0000-00-00 00:00:00', 1),
(29, 6, 10, 25, '3.00', '90.00', '4500.00', '2017-09-14 14:52:00', '0000-00-00 00:00:00', 1),
(30, 6, 4, 80, '2.00', '60.00', '9600.00', '2017-09-14 14:52:00', '0000-00-00 00:00:00', 1),
(31, 7, 1, 80, '1.10', '33.00', '5280.00', '2017-09-14 14:55:14', '0000-00-00 00:00:00', 1),
(32, 7, 10, 25, '3.00', '90.00', '4500.00', '2017-09-14 14:55:14', '0000-00-00 00:00:00', 1),
(33, 7, 4, 70, '2.00', '60.00', '8400.00', '2017-09-14 14:55:14', '0000-00-00 00:00:00', 1),
(34, 8, 4, 60, '2.00', '60.00', '7200.00', '2017-09-14 14:56:55', '0000-00-00 00:00:00', 1),
(35, 9, 4, 200, '2.00', '60.00', '24000.00', '2017-09-14 14:57:45', '0000-00-00 00:00:00', 1),
(36, 10, 1, 200, '1.10', '33.00', '13200.00', '2017-09-14 14:58:42', '0000-00-00 00:00:00', 1),
(37, 10, 10, 50, '3.00', '90.00', '9000.00', '2017-09-14 14:58:42', '0000-00-00 00:00:00', 1),
(38, 10, 4, 100, '2.00', '60.00', '12000.00', '2017-09-14 14:58:42', '0000-00-00 00:00:00', 1),
(39, 11, 1, 150, '1.10', '33.00', '9900.00', '2017-09-14 15:01:57', '0000-00-00 00:00:00', 1),
(40, 11, 4, 100, '2.00', '60.00', '12000.00', '2017-09-14 15:01:57', '0000-00-00 00:00:00', 1),
(41, 12, 40, 3, '1.30', '39.00', '234.00', '2017-09-14 16:04:43', '2017-09-14 16:04:58', 1),
(42, 12, 4, 100, '2.00', '60.00', '12000.00', '2017-09-14 16:04:43', '2017-09-14 16:04:58', 1),
(43, 12, 39, 35, '0.50', '15.00', '1050.00', '2017-09-14 16:04:43', '2017-09-14 16:04:58', 1),
(44, 12, 41, 4, '1.67', '50.10', '400.80', '2017-09-14 16:04:43', '2017-09-14 16:04:58', 1),
(45, 13, 1, 200, '1.10', '33.00', '13200.00', '2017-09-14 16:06:01', '0000-00-00 00:00:00', 1),
(46, 13, 10, 35, '3.00', '90.00', '6300.00', '2017-09-14 16:06:01', '0000-00-00 00:00:00', 1),
(47, 13, 4, 200, '2.00', '60.00', '24000.00', '2017-09-14 16:06:01', '0000-00-00 00:00:00', 1),
(48, 14, 1, 350, '1.10', '33.00', '34650.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1),
(49, 14, 26, 600, '1.00', '30.00', '54000.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1),
(50, 14, 33, 1600, '0.70', '21.00', '100800.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1),
(51, 14, 34, 150, '0.70', '21.00', '9450.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1),
(52, 14, 7, 330, '0.70', '21.00', '20790.00', '2017-09-14 17:12:35', '0000-00-00 00:00:00', 1),
(53, 15, 1, 200, '1.10', '33.00', '19800.00', '2017-09-14 17:14:05', '0000-00-00 00:00:00', 1),
(54, 15, 26, 160, '1.00', '30.00', '14400.00', '2017-09-14 17:14:05', '0000-00-00 00:00:00', 1),
(55, 15, 25, 24, '1.20', '36.00', '2592.00', '2017-09-14 17:14:05', '0000-00-00 00:00:00', 1),
(56, 15, 27, 142, '0.90', '27.00', '11502.00', '2017-09-14 17:14:05', '0000-00-00 00:00:00', 1),
(57, 15, 7, 200, '0.70', '21.00', '12600.00', '2017-09-14 17:14:05', '0000-00-00 00:00:00', 1),
(58, 16, 4, 40, '2.00', '60.00', '7200.00', '2017-09-15 11:06:00', '0000-00-00 00:00:00', 1),
(59, 17, 1, 1000, '1.00', '30.00', '90000.00', '2017-09-15 11:29:40', '0000-00-00 00:00:00', 1),
(60, 18, 1, 220, '1.10', '33.00', '43560.00', '2017-09-15 12:57:37', '0000-00-00 00:00:00', 1),
(61, 18, 2, 20, '0.80', '24.00', '2880.00', '2017-09-15 12:57:37', '0000-00-00 00:00:00', 1),
(62, 18, 5, 250, '3.00', '90.00', '135000.00', '2017-09-15 12:57:37', '0000-00-00 00:00:00', 1),
(63, 18, 10, 82, '3.00', '90.00', '44280.00', '2017-09-15 12:57:37', '0000-00-00 00:00:00', 1),
(64, 18, 3, 8, '4.00', '120.00', '5760.00', '2017-09-15 12:57:37', '0000-00-00 00:00:00', 1),
(65, 19, 14, 400, '1.80', '54.00', '64800.00', '2017-09-15 14:10:34', '0000-00-00 00:00:00', 1),
(66, 19, 13, 100, '1.00', '30.00', '9000.00', '2017-09-15 14:10:34', '0000-00-00 00:00:00', 1),
(67, 19, 17, 1000, '0.30', '9.00', '27000.00', '2017-09-15 14:10:34', '0000-00-00 00:00:00', 1),
(68, 20, 14, 500, '1.80', '54.00', '81000.00', '2017-09-15 14:16:50', '0000-00-00 00:00:00', 1),
(69, 20, 17, 1200, '0.30', '9.00', '32400.00', '2017-09-15 14:16:50', '0000-00-00 00:00:00', 1),
(70, 21, 34, 400, '0.70', '21.00', '33600.00', '2017-09-15 14:42:41', '0000-00-00 00:00:00', 1),
(71, 21, 7, 50, '0.70', '21.00', '4200.00', '2017-09-15 14:42:41', '0000-00-00 00:00:00', 1),
(72, 22, 26, 260, '1.00', '30.00', '23400.00', '2017-09-15 14:55:39', '0000-00-00 00:00:00', 1),
(73, 22, 31, 420, '1.00', '30.00', '37800.00', '2017-09-15 14:55:39', '0000-00-00 00:00:00', 1),
(74, 22, 33, 225, '0.70', '21.00', '14175.00', '2017-09-15 14:55:39', '0000-00-00 00:00:00', 1),
(75, 22, 7, 90, '0.70', '21.00', '5670.00', '2017-09-15 14:55:39', '0000-00-00 00:00:00', 1),
(76, 23, 1, 184, '1.10', '33.00', '18216.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(77, 23, 14, 32, '1.80', '54.00', '5184.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(78, 23, 13, 8, '1.00', '30.00', '720.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(79, 23, 42, 85, '0.80', '24.00', '6120.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(80, 23, 43, 40, '0.60', '18.00', '2160.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(81, 23, 29, 40, '0.60', '18.00', '2160.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(82, 23, 6, 170, '0.70', '21.00', '10710.00', '2017-09-15 15:10:41', '0000-00-00 00:00:00', 1),
(83, 24, 26, 200, '1.00', '30.00', '18000.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1),
(84, 24, 33, 150, '0.70', '21.00', '9450.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1),
(85, 24, 31, 280, '1.00', '30.00', '25200.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1),
(86, 24, 14, 10, '1.80', '54.00', '1620.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1),
(87, 24, 7, 36, '0.70', '21.00', '2268.00', '2017-09-15 15:38:41', '0000-00-00 00:00:00', 1),
(88, 25, 33, 80, '0.70', '21.00', '5040.00', '2017-09-15 15:48:36', '0000-00-00 00:00:00', 1),
(89, 25, 31, 60, '1.00', '30.00', '5400.00', '2017-09-15 15:48:36', '0000-00-00 00:00:00', 1),
(90, 26, 1, 700, '1.10', '33.00', '69300.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(91, 26, 45, 2000, '2.50', '75.00', '450000.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(92, 26, 10, 500, '3.00', '90.00', '135000.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(93, 26, 20, 152, '4.50', '135.00', '61560.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(94, 26, 19, 44, '2.50', '75.00', '9900.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(95, 26, 6, 1500, '0.70', '21.00', '94500.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(96, 26, 46, 1500, '0.30', '9.00', '40500.00', '2017-09-15 16:26:40', '0000-00-00 00:00:00', 1),
(97, 27, 26, 100, '1.00', '30.00', '9000.00', '2017-09-15 17:14:27', '0000-00-00 00:00:00', 1),
(98, 27, 33, 100, '0.70', '21.00', '6300.00', '2017-09-15 17:14:27', '0000-00-00 00:00:00', 1),
(99, 27, 31, 150, '1.00', '30.00', '13500.00', '2017-09-15 17:14:27', '0000-00-00 00:00:00', 1),
(100, 27, 15, 20, '0.25', '7.50', '450.00', '2017-09-15 17:14:27', '0000-00-00 00:00:00', 1),
(101, 28, 26, 108, '1.00', '30.00', '9720.00', '2017-09-25 10:05:43', '0000-00-00 00:00:00', 1),
(102, 28, 31, 144, '1.00', '30.00', '12960.00', '2017-09-25 10:05:44', '0000-00-00 00:00:00', 1),
(103, 28, 33, 81, '0.70', '21.00', '5103.00', '2017-09-25 10:05:44', '0000-00-00 00:00:00', 1),
(104, 28, 7, 18, '0.70', '21.00', '1134.00', '2017-09-25 10:05:44', '0000-00-00 00:00:00', 1),
(105, 29, 28, 500, '0.80', '24.00', '36000.00', '2017-09-25 10:51:58', '2017-09-25 11:01:41', 1),
(106, 29, 6, 1000, '0.70', '21.00', '63000.00', '2017-09-25 10:51:58', '2017-09-25 11:01:41', 1),
(107, 29, 47, 500, '0.60', '18.00', '27000.00', '2017-09-25 10:51:58', '2017-09-25 11:01:41', 1),
(108, 29, 16, 750, '0.25', '7.50', '16875.00', '2017-09-25 10:51:58', '2017-09-25 11:01:41', 1),
(109, 30, 26, 65, '1.00', '30.00', '5850.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(110, 30, 33, 55, '0.70', '21.00', '3465.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(111, 30, 31, 55, '1.00', '30.00', '4950.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(112, 30, 7, 12, '0.70', '21.00', '756.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(113, 30, 48, 10, '1.00', '30.00', '900.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(114, 30, 18, 25, '0.30', '9.00', '675.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(115, 30, 13, 6, '1.00', '30.00', '540.00', '2017-09-25 11:47:04', '0000-00-00 00:00:00', 1),
(116, 31, 1, 205, '1.10', '33.00', '13530.00', '2017-09-25 16:00:25', '0000-00-00 00:00:00', 1),
(117, 31, 2, 20, '0.80', '24.00', '960.00', '2017-09-25 16:00:25', '0000-00-00 00:00:00', 1),
(118, 31, 10, 40, '3.00', '90.00', '7200.00', '2017-09-25 16:00:25', '0000-00-00 00:00:00', 1),
(119, 31, 4, 220, '2.00', '60.00', '26400.00', '2017-09-25 16:00:25', '0000-00-00 00:00:00', 1),
(120, 32, 26, 90, '1.00', '30.00', '2700.00', '2017-09-25 17:10:22', '0000-00-00 00:00:00', 1),
(121, 32, 28, 25, '1.00', '30.00', '750.00', '2017-09-25 17:10:22', '0000-00-00 00:00:00', 1),
(122, 32, 31, 215, '0.70', '21.00', '4515.00', '2017-09-25 17:10:22', '0000-00-00 00:00:00', 1),
(123, 32, 7, 25, '0.70', '21.00', '525.00', '2017-09-25 17:10:22', '0000-00-00 00:00:00', 1),
(124, 33, 25, 700, '1.20', '36.00', '100800.00', '2017-09-25 17:36:46', '0000-00-00 00:00:00', 1),
(125, 33, 33, 400, '0.70', '21.00', '33600.00', '2017-09-25 17:36:46', '0000-00-00 00:00:00', 1),
(126, 33, 31, 400, '1.00', '30.00', '48000.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(127, 33, 10, 50, '3.00', '90.00', '18000.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(128, 33, 49, 200, '0.80', '24.00', '19200.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(129, 33, 6, 50, '0.70', '21.00', '4200.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(130, 33, 7, 150, '0.70', '21.00', '12600.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(131, 33, 14, 50, '1.80', '54.00', '10800.00', '2017-09-25 17:36:47', '0000-00-00 00:00:00', 1),
(132, 34, 26, 700, '1.00', '30.00', '63000.00', '2017-09-25 17:53:05', '0000-00-00 00:00:00', 1),
(133, 34, 33, 640, '0.70', '21.00', '40320.00', '2017-09-25 17:53:05', '0000-00-00 00:00:00', 1),
(134, 34, 31, 900, '1.00', '30.00', '81000.00', '2017-09-25 17:53:05', '0000-00-00 00:00:00', 1),
(135, 34, 7, 115, '0.70', '21.00', '7245.00', '2017-09-25 17:53:05', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_employees`
--

CREATE TABLE `wp_shc_employees` (
  `id` int(11) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_mobile` varchar(100) NOT NULL,
  `emp_address` text NOT NULL,
  `emp_salary` decimal(9,2) NOT NULL,
  `emp_joining` datetime NOT NULL,
  `emp_created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emp_modified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `emp_current_status` int(2) NOT NULL DEFAULT '1',
  `updated_by` int(11) NOT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_employee_attendance`
--

CREATE TABLE `wp_shc_employee_attendance` (
  `id` int(11) NOT NULL,
  `emp_id` int(20) NOT NULL,
  `emp_attendance` int(2) NOT NULL,
  `attendance_date` datetime DEFAULT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_hiring`
--

CREATE TABLE `wp_shc_hiring` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `bill_from` date NOT NULL,
  `bill_to` date NOT NULL,
  `return_ids` text NOT NULL,
  `transportation_charge` decimal(15,2) NOT NULL,
  `damage_charge` decimal(15,2) NOT NULL,
  `lost_charge` decimal(15,2) NOT NULL,
  `sub_tot` decimal(15,2) NOT NULL,
  `discount_avail` varchar(5) NOT NULL,
  `discount_percentage` decimal(10,2) NOT NULL,
  `discount_amount` decimal(15,2) NOT NULL,
  `total_after_discount` decimal(15,2) NOT NULL,
  `total_before_tax` decimal(15,2) NOT NULL,
  `tax_from` varchar(10) NOT NULL,
  `gst_for` varchar(20) NOT NULL,
  `igst_amt` decimal(15,2) NOT NULL,
  `cgst_amt` decimal(15,2) NOT NULL,
  `sgst_amt` decimal(15,2) NOT NULL,
  `vat_amt` decimal(15,2) NOT NULL,
  `tax_include_tot` decimal(15,2) NOT NULL,
  `round_off` decimal(15,2) NOT NULL,
  `hiring_total` decimal(15,2) NOT NULL,
  `bill_date` date NOT NULL,
  `bill_time` time NOT NULL,
  `payment_date` date NOT NULL,
  `bill_status` int(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_hiring`
--

INSERT INTO `wp_shc_hiring` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `bill_from`, `bill_to`, `return_ids`, `transportation_charge`, `damage_charge`, `lost_charge`, `sub_tot`, `discount_avail`, `discount_percentage`, `discount_amount`, `total_after_discount`, `total_before_tax`, `tax_from`, `gst_for`, `igst_amt`, `cgst_amt`, `sgst_amt`, `vat_amt`, `tax_include_tot`, `round_off`, `hiring_total`, `bill_date`, `bill_time`, `payment_date`, `bill_status`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 3, 2017, 1, '', 1, '2017-03-25', '2017-04-30', '', '0.00', '0.00', '0.00', '22904.50', 'yes', '5.00', '1145.23', '21759.27', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '1087.96', '22847.23', '0.23', '22847.00', '2017-04-30', '07:06:00', '0000-00-00', 1, '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1, 1),
(2, 3, 2017, 2, '', 1, '2017-05-01', '2017-05-31', '', '0.00', '0.00', '0.00', '33836.50', 'no', '0.00', '0.00', '33836.50', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '1691.83', '35528.33', '0.33', '35528.00', '2017-05-31', '07:11:00', '0000-00-00', 1, '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1, 1),
(3, 3, 2017, 3, '', 1, '2017-06-01', '2017-06-30', '', '0.00', '0.00', '0.00', '32745.00', 'no', '0.00', '0.00', '32745.00', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '1637.25', '34382.25', '0.25', '34382.00', '2017-06-30', '07:12:00', '0000-00-00', 1, '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1, 1),
(4, 3, 2017, 4, '', 1, '2017-07-01', '2017-07-31', '', '0.00', '0.00', '0.00', '33836.50', 'no', '0.00', '0.00', '33836.50', '0.00', 'gst', 'cgst', '0.00', '3045.28', '3045.28', '0.00', '39927.06', '0.06', '39927.00', '2017-07-31', '07:12:00', '0000-00-00', 1, '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1, 1),
(5, 3, 2017, 5, '', 1, '2017-08-01', '2017-08-31', '1', '100.00', '0.00', '0.00', '33624.90', 'no', '0.00', '0.00', '33624.90', '0.00', 'gst', 'cgst', '0.00', '3026.24', '3026.24', '0.00', '39677.38', '0.38', '39677.00', '2017-08-31', '07:13:00', '0000-00-00', 1, '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1, 1),
(6, 3, 2017, 6, '', 2, '2017-07-29', '2017-08-31', '', '0.00', '0.00', '0.00', '51430.88', 'no', '0.00', '0.00', '51430.88', '0.00', 'gst', 'cgst', '0.00', '4628.78', '4628.78', '0.00', '60688.44', '0.00', '60688.44', '2017-08-31', '11:17:00', '0000-00-00', 1, '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1, 1),
(7, 3, 2017, 7, '', 3, '2017-05-09', '2017-05-31', '', '0.00', '0.00', '0.00', '59282.80', 'no', '0.00', '0.00', '59282.80', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '2964.14', '62246.94', '-0.06', '62247.00', '2017-05-31', '04:23:00', '0000-00-00', 1, '2017-09-15 09:54:43', '0000-00-00 00:00:00', 1, 1),
(8, 3, 2017, 8, '', 3, '2017-06-01', '2017-06-30', '', '0.00', '0.00', '0.00', '96240.00', 'no', '0.00', '0.00', '96240.00', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '4812.00', '101052.00', '0.00', '101052.00', '2017-06-30', '04:25:00', '0000-00-00', 1, '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1, 1),
(9, 3, 2017, 9, '', 3, '2017-07-01', '2017-07-31', '2, 3', '0.00', '0.00', '0.00', '100699.30', 'no', '0.00', '0.00', '100699.30', '0.00', 'gst', 'cgst', '0.00', '9062.94', '9062.94', '0.00', '118825.18', '0.18', '118825.00', '2017-07-31', '06:47:00', '0000-00-00', 1, '2017-09-15 10:01:02', '2017-09-15 12:17:56', 1, 1),
(10, 3, 2017, 10, '', 3, '2017-08-01', '2017-08-31', '4, 5', '0.00', '0.00', '0.00', '67730.70', 'no', '0.00', '0.00', '67730.70', '0.00', 'gst', 'cgst', '0.00', '6095.76', '6095.76', '0.00', '79922.22', '0.00', '79922.22', '2017-08-31', '06:48:00', '0000-00-00', 1, '2017-09-15 10:40:22', '2017-09-15 12:19:42', 1, 1),
(11, 3, 2017, 11, '', 4, '2017-08-01', '2017-08-31', '', '0.00', '0.00', '0.00', '1920.00', 'no', '0.00', '0.00', '1920.00', '0.00', 'gst', 'cgst', '0.00', '172.80', '172.80', '0.00', '2265.60', '-0.40', '2266.00', '2017-08-31', '05:45:00', '0000-00-00', 1, '2017-09-15 11:16:35', '0000-00-00 00:00:00', 1, 1),
(12, 3, 2017, 12, 'JBC/HB-020', 5, '2017-08-05', '2017-08-31', '', '0.00', '0.00', '0.00', '27000.00', 'no', '0.00', '0.00', '27000.00', '0.00', 'gst', 'igst', '4860.00', '0.00', '0.00', '0.00', '31860.00', '0.00', '31860.00', '2017-08-31', '06:00:00', '0000-00-00', 1, '2017-09-15 11:32:16', '0000-00-00 00:00:00', 1, 1),
(13, 3, 2017, 13, '', 3, '2017-09-01', '2017-09-04', '6, 7, 8', '6200.00', '0.00', '0.00', '11708.00', 'no', '0.00', '0.00', '11708.00', '0.00', 'gst', 'cgst', '0.00', '1053.72', '1053.72', '0.00', '13815.44', '0.00', '13815.44', '2017-09-04', '06:53:00', '0000-00-00', 1, '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1, 1),
(14, 3, 2017, 14, '', 6, '2017-08-10', '2017-08-31', '', '0.00', '0.00', '0.00', '28281.00', 'yes', '10.00', '2828.10', '25452.90', '0.00', 'gst', 'cgst', '0.00', '2290.76', '2290.76', '0.00', '30034.42', '0.42', '30034.00', '2017-08-31', '08:18:00', '0000-00-00', 1, '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1, 1),
(15, 3, 2017, 15, '', 7, '2017-07-24', '2017-08-31', '', '0.00', '0.00', '0.00', '43859.40', 'no', '0.00', '0.00', '43859.40', '0.00', 'gst', 'cgst', '0.00', '3947.35', '3947.35', '0.00', '51754.10', '0.00', '51754.10', '2017-08-31', '09:01:00', '0000-00-00', 1, '2017-09-15 14:32:00', '0000-00-00 00:00:00', 1, 1),
(16, 3, 2017, 16, '', 9, '2017-07-22', '2017-08-31', '', '0.00', '0.00', '0.00', '36920.50', 'no', '0.00', '0.00', '36920.50', '0.00', 'gst', 'cgst', '0.00', '3322.84', '3322.84', '0.00', '43566.18', '0.18', '43566.00', '2017-08-31', '09:47:00', '0000-00-00', 1, '2017-09-15 15:18:27', '0000-00-00 00:00:00', 1, 1),
(17, 3, 2017, 17, '', 13, '2017-04-22', '2017-05-31', '', '0.00', '0.00', '0.00', '12852.00', 'no', '0.00', '0.00', '12852.00', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '642.60', '13494.60', '0.60', '13494.00', '2017-05-31', '04:43:00', '0000-00-00', 1, '2017-09-25 10:14:39', '0000-00-00 00:00:00', 1, 1),
(18, 3, 2017, 18, '', 13, '2017-06-01', '2017-06-16', '9', '350.00', '0.00', '0.00', '5490.80', 'no', '0.00', '0.00', '5490.80', '0.00', 'vat', 'cgst', '0.00', '0.00', '0.00', '274.54', '5765.34', '0.00', '5765.34', '2017-06-19', '04:57:00', '0000-00-00', 1, '2017-09-25 10:17:47', '2017-09-25 10:27:55', 1, 1),
(19, 1, 2016, 1, '', 16, '2017-03-02', '2017-03-31', '', '0.00', '0.00', '0.00', '10446.60', 'no', '0.00', '0.00', '10446.60', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '10446.60', '-0.40', '10447.00', '2017-03-31', '06:52:00', '0000-00-00', 1, '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1, 1),
(20, 1, 2017, 1, '', 16, '2017-04-01', '2017-04-30', '', '0.00', '0.00', '0.00', '42909.00', 'no', '0.00', '0.00', '42909.00', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '42909.00', '0.00', '42909.00', '2017-04-30', '06:56:00', '0000-00-00', 1, '2017-09-25 12:26:44', '0000-00-00 00:00:00', 1, 1),
(21, 1, 2017, 2, '', 16, '2017-05-01', '2017-05-31', '11', '100.00', '0.00', '0.00', '44894.60', 'no', '0.00', '0.00', '44894.60', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '44894.60', '0.60', '44894.00', '2017-05-31', '06:56:00', '0000-00-00', 1, '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1, 1),
(22, 3, 2017, 19, '', 11, '2017-08-17', '2017-09-18', '16, 17', '0.00', '0.00', '0.00', '267051.90', 'yes', '10.00', '26705.19', '240346.71', '0.00', 'gst', 'cgst', '0.00', '21631.20', '21631.20', '0.00', '283609.11', '0.11', '283609.00', '2017-09-18', '09:22:00', '0000-00-00', 1, '2017-09-25 14:53:06', '0000-00-00 00:00:00', 1, 1),
(23, 1, 2017, 3, '', 17, '2017-06-26', '2017-07-31', '18', '0.00', '0.00', '0.00', '27805.50', 'no', '0.00', '0.00', '27805.50', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '27805.50', '-0.50', '27806.00', '2017-07-31', '11:01:00', '0000-00-00', 1, '2017-09-25 16:27:02', '2017-09-25 16:33:01', 1, 1),
(24, 1, 2017, 4, '', 17, '2017-08-01', '2017-08-31', '19', '250.00', '0.00', '0.00', '25678.50', 'no', '0.00', '0.00', '25678.50', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '25678.50', '-0.50', '25679.00', '2017-08-31', '11:24:00', '0000-00-00', 1, '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1, 1),
(25, 1, 2017, 5, '', 18, '2017-07-17', '2017-08-31', '', '0.00', '0.00', '0.00', '13018.00', 'no', '0.00', '0.00', '13018.00', '0.00', 'no_tax', 'cgst', '0.00', '0.00', '0.00', '0.00', '13018.00', '0.00', '13018.00', '2017-08-31', '11:49:00', '0000-00-00', 1, '2017-09-25 17:19:56', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_hiring_detail`
--

CREATE TABLE `wp_shc_hiring_detail` (
  `id` int(11) NOT NULL,
  `hiring_bill_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `bill_from` date NOT NULL,
  `bill_to` date NOT NULL,
  `bill_days` int(11) NOT NULL,
  `delivery_date` date NOT NULL,
  `total_days` int(11) NOT NULL,
  `rate_per_day` decimal(15,2) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `got_return` int(1) NOT NULL,
  `min_checkbox_avail` int(1) NOT NULL,
  `min_checked` int(1) NOT NULL,
  `hiring_amt` decimal(15,2) NOT NULL,
  `hiring_amt_min` decimal(15,2) NOT NULL,
  `for_thirty_days` decimal(15,2) NOT NULL,
  `previous_paid` decimal(15,2) NOT NULL,
  `bal_to_pay` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_hiring_detail`
--

INSERT INTO `wp_shc_hiring_detail` (`id`, `hiring_bill_id`, `delivery_detail_id`, `lot_id`, `qty`, `bill_from`, `bill_to`, `bill_days`, `delivery_date`, `total_days`, `rate_per_day`, `amount`, `got_return`, `min_checkbox_avail`, `min_checked`, `hiring_amt`, `hiring_amt_min`, `for_thirty_days`, `previous_paid`, `bal_to_pay`, `created_at`, `modified_at`, `active`) VALUES
(1, 1, 12, 1, 20, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '1.10', '88.00', 0, 0, 0, '88.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(2, 1, 8, 1, 10, '2017-04-18', '2017-04-30', 13, '0000-00-00', 0, '1.10', '143.00', 0, 0, 0, '143.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(3, 1, 1, 1, 20, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '1.10', '814.00', 0, 0, 0, '814.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(4, 1, 14, 2, 5, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '0.80', '16.00', 0, 0, 0, '16.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(5, 1, 17, 4, 25, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '2.00', '200.00', 0, 0, 0, '200.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(6, 1, 11, 5, 75, '2017-04-18', '2017-04-30', 13, '0000-00-00', 0, '3.00', '2925.00', 0, 0, 0, '2925.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(7, 1, 4, 5, 60, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '3.00', '6660.00', 0, 0, 0, '6660.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(8, 1, 6, 6, 60, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '0.70', '1554.00', 0, 0, 0, '1554.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(9, 1, 7, 7, 30, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '0.70', '777.00', 0, 0, 0, '777.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(10, 1, 13, 8, 30, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '1.40', '168.00', 0, 0, 0, '168.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(11, 1, 9, 8, 20, '2017-04-18', '2017-04-30', 13, '0000-00-00', 0, '1.40', '364.00', 0, 0, 0, '364.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(12, 1, 2, 8, 80, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '1.40', '4144.00', 0, 0, 0, '4144.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(13, 1, 15, 9, 10, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '0.90', '36.00', 0, 0, 0, '36.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(14, 1, 16, 11, 10, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '3.50', '140.00', 0, 0, 0, '140.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(15, 1, 10, 11, 16, '2017-04-18', '2017-04-30', 13, '0000-00-00', 0, '3.50', '728.00', 0, 0, 0, '728.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(16, 1, 3, 11, 25, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '3.50', '3237.50', 0, 0, 0, '3237.50', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(17, 1, 18, 14, 50, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '1.80', '360.00', 0, 0, 0, '360.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(18, 1, 5, 15, 40, '2017-03-25', '2017-04-30', 37, '0000-00-00', 0, '0.25', '370.00', 0, 0, 0, '370.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(19, 1, 19, 17, 150, '2017-04-27', '2017-04-30', 4, '0000-00-00', 0, '0.30', '180.00', 0, 0, 0, '180.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:39:15', '0000-00-00 00:00:00', 1),
(20, 2, 1, 1, 50, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '1.10', '1705.00', 0, 0, 0, '1705.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(21, 2, 14, 2, 5, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.80', '124.00', 0, 0, 0, '124.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(22, 2, 17, 4, 25, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '2.00', '1550.00', 0, 0, 0, '1550.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(23, 2, 4, 5, 135, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '3.00', '12555.00', 0, 0, 0, '12555.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(24, 2, 6, 6, 60, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.70', '1302.00', 0, 0, 0, '1302.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(25, 2, 7, 7, 30, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.70', '651.00', 0, 0, 0, '651.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(26, 2, 2, 8, 130, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '1.40', '5642.00', 0, 0, 0, '5642.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(27, 2, 15, 9, 10, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.90', '279.00', 0, 0, 0, '279.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(28, 2, 3, 11, 51, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '3.50', '5533.50', 0, 0, 0, '5533.50', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(29, 2, 18, 14, 50, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '1.80', '2790.00', 0, 0, 0, '2790.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(30, 2, 5, 15, 40, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.25', '310.00', 0, 0, 0, '310.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(31, 2, 19, 17, 150, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.30', '1395.00', 0, 0, 0, '1395.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:09', '0000-00-00 00:00:00', 1),
(32, 3, 1, 1, 50, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.10', '1650.00', 0, 0, 0, '1650.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(33, 3, 14, 2, 5, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.80', '120.00', 0, 0, 0, '120.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(34, 3, 17, 4, 25, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '2.00', '1500.00', 0, 0, 0, '1500.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(35, 3, 4, 5, 135, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '3.00', '12150.00', 0, 0, 0, '12150.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(36, 3, 6, 6, 60, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.70', '1260.00', 0, 0, 0, '1260.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(37, 3, 7, 7, 30, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.70', '630.00', 0, 0, 0, '630.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(38, 3, 2, 8, 130, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.40', '5460.00', 0, 0, 0, '5460.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(39, 3, 15, 9, 10, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.90', '270.00', 0, 0, 0, '270.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(40, 3, 3, 11, 51, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '3.50', '5355.00', 0, 0, 0, '5355.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:51', '0000-00-00 00:00:00', 1),
(41, 3, 18, 14, 50, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.80', '2700.00', 0, 0, 0, '2700.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:52', '0000-00-00 00:00:00', 1),
(42, 3, 5, 15, 40, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.25', '300.00', 0, 0, 0, '300.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:52', '0000-00-00 00:00:00', 1),
(43, 3, 19, 17, 150, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.30', '1350.00', 0, 0, 0, '1350.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:42:52', '0000-00-00 00:00:00', 1),
(44, 4, 1, 1, 50, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.10', '1705.00', 0, 0, 0, '1705.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(45, 4, 14, 2, 5, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.80', '124.00', 0, 0, 0, '124.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(46, 4, 17, 4, 25, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '2.00', '1550.00', 0, 0, 0, '1550.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(47, 4, 4, 5, 135, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '3.00', '12555.00', 0, 0, 0, '12555.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(48, 4, 6, 6, 60, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '1302.00', 0, 0, 0, '1302.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(49, 4, 7, 7, 30, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '651.00', 0, 0, 0, '651.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:21', '0000-00-00 00:00:00', 1),
(50, 4, 2, 8, 130, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.40', '5642.00', 0, 0, 0, '5642.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(51, 4, 15, 9, 10, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.90', '279.00', 0, 0, 0, '279.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(52, 4, 3, 11, 51, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '3.50', '5533.50', 0, 0, 0, '5533.50', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(53, 4, 18, 14, 50, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.80', '2790.00', 0, 0, 0, '2790.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(54, 4, 5, 15, 40, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.25', '310.00', 0, 0, 0, '310.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(55, 4, 19, 17, 150, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.30', '1395.00', 0, 0, 0, '1395.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:43:22', '0000-00-00 00:00:00', 1),
(56, 5, 1, 1, 50, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.10', '1705.00', 0, 0, 0, '1705.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(57, 5, 14, 2, 5, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.80', '124.00', 0, 0, 0, '124.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(58, 5, 17, 4, 25, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '2.00', '1550.00', 0, 0, 0, '1550.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(59, 5, 4, 5, 135, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '3.00', '12555.00', 0, 0, 0, '12555.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(60, 5, 2, 8, 130, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.40', '5642.00', 0, 0, 0, '5642.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(61, 5, 15, 9, 10, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.90', '279.00', 0, 0, 0, '279.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(62, 5, 3, 11, 51, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '3.50', '5533.50', 0, 0, 0, '5533.50', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(63, 5, 18, 14, 4, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.80', '223.20', 0, 0, 0, '223.20', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(64, 5, 19, 17, 150, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.30', '1395.00', 0, 0, 0, '1395.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(65, 5, 5, 15, 40, '2017-08-01', '2017-08-29', 29, '2017-03-25', 158, '0.25', '290.00', 1, 0, 0, '290.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(66, 5, 6, 6, 60, '2017-08-01', '2017-08-29', 29, '2017-03-25', 158, '0.70', '1218.00', 1, 0, 0, '1218.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(67, 5, 7, 7, 30, '2017-08-01', '2017-08-29', 29, '2017-03-25', 158, '0.70', '609.00', 1, 0, 0, '609.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(68, 5, 18, 14, 46, '2017-08-01', '2017-08-29', 29, '2017-04-27', 125, '1.80', '2401.20', 1, 0, 0, '2401.20', '0.00', '0.00', '0.00', '0.00', '2017-09-14 12:45:20', '0000-00-00 00:00:00', 1),
(69, 6, 42, 1, 150, '2017-08-26', '2017-08-31', 6, '0000-00-00', 0, '1.10', '990.00', 0, 0, 0, '990.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(70, 6, 39, 1, 200, '2017-08-19', '2017-08-31', 13, '0000-00-00', 0, '1.10', '2860.00', 0, 0, 0, '2860.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(71, 6, 34, 1, 80, '2017-08-15', '2017-08-31', 17, '0000-00-00', 0, '1.10', '1496.00', 0, 0, 0, '1496.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(72, 6, 31, 1, 100, '2017-08-11', '2017-08-31', 21, '0000-00-00', 0, '1.10', '2310.00', 0, 0, 0, '2310.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(73, 6, 27, 1, 50, '2017-08-09', '2017-08-31', 23, '0000-00-00', 0, '1.10', '1265.00', 0, 0, 0, '1265.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(74, 6, 24, 1, 80, '2017-08-08', '2017-08-31', 24, '0000-00-00', 0, '1.10', '2112.00', 0, 0, 0, '2112.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(75, 6, 20, 1, 150, '2017-07-29', '2017-08-31', 34, '0000-00-00', 0, '1.10', '5610.00', 0, 0, 0, '5610.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(76, 6, 28, 2, 20, '2017-08-09', '2017-08-31', 23, '0000-00-00', 0, '0.80', '368.00', 0, 0, 0, '368.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:05', '0000-00-00 00:00:00', 1),
(77, 6, 47, 4, 100, '2017-08-30', '2017-08-31', 2, '0000-00-00', 0, '2.00', '400.00', 0, 0, 0, '400.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(78, 6, 43, 4, 100, '2017-08-26', '2017-08-31', 6, '0000-00-00', 0, '2.00', '1200.00', 0, 0, 0, '1200.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(79, 6, 41, 4, 100, '2017-08-19', '2017-08-31', 13, '0000-00-00', 0, '2.00', '2600.00', 0, 0, 0, '2600.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(80, 6, 38, 4, 200, '2017-08-17', '2017-08-31', 15, '0000-00-00', 0, '2.00', '6000.00', 0, 0, 0, '6000.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(81, 6, 37, 4, 130, '2017-08-15', '2017-08-31', 17, '0000-00-00', 0, '2.00', '4420.00', 0, 0, 0, '4420.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(82, 6, 33, 4, 80, '2017-08-11', '2017-08-31', 21, '0000-00-00', 0, '2.00', '3360.00', 0, 0, 0, '3360.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(83, 6, 30, 4, 20, '2017-08-09', '2017-08-31', 23, '0000-00-00', 0, '2.00', '920.00', 0, 0, 0, '920.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(84, 6, 26, 4, 20, '2017-08-08', '2017-08-31', 24, '0000-00-00', 0, '2.00', '960.00', 0, 0, 0, '960.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(85, 6, 23, 4, 50, '2017-07-29', '2017-08-31', 34, '0000-00-00', 0, '2.00', '3400.00', 0, 0, 0, '3400.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(86, 6, 21, 8, 39, '2017-07-29', '2017-08-31', 34, '0000-00-00', 0, '1.40', '1856.40', 0, 0, 0, '1856.40', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(87, 6, 40, 10, 50, '2017-08-19', '2017-08-31', 13, '0000-00-00', 0, '3.00', '1950.00', 0, 0, 0, '1950.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(88, 6, 35, 10, 25, '2017-08-15', '2017-08-31', 17, '0000-00-00', 0, '3.00', '1275.00', 0, 0, 0, '1275.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(89, 6, 32, 10, 25, '2017-08-11', '2017-08-31', 21, '0000-00-00', 0, '3.00', '1575.00', 0, 0, 0, '1575.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(90, 6, 29, 10, 25, '2017-08-09', '2017-08-31', 23, '0000-00-00', 0, '3.00', '1725.00', 0, 0, 0, '1725.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(91, 6, 25, 10, 15, '2017-08-08', '2017-08-31', 24, '0000-00-00', 0, '3.00', '1080.00', 0, 0, 0, '1080.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(92, 6, 22, 10, 15, '2017-07-29', '2017-08-31', 34, '0000-00-00', 0, '3.00', '1530.00', 0, 0, 0, '1530.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(93, 6, 45, 39, 35, '2017-08-26', '2017-08-31', 6, '0000-00-00', 0, '0.50', '105.00', 0, 0, 0, '105.00', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(94, 6, 44, 40, 3, '2017-08-26', '2017-08-31', 6, '0000-00-00', 0, '1.30', '23.40', 0, 0, 0, '23.40', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(95, 6, 46, 41, 4, '2017-08-26', '2017-08-31', 6, '0000-00-00', 0, '1.67', '40.08', 0, 0, 0, '40.08', '0.00', '0.00', '0.00', '0.00', '2017-09-14 16:49:06', '0000-00-00 00:00:00', 1),
(96, 7, 61, 1, 200, '2017-05-24', '2017-05-31', 8, '0000-00-00', 0, '1.10', '1760.00', 0, 0, 0, '1760.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:43', '0000-00-00 00:00:00', 1),
(97, 7, 59, 1, 340, '2017-05-11', '2017-05-31', 21, '0000-00-00', 0, '1.10', '7854.00', 0, 0, 0, '7854.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:43', '0000-00-00 00:00:00', 1),
(98, 7, 51, 1, 10, '2017-05-09', '2017-05-31', 23, '0000-00-00', 0, '1.10', '253.00', 0, 0, 0, '253.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:43', '0000-00-00 00:00:00', 1),
(99, 7, 64, 7, 200, '2017-05-24', '2017-05-31', 8, '0000-00-00', 0, '0.70', '1120.00', 0, 0, 0, '1120.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(100, 7, 57, 7, 200, '2017-05-10', '2017-05-31', 22, '0000-00-00', 0, '0.70', '3080.00', 0, 0, 0, '3080.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(101, 7, 54, 7, 130, '2017-05-09', '2017-05-31', 23, '0000-00-00', 0, '0.70', '2093.00', 0, 0, 0, '2093.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(102, 7, 62, 25, 24, '2017-05-24', '2017-05-31', 8, '0000-00-00', 0, '1.20', '230.40', 0, 0, 0, '230.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(103, 7, 63, 26, 160, '2017-05-24', '2017-05-31', 8, '0000-00-00', 0, '1.00', '1280.00', 0, 0, 0, '1280.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(104, 7, 56, 26, 300, '2017-05-10', '2017-05-31', 22, '0000-00-00', 0, '1.00', '6600.00', 0, 0, 0, '6600.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(105, 7, 53, 26, 300, '2017-05-09', '2017-05-31', 23, '0000-00-00', 0, '1.00', '6900.00', 0, 0, 0, '6900.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(106, 7, 65, 27, 142, '2017-05-24', '2017-05-31', 8, '0000-00-00', 0, '0.90', '1022.40', 0, 0, 0, '1022.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(107, 7, 60, 33, 450, '2017-05-11', '2017-05-31', 21, '0000-00-00', 0, '0.70', '6615.00', 0, 0, 0, '6615.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(108, 7, 55, 33, 500, '2017-05-10', '2017-05-31', 22, '0000-00-00', 0, '0.70', '7700.00', 0, 0, 0, '7700.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(109, 7, 52, 33, 650, '2017-05-09', '2017-05-31', 23, '0000-00-00', 0, '0.70', '10465.00', 0, 0, 0, '10465.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(110, 7, 58, 34, 150, '2017-05-10', '2017-05-31', 22, '0000-00-00', 0, '0.70', '2310.00', 0, 0, 0, '2310.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:54:44', '0000-00-00 00:00:00', 1),
(111, 8, 61, 1, 550, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.10', '18150.00', 0, 0, 0, '18150.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(112, 8, 64, 7, 530, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.70', '11130.00', 0, 0, 0, '11130.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(113, 8, 66, 25, 190, '2017-06-28', '2017-06-30', 3, '0000-00-00', 0, '1.20', '684.00', 0, 0, 0, '684.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(114, 8, 62, 25, 24, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.20', '864.00', 0, 0, 0, '864.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(115, 8, 63, 26, 760, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '1.00', '22800.00', 0, 0, 0, '22800.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(116, 8, 68, 27, 90, '2017-06-28', '2017-06-30', 3, '0000-00-00', 0, '0.90', '243.00', 0, 0, 0, '243.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(117, 8, 65, 27, 142, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.90', '3834.00', 0, 0, 0, '3834.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(118, 8, 67, 33, 850, '2017-06-28', '2017-06-30', 3, '0000-00-00', 0, '0.70', '1785.00', 0, 0, 0, '1785.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(119, 8, 60, 33, 1600, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.70', '33600.00', 0, 0, 0, '33600.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(120, 8, 58, 34, 150, '2017-06-01', '2017-06-30', 30, '0000-00-00', 0, '0.70', '3150.00', 0, 0, 0, '3150.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 09:56:45', '0000-00-00 00:00:00', 1),
(121, 9, 61, 1, 301, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.10', '10264.10', 0, 0, 0, '10264.10', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:02', '2017-09-15 12:17:56', 0),
(122, 9, 64, 7, 447, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '9699.90', 0, 0, 0, '9699.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:02', '2017-09-15 12:17:56', 0),
(123, 9, 66, 25, 177, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.20', '6584.40', 0, 0, 0, '6584.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:02', '2017-09-15 12:17:56', 0),
(124, 9, 63, 26, 513, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.00', '15903.00', 0, 0, 0, '15903.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(125, 9, 68, 27, 37, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.90', '1032.30', 0, 0, 0, '1032.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(126, 9, 67, 33, 1298, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '28166.60', 0, 0, 0, '28166.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(127, 9, 58, 34, 27, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '585.90', 0, 0, 0, '585.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(128, 9, 59, 1, 79, '2017-07-01', '2017-07-26', 26, '2017-05-11', 77, '1.10', '2259.40', 1, 0, 0, '2259.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(129, 9, 59, 1, 160, '2017-07-01', '2017-07-15', 15, '2017-05-11', 66, '1.10', '2640.00', 1, 0, 0, '2640.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(130, 9, 51, 1, 10, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '1.10', '165.00', 1, 0, 0, '165.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(131, 9, 54, 7, 83, '2017-07-01', '2017-07-26', 26, '2017-05-09', 79, '0.70', '1510.60', 1, 0, 0, '1510.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(132, 9, 66, 25, 6, '2017-07-01', '2017-07-26', 26, '2017-06-28', 29, '1.20', '187.20', 1, 1, 0, '187.20', '194.40', '216.00', '21.60', '194.40', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(133, 9, 66, 25, 7, '2017-07-01', '2017-07-15', 15, '2017-06-28', 18, '1.20', '126.00', 1, 1, 0, '126.00', '226.80', '252.00', '25.20', '226.80', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(134, 9, 62, 25, 24, '2017-07-01', '2017-07-15', 15, '2017-05-24', 53, '1.20', '432.00', 1, 0, 0, '432.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(135, 9, 53, 26, 6, '2017-07-01', '2017-07-26', 26, '2017-05-09', 79, '1.00', '156.00', 1, 0, 0, '156.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(136, 9, 53, 26, 241, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '1.00', '3615.00', 1, 0, 0, '3615.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(137, 9, 68, 27, 2, '2017-07-01', '2017-07-26', 26, '2017-06-28', 29, '0.90', '46.80', 1, 1, 0, '46.80', '48.60', '54.00', '5.40', '48.60', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(138, 9, 68, 27, 51, '2017-07-01', '2017-07-15', 15, '2017-06-28', 18, '0.90', '688.50', 1, 1, 0, '688.50', '1239.30', '1377.00', '137.70', '1239.30', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(139, 9, 65, 27, 142, '2017-07-01', '2017-07-15', 15, '2017-05-24', 53, '0.90', '1917.00', 1, 0, 0, '1917.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(140, 9, 60, 33, 2, '2017-07-01', '2017-07-26', 26, '2017-05-11', 77, '0.70', '36.40', 1, 0, 0, '36.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(141, 9, 55, 33, 171, '2017-07-01', '2017-07-26', 26, '2017-05-10', 78, '0.70', '3112.20', 1, 0, 0, '3112.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(142, 9, 55, 33, 329, '2017-07-01', '2017-07-15', 15, '2017-05-10', 67, '0.70', '3454.50', 1, 0, 0, '3454.50', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(143, 9, 52, 33, 650, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '0.70', '6825.00', 1, 0, 0, '6825.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(144, 9, 58, 34, 123, '2017-07-01', '2017-07-15', 15, '2017-05-10', 67, '0.70', '1291.50', 1, 0, 0, '1291.50', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:01:03', '2017-09-15 12:17:56', 0),
(145, 10, 61, 1, 199, '2017-08-01', '2017-08-22', 22, '2017-05-24', 91, '1.10', '4815.80', 1, 0, 0, '4815.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(146, 10, 61, 1, 1, '2017-08-01', '2017-08-29', 29, '2017-05-24', 98, '1.10', '31.90', 1, 0, 0, '31.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(147, 10, 59, 1, 101, '2017-08-01', '2017-08-22', 22, '2017-05-11', 104, '1.10', '2444.20', 1, 0, 0, '2444.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(148, 10, 57, 7, 12, '2017-08-01', '2017-08-22', 22, '2017-05-10', 105, '0.70', '184.80', 1, 0, 0, '184.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(149, 10, 57, 7, 152, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '0.70', '3085.60', 1, 0, 0, '3085.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(150, 10, 64, 7, 236, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.70', '5121.20', 0, 0, 0, '5121.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(151, 10, 54, 7, 47, '2017-08-01', '2017-08-22', 22, '2017-05-09', 106, '0.70', '723.80', 1, 0, 0, '723.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(152, 10, 66, 25, 136, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.20', '5059.20', 0, 0, 0, '5059.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(153, 10, 66, 25, 41, '2017-08-01', '2017-08-29', 29, '2017-06-28', 63, '1.20', '1426.80', 1, 0, 0, '1426.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(154, 10, 63, 26, 379, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.00', '11749.00', 0, 0, 0, '11749.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(155, 10, 56, 26, 81, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '1.00', '2349.00', 1, 0, 0, '2349.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(156, 10, 53, 26, 53, '2017-08-01', '2017-08-29', 29, '2017-05-09', 113, '1.00', '1537.00', 1, 0, 0, '1537.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(157, 10, 68, 27, 37, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.90', '1032.30', 0, 0, 0, '1032.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(158, 10, 67, 33, 909, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.70', '19725.30', 0, 0, 0, '19725.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(159, 10, 60, 33, 389, '2017-08-01', '2017-08-29', 29, '2017-05-11', 111, '0.70', '7896.70', 1, 0, 0, '7896.70', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(160, 10, 58, 34, 27, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '0.70', '548.10', 1, 0, 0, '548.10', '0.00', '0.00', '0.00', '0.00', '2017-09-15 10:40:22', '2017-09-15 12:19:42', 0),
(161, 11, 69, 4, 40, '2017-08-08', '2017-08-31', 24, '0000-00-00', 0, '2.00', '1920.00', 0, 0, 0, '1920.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 11:16:36', '0000-00-00 00:00:00', 1),
(162, 12, 70, 1, 1000, '2017-08-05', '2017-08-31', 27, '0000-00-00', 0, '1.00', '27000.00', 0, 0, 0, '27000.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 11:32:16', '0000-00-00 00:00:00', 1),
(163, 9, 61, 1, 301, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.10', '10264.10', 0, 0, 0, '10264.10', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(164, 9, 51, 1, 10, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '1.10', '165.00', 1, 0, 0, '165.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(165, 9, 59, 1, 160, '2017-07-01', '2017-07-15', 15, '2017-05-11', 66, '1.10', '2640.00', 1, 0, 0, '2640.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(166, 9, 59, 1, 79, '2017-07-01', '2017-07-26', 26, '2017-05-11', 77, '1.10', '2259.40', 1, 0, 0, '2259.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(167, 9, 54, 7, 83, '2017-07-01', '2017-07-26', 26, '2017-05-09', 79, '0.70', '1510.60', 1, 0, 0, '1510.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(168, 9, 64, 7, 447, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '9699.90', 0, 0, 0, '9699.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(169, 9, 62, 25, 24, '2017-07-01', '2017-07-15', 15, '2017-05-24', 53, '1.20', '432.00', 1, 0, 0, '432.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(170, 9, 66, 25, 177, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.20', '6584.40', 0, 0, 0, '6584.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(171, 9, 66, 25, 7, '2017-07-01', '2017-07-15', 15, '2017-06-28', 18, '1.20', '126.00', 1, 1, 0, '126.00', '226.80', '252.00', '25.20', '226.80', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(172, 9, 66, 25, 6, '2017-07-01', '2017-07-26', 26, '2017-06-28', 29, '1.20', '187.20', 1, 1, 0, '187.20', '194.40', '216.00', '21.60', '194.40', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(173, 9, 63, 26, 513, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '1.00', '15903.00', 0, 0, 0, '15903.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(174, 9, 53, 26, 241, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '1.00', '3615.00', 1, 0, 0, '3615.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(175, 9, 53, 26, 6, '2017-07-01', '2017-07-26', 26, '2017-05-09', 79, '1.00', '156.00', 1, 0, 0, '156.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(176, 9, 68, 27, 51, '2017-07-01', '2017-07-15', 15, '2017-06-28', 18, '0.90', '688.50', 1, 1, 0, '688.50', '1239.30', '1377.00', '137.70', '1239.30', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(177, 9, 68, 27, 2, '2017-07-01', '2017-07-26', 26, '2017-06-28', 29, '0.90', '46.80', 1, 1, 0, '46.80', '48.60', '54.00', '5.40', '48.60', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(178, 9, 65, 27, 142, '2017-07-01', '2017-07-15', 15, '2017-05-24', 53, '0.90', '1917.00', 1, 0, 0, '1917.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(179, 9, 68, 27, 37, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.90', '1032.30', 0, 0, 0, '1032.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(180, 9, 55, 33, 171, '2017-07-01', '2017-07-26', 26, '2017-05-10', 78, '0.70', '3112.20', 1, 0, 0, '3112.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(181, 9, 60, 33, 2, '2017-07-01', '2017-07-26', 26, '2017-05-11', 77, '0.70', '36.40', 1, 0, 0, '36.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(182, 9, 52, 33, 650, '2017-07-01', '2017-07-15', 15, '2017-05-09', 68, '0.70', '6825.00', 1, 0, 0, '6825.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:56', '0000-00-00 00:00:00', 1),
(183, 9, 67, 33, 1298, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '28166.60', 0, 0, 0, '28166.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:57', '0000-00-00 00:00:00', 1),
(184, 9, 55, 33, 329, '2017-07-01', '2017-07-15', 15, '2017-05-10', 67, '0.70', '3454.50', 1, 0, 0, '3454.50', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:57', '0000-00-00 00:00:00', 1),
(185, 9, 58, 34, 123, '2017-07-01', '2017-07-15', 15, '2017-05-10', 67, '0.70', '1291.50', 1, 0, 0, '1291.50', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:57', '0000-00-00 00:00:00', 1),
(186, 9, 58, 34, 27, '2017-07-01', '2017-07-31', 31, '0000-00-00', 0, '0.70', '585.90', 0, 0, 0, '585.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:17:57', '0000-00-00 00:00:00', 1),
(187, 10, 59, 1, 101, '2017-08-01', '2017-08-22', 22, '2017-05-11', 104, '1.10', '2444.20', 1, 0, 0, '2444.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(188, 10, 61, 1, 199, '2017-08-01', '2017-08-22', 22, '2017-05-24', 91, '1.10', '4815.80', 1, 0, 0, '4815.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(189, 10, 61, 1, 1, '2017-08-01', '2017-08-29', 29, '2017-05-24', 98, '1.10', '31.90', 1, 0, 0, '31.90', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(190, 10, 57, 7, 152, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '0.70', '3085.60', 1, 0, 0, '3085.60', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(191, 10, 64, 7, 236, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.70', '5121.20', 0, 0, 0, '5121.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(192, 10, 54, 7, 47, '2017-08-01', '2017-08-22', 22, '2017-05-09', 106, '0.70', '723.80', 1, 0, 0, '723.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(193, 10, 57, 7, 12, '2017-08-01', '2017-08-22', 22, '2017-05-10', 105, '0.70', '184.80', 1, 0, 0, '184.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(194, 10, 66, 25, 136, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.20', '5059.20', 0, 0, 0, '5059.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(195, 10, 66, 25, 41, '2017-08-01', '2017-08-29', 29, '2017-06-28', 63, '1.20', '1426.80', 1, 0, 0, '1426.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(196, 10, 53, 26, 53, '2017-08-01', '2017-08-29', 29, '2017-05-09', 113, '1.00', '1537.00', 1, 0, 0, '1537.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(197, 10, 63, 26, 379, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.00', '11749.00', 0, 0, 0, '11749.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(198, 10, 56, 26, 81, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '1.00', '2349.00', 1, 0, 0, '2349.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:42', '0000-00-00 00:00:00', 1),
(199, 10, 68, 27, 37, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.90', '1032.30', 0, 0, 0, '1032.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:43', '0000-00-00 00:00:00', 1),
(200, 10, 67, 33, 909, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.70', '19725.30', 0, 0, 0, '19725.30', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:43', '0000-00-00 00:00:00', 1),
(201, 10, 60, 33, 389, '2017-08-01', '2017-08-29', 29, '2017-05-11', 111, '0.70', '7896.70', 1, 0, 0, '7896.70', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:43', '0000-00-00 00:00:00', 1),
(202, 10, 58, 34, 27, '2017-08-01', '2017-08-29', 29, '2017-05-10', 112, '0.70', '548.10', 1, 0, 0, '548.10', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:19:43', '0000-00-00 00:00:00', 1),
(203, 13, 64, 7, 200, '2017-09-01', '2017-09-04', 4, '2017-05-24', 104, '0.70', '560.00', 1, 0, 0, '560.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(204, 13, 57, 7, 36, '2017-09-01', '2017-09-04', 4, '2017-05-10', 118, '0.70', '100.80', 1, 0, 0, '100.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(205, 13, 66, 25, 136, '2017-09-01', '2017-09-04', 4, '2017-06-28', 69, '1.20', '652.80', 1, 0, 0, '652.80', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(206, 13, 56, 26, 219, '2017-09-01', '2017-09-04', 4, '2017-05-10', 118, '1.00', '876.00', 1, 0, 0, '876.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(207, 13, 63, 26, 160, '2017-09-01', '2017-09-04', 4, '2017-05-24', 104, '1.00', '640.00', 1, 0, 0, '640.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(208, 13, 68, 27, 37, '2017-09-01', '2017-09-04', 4, '2017-06-28', 69, '0.90', '133.20', 1, 0, 0, '133.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(209, 13, 60, 33, 59, '2017-09-01', '2017-09-04', 4, '2017-05-11', 117, '0.70', '165.20', 1, 0, 0, '165.20', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(210, 13, 67, 33, 850, '2017-09-01', '2017-09-04', 4, '2017-06-28', 69, '0.70', '2380.00', 1, 0, 0, '2380.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 12:23:45', '0000-00-00 00:00:00', 1),
(211, 14, 71, 1, 220, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '1.10', '5324.00', 0, 0, 0, '5324.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(212, 14, 72, 2, 20, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '0.80', '352.00', 0, 0, 0, '352.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(213, 14, 75, 3, 7, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '4.00', '616.00', 0, 0, 0, '616.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(214, 14, 74, 5, 250, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '3.00', '16500.00', 0, 0, 0, '16500.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(215, 14, 73, 10, 82, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '3.00', '5412.00', 0, 0, 0, '5412.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(216, 14, 76, 11, 1, '2017-08-10', '2017-08-31', 22, '0000-00-00', 0, '3.50', '77.00', 0, 0, 0, '77.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 13:49:11', '0000-00-00 00:00:00', 1),
(217, 15, 79, 13, 142, '2017-07-24', '2017-08-31', 39, '0000-00-00', 0, '1.00', '5538.00', 0, 0, 0, '5538.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 14:32:00', '0000-00-00 00:00:00', 1),
(218, 15, 77, 14, 332, '2017-07-24', '2017-08-31', 39, '0000-00-00', 0, '1.80', '23306.40', 0, 0, 0, '23306.40', '0.00', '0.00', '0.00', '0.00', '2017-09-15 14:32:00', '0000-00-00 00:00:00', 1),
(219, 15, 80, 16, 100, '2017-07-24', '2017-08-31', 39, '0000-00-00', 0, '0.25', '975.00', 0, 0, 0, '975.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 14:32:00', '0000-00-00 00:00:00', 1),
(220, 15, 81, 17, 650, '2017-07-24', '2017-08-31', 39, '0000-00-00', 0, '0.30', '7605.00', 0, 0, 0, '7605.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 14:32:00', '0000-00-00 00:00:00', 1),
(221, 15, 78, 18, 550, '2017-07-24', '2017-08-31', 39, '0000-00-00', 0, '0.30', '6435.00', 0, 0, 0, '6435.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 14:32:01', '0000-00-00 00:00:00', 1),
(222, 16, 89, 7, 90, '2017-07-22', '2017-08-31', 41, '0000-00-00', 0, '0.70', '2583.00', 0, 0, 0, '2583.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 15:18:27', '0000-00-00 00:00:00', 1),
(223, 16, 88, 26, 260, '2017-07-22', '2017-08-31', 41, '0000-00-00', 0, '1.00', '10660.00', 0, 0, 0, '10660.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 15:18:27', '0000-00-00 00:00:00', 1),
(224, 16, 90, 31, 420, '2017-07-22', '2017-08-31', 41, '0000-00-00', 0, '1.00', '17220.00', 0, 0, 0, '17220.00', '0.00', '0.00', '0.00', '0.00', '2017-09-15 15:18:27', '0000-00-00 00:00:00', 1),
(225, 16, 87, 33, 225, '2017-07-22', '2017-08-31', 41, '0000-00-00', 0, '0.70', '6457.50', 0, 0, 0, '6457.50', '0.00', '0.00', '0.00', '0.00', '2017-09-15 15:18:27', '0000-00-00 00:00:00', 1),
(226, 17, 150, 7, 18, '2017-04-22', '2017-05-31', 40, '0000-00-00', 0, '0.70', '504.00', 0, 0, 0, '504.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:14:39', '0000-00-00 00:00:00', 1),
(227, 17, 147, 26, 108, '2017-04-22', '2017-05-31', 40, '0000-00-00', 0, '1.00', '4320.00', 0, 0, 0, '4320.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:14:39', '0000-00-00 00:00:00', 1),
(228, 17, 149, 31, 144, '2017-04-22', '2017-05-31', 40, '0000-00-00', 0, '1.00', '5760.00', 0, 0, 0, '5760.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:14:39', '0000-00-00 00:00:00', 1),
(229, 17, 148, 33, 81, '2017-04-22', '2017-05-31', 40, '0000-00-00', 0, '0.70', '2268.00', 0, 0, 0, '2268.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:14:39', '0000-00-00 00:00:00', 1),
(230, 18, 150, 7, 18, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '0.70', '201.60', 1, 0, 0, '201.60', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:17:47', '2017-09-25 10:27:55', 0),
(231, 18, 147, 26, 108, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '1.00', '1728.00', 1, 0, 0, '1728.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:17:47', '2017-09-25 10:27:55', 0),
(232, 18, 149, 31, 144, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '1.00', '2304.00', 1, 0, 0, '2304.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:17:47', '2017-09-25 10:27:55', 0),
(233, 18, 148, 33, 81, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '0.70', '907.20', 1, 0, 0, '907.20', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:17:47', '2017-09-25 10:27:55', 0),
(234, 18, 150, 7, 18, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '0.70', '201.60', 1, 0, 0, '201.60', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:27:55', '0000-00-00 00:00:00', 1),
(235, 18, 147, 26, 108, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '1.00', '1728.00', 1, 0, 0, '1728.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:27:55', '0000-00-00 00:00:00', 1),
(236, 18, 149, 31, 144, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '1.00', '2304.00', 1, 0, 0, '2304.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:27:55', '0000-00-00 00:00:00', 1),
(237, 18, 148, 33, 81, '2017-06-01', '2017-06-16', 16, '2017-04-22', 56, '0.70', '907.20', 1, 0, 0, '907.20', '0.00', '0.00', '0.00', '0.00', '2017-09-25 10:27:55', '0000-00-00 00:00:00', 1),
(238, 19, 179, 1, 150, '2017-03-30', '2017-03-31', 2, '0000-00-00', 0, '0.90', '270.00', 0, 0, 0, '270.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(239, 19, 176, 1, 150, '2017-03-29', '2017-03-31', 3, '0000-00-00', 0, '0.90', '405.00', 0, 0, 0, '405.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(240, 19, 175, 4, 200, '2017-03-29', '2017-03-31', 3, '0000-00-00', 0, '1.66', '996.00', 0, 0, 0, '996.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(241, 19, 172, 4, 50, '2017-03-02', '2017-03-31', 30, '0000-00-00', 0, '1.66', '2490.00', 0, 0, 0, '2490.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(242, 19, 180, 4, 50, '2017-03-30', '2017-03-31', 2, '0000-00-00', 0, '1.66', '166.00', 0, 0, 0, '166.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(243, 19, 173, 4, 200, '2017-03-17', '2017-03-31', 15, '0000-00-00', 0, '1.66', '4980.00', 0, 0, 0, '4980.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(244, 19, 174, 4, 50, '2017-03-25', '2017-03-31', 7, '0000-00-00', 0, '1.66', '581.00', 0, 0, 0, '581.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(245, 19, 178, 5, 20, '2017-03-29', '2017-03-31', 3, '0000-00-00', 0, '2.66', '159.60', 0, 0, 0, '159.60', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(246, 19, 181, 5, 30, '2017-03-30', '2017-03-31', 2, '0000-00-00', 0, '2.66', '159.60', 0, 0, 0, '159.60', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(247, 19, 177, 10, 30, '2017-03-29', '2017-03-31', 3, '0000-00-00', 0, '2.66', '239.40', 0, 0, 0, '239.40', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:25:41', '0000-00-00 00:00:00', 1),
(248, 20, 179, 1, 300, '2017-04-01', '2017-04-30', 30, '0000-00-00', 0, '0.90', '8100.00', 0, 0, 0, '8100.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(249, 20, 182, 2, 30, '2017-04-08', '2017-04-30', 23, '0000-00-00', 0, '0.70', '483.00', 0, 0, 0, '483.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(250, 20, 180, 4, 550, '2017-04-01', '2017-04-30', 30, '0000-00-00', 0, '1.66', '27390.00', 0, 0, 0, '27390.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(251, 20, 181, 5, 50, '2017-04-01', '2017-04-30', 30, '0000-00-00', 0, '2.66', '3990.00', 0, 0, 0, '3990.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(252, 20, 183, 9, 30, '2017-04-08', '2017-04-30', 23, '0000-00-00', 0, '0.80', '552.00', 0, 0, 0, '552.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(253, 20, 177, 10, 30, '2017-04-01', '2017-04-30', 30, '0000-00-00', 0, '2.66', '2394.00', 0, 0, 0, '2394.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:26:45', '0000-00-00 00:00:00', 1),
(254, 21, 179, 1, 300, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.90', '8370.00', 0, 0, 0, '8370.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(255, 21, 182, 2, 30, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.70', '651.00', 0, 0, 0, '651.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(256, 21, 180, 4, 550, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '1.66', '28303.00', 0, 0, 0, '28303.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(257, 21, 184, 4, 80, '2017-05-16', '2017-05-31', 16, '0000-00-00', 0, '1.66', '2124.80', 0, 0, 0, '2124.80', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(258, 21, 181, 5, 30, '2017-05-01', '2017-05-16', 16, '2017-03-30', 48, '2.66', '1276.80', 1, 0, 0, '1276.80', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(259, 21, 178, 5, 20, '2017-05-01', '2017-05-16', 16, '2017-03-29', 49, '2.66', '851.20', 1, 0, 0, '851.20', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(260, 21, 183, 9, 30, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '0.80', '744.00', 0, 0, 0, '744.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(261, 21, 177, 10, 30, '2017-05-01', '2017-05-31', 31, '0000-00-00', 0, '2.66', '2473.80', 0, 0, 0, '2473.80', '0.00', '0.00', '0.00', '0.00', '2017-09-25 12:46:25', '0000-00-00 00:00:00', 1),
(262, 22, 139, 1, 150, '2017-09-04', '2017-09-18', 15, '0000-00-00', 0, '1.10', '2475.00', 0, 0, 0, '2475.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:06', '0000-00-00 00:00:00', 1),
(263, 22, 108, 1, 600, '2017-08-17', '2017-09-18', 33, '0000-00-00', 0, '1.10', '21780.00', 0, 0, 0, '21780.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1);
INSERT INTO `wp_shc_hiring_detail` (`id`, `hiring_bill_id`, `delivery_detail_id`, `lot_id`, `qty`, `bill_from`, `bill_to`, `bill_days`, `delivery_date`, `total_days`, `rate_per_day`, `amount`, `got_return`, `min_checkbox_avail`, `min_checked`, `hiring_amt`, `hiring_amt_min`, `for_thirty_days`, `previous_paid`, `bal_to_pay`, `created_at`, `modified_at`, `active`) VALUES
(264, 22, 111, 1, 100, '2017-08-18', '2017-09-18', 32, '0000-00-00', 0, '1.10', '3520.00', 0, 0, 0, '3520.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(265, 22, 141, 6, 150, '2017-09-07', '2017-09-18', 12, '0000-00-00', 0, '0.70', '1260.00', 0, 0, 0, '1260.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(266, 22, 109, 6, 1400, '2017-08-17', '2017-09-18', 33, '0000-00-00', 0, '0.70', '32340.00', 0, 0, 0, '32340.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(267, 22, 112, 6, 100, '2017-08-18', '2017-09-18', 32, '0000-00-00', 0, '0.70', '2240.00', 0, 0, 0, '2240.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(268, 22, 120, 10, 100, '2017-08-22', '2017-09-18', 28, '0000-00-00', 0, '3.00', '8400.00', 0, 0, 0, '8400.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(269, 22, 185, 10, 38, '2017-08-17', '2017-09-04', 19, '2017-08-17', 19, '0.00', '0.00', 1, 1, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(270, 22, 106, 10, 62, '2017-08-17', '2017-09-18', 33, '0000-00-00', 0, '3.00', '6138.00', 0, 0, 0, '6138.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(271, 22, 138, 10, 18, '2017-09-04', '2017-09-18', 15, '0000-00-00', 0, '3.00', '810.00', 0, 0, 0, '810.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(272, 22, 126, 10, 15, '2017-08-25', '2017-09-18', 25, '0000-00-00', 0, '3.00', '1125.00', 0, 0, 0, '1125.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(273, 22, 186, 10, 5, '2017-08-26', '2017-09-04', 10, '2017-08-26', 10, '0.00', '0.00', 1, 1, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(274, 22, 110, 10, 20, '2017-08-18', '2017-09-18', 32, '0000-00-00', 0, '3.00', '1920.00', 0, 0, 0, '1920.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(275, 22, 131, 10, 65, '2017-08-29', '2017-09-18', 21, '0000-00-00', 0, '3.00', '4095.00', 0, 0, 0, '4095.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(276, 22, 113, 10, 150, '2017-08-19', '2017-09-18', 31, '0000-00-00', 0, '3.00', '13950.00', 0, 0, 0, '13950.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(277, 22, 136, 10, 21, '2017-09-01', '2017-09-18', 18, '0000-00-00', 0, '3.00', '1134.00', 0, 0, 0, '1134.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(278, 22, 130, 11, 45, '2017-08-26', '2017-09-18', 24, '0000-00-00', 0, '3.50', '3780.00', 0, 0, 0, '3780.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(279, 22, 140, 11, 4, '2017-09-04', '2017-09-18', 15, '0000-00-00', 0, '3.50', '210.00', 0, 0, 0, '210.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(280, 22, 142, 17, 750, '2017-09-07', '2017-09-18', 12, '0000-00-00', 0, '0.30', '2700.00', 0, 0, 0, '2700.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(281, 22, 133, 19, 43, '2017-08-29', '2017-09-18', 21, '0000-00-00', 0, '2.50', '2257.50', 0, 0, 0, '2257.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(282, 22, 115, 19, 19, '2017-08-21', '2017-09-18', 29, '0000-00-00', 0, '2.50', '1377.50', 0, 0, 0, '1377.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(283, 22, 116, 20, 89, '2017-08-21', '2017-09-18', 29, '0000-00-00', 0, '4.50', '11614.50', 0, 0, 0, '11614.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(284, 22, 134, 20, 54, '2017-08-29', '2017-09-18', 21, '0000-00-00', 0, '4.50', '5103.00', 0, 0, 0, '5103.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(285, 22, 127, 45, 495, '2017-08-25', '2017-09-18', 25, '0000-00-00', 0, '2.50', '30937.50', 0, 0, 0, '30937.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(286, 22, 117, 45, 350, '2017-08-21', '2017-09-18', 29, '0000-00-00', 0, '2.50', '25375.00', 0, 0, 0, '25375.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(287, 22, 129, 45, 250, '2017-08-26', '2017-09-18', 24, '0000-00-00', 0, '2.50', '15000.00', 0, 0, 0, '15000.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(288, 22, 118, 45, 150, '2017-08-22', '2017-09-18', 28, '0000-00-00', 0, '2.50', '10500.00', 0, 0, 0, '10500.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(289, 22, 135, 45, 280, '2017-08-29', '2017-09-18', 21, '0000-00-00', 0, '2.50', '14700.00', 0, 0, 0, '14700.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(290, 22, 123, 45, 475, '2017-08-23', '2017-09-18', 27, '0000-00-00', 0, '2.50', '32062.50', 0, 0, 0, '32062.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(291, 22, 137, 46, 731, '2017-09-01', '2017-09-18', 18, '0000-00-00', 0, '0.30', '3947.40', 0, 0, 0, '3947.40', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(292, 22, 119, 46, 750, '2017-08-22', '2017-09-18', 28, '0000-00-00', 0, '0.30', '6300.00', 0, 0, 0, '6300.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 14:53:07', '0000-00-00 00:00:00', 1),
(293, 23, 188, 1, 205, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '1.10', '7892.50', 0, 0, 0, '7892.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(294, 23, 189, 2, 20, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '0.80', '560.00', 0, 0, 0, '560.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(295, 23, 187, 4, 100, '2017-06-26', '2017-07-31', 36, '0000-00-00', 0, '2.00', '7200.00', 0, 0, 0, '7200.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(296, 23, 192, 4, 120, '2017-06-28', '2017-07-31', 34, '0000-00-00', 0, '2.00', '8160.00', 0, 0, 0, '8160.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(297, 23, 190, 10, 3, '2017-06-27', '2017-07-08', 12, '2017-06-27', 12, '3.00', '108.00', 1, 1, 0, '108.00', '270.00', '270.00', '0.00', '270.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(298, 23, 191, 10, 37, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '3.00', '3885.00', 0, 0, 0, '3885.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:27:02', '2017-09-25 16:33:01', 0),
(299, 23, 188, 1, 205, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '1.10', '7892.50', 0, 0, 0, '7892.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(300, 23, 189, 2, 20, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '0.80', '560.00', 0, 0, 0, '560.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(301, 23, 187, 4, 100, '2017-06-26', '2017-07-31', 36, '0000-00-00', 0, '2.00', '7200.00', 0, 0, 0, '7200.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(302, 23, 192, 4, 120, '2017-06-28', '2017-07-31', 34, '0000-00-00', 0, '2.00', '8160.00', 0, 0, 0, '8160.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(303, 23, 190, 10, 3, '2017-06-27', '2017-07-08', 12, '2017-06-27', 12, '3.00', '108.00', 1, 1, 0, '108.00', '270.00', '270.00', '0.00', '270.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(304, 23, 191, 10, 37, '2017-06-27', '2017-07-31', 35, '0000-00-00', 0, '3.00', '3885.00', 0, 0, 0, '3885.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:33:01', '0000-00-00 00:00:00', 1),
(305, 24, 188, 1, 205, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '1.10', '6990.50', 0, 0, 0, '6990.50', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(306, 24, 195, 1, 10, '2017-08-11', '2017-08-11', 1, '2017-08-11', 1, '0.00', '0.00', 1, 1, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(307, 24, 189, 2, 20, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '0.80', '496.00', 0, 0, 0, '496.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(308, 24, 192, 4, 220, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '2.00', '13640.00', 0, 0, 0, '13640.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(309, 24, 193, 4, 10, '2017-08-11', '2017-08-31', 21, '0000-00-00', 0, '2.00', '420.00', 0, 0, 0, '420.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(310, 24, 191, 10, 37, '2017-08-01', '2017-08-31', 31, '0000-00-00', 0, '3.00', '3441.00', 0, 0, 0, '3441.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(311, 24, 194, 11, 6, '2017-08-11', '2017-08-31', 21, '0000-00-00', 0, '3.50', '441.00', 0, 0, 0, '441.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 16:57:44', '0000-00-00 00:00:00', 1),
(312, 25, 198, 7, 25, '2017-07-17', '2017-08-31', 46, '0000-00-00', 0, '0.70', '805.00', 0, 0, 0, '805.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 17:19:56', '0000-00-00 00:00:00', 1),
(313, 25, 199, 26, 90, '2017-07-17', '2017-08-31', 46, '0000-00-00', 0, '1.00', '4140.00', 0, 0, 0, '4140.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 17:19:56', '0000-00-00 00:00:00', 1),
(314, 25, 197, 28, 25, '2017-07-17', '2017-08-31', 46, '0000-00-00', 0, '1.00', '1150.00', 0, 0, 0, '1150.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 17:19:56', '0000-00-00 00:00:00', 1),
(315, 25, 196, 31, 215, '2017-07-17', '2017-08-31', 46, '0000-00-00', 0, '0.70', '6923.00', 0, 0, 0, '6923.00', '0.00', '0.00', '0.00', '0.00', '2017-09-25 17:19:56', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_hiring_gst`
--

CREATE TABLE `wp_shc_hiring_gst` (
  `hiring_id` bigint(11) NOT NULL,
  `hsn_code` varchar(255) NOT NULL,
  `hsn_name` text NOT NULL,
  `taxable_value` decimal(15,2) NOT NULL,
  `cgst_val` decimal(15,2) NOT NULL,
  `sgst_val` decimal(15,2) NOT NULL,
  `igst_val` decimal(15,2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_loading`
--

CREATE TABLE `wp_shc_loading` (
  `id` int(11) NOT NULL,
  `deposit_id` int(11) NOT NULL,
  `loading_charge` decimal(15,2) NOT NULL,
  `master_id` int(11) NOT NULL,
  `deposit_date` datetime NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_loading`
--

INSERT INTO `wp_shc_loading` (`id`, `deposit_id`, `loading_charge`, `master_id`, `deposit_date`, `active`) VALUES
(1, 1, '7350.00', 1, '2017-03-30 06:21:00', 1),
(2, 2, '3200.00', 1, '2017-04-18 07:25:00', 1),
(3, 3, '4250.00', 1, '2017-04-27 07:34:00', 1),
(4, 4, '2700.00', 2, '2017-07-29 09:15:00', 1),
(5, 5, '2700.00', 2, '2017-08-08 09:17:00', 1),
(6, 6, '2750.00', 2, '2017-08-11 09:20:00', 1),
(7, 7, '2700.00', 2, '2017-08-14 09:22:00', 1),
(8, 8, '1620.00', 2, '2017-08-14 09:25:00', 1),
(9, 9, '2800.00', 2, '2017-08-19 09:26:00', 1),
(10, 10, '3300.00', 2, '2017-08-19 09:27:00', 1),
(11, 11, '2800.00', 2, '2017-08-30 09:28:00', 1),
(12, 12, '2000.00', 2, '2017-08-30 10:21:00', 1),
(13, 13, '5600.00', 2, '2017-09-02 10:35:00', 1),
(14, 14, '2500.00', 3, '2017-05-18 11:40:00', 1),
(15, 15, '600.00', 3, '2017-05-24 11:42:00', 1),
(16, 16, '0.00', 4, '2017-08-08 05:26:00', 1),
(17, 17, '1000.00', 5, '2017-08-05 05:57:00', 1),
(18, 18, '3200.00', 6, '2017-08-08 07:15:00', 1),
(19, 19, '1900.00', 7, '2017-07-20 08:34:00', 1),
(20, 20, '9500.00', 7, '2017-09-12 08:42:00', 1),
(21, 21, '2650.00', 8, '2017-08-31 09:10:00', 1),
(22, 22, '5250.00', 9, '2017-07-20 09:23:00', 1),
(23, 23, '5300.00', 9, '2017-09-01 09:26:00', 1),
(24, 24, '5000.00', 10, '2017-08-21 10:07:00', 1),
(25, 25, '3150.00', 10, '2017-09-06 10:14:00', 1),
(26, 26, '84800.00', 11, '2017-08-16 10:27:00', 1),
(27, 27, '3300.00', 12, '2017-06-30 11:41:00', 1),
(28, 28, '2850.00', 13, '2017-04-22 04:30:00', 1),
(29, 29, '0.00', 14, '2017-07-27 05:12:00', 1),
(30, 30, '1800.00', 15, '2017-09-14 06:11:00', 1),
(31, 31, '3750.00', 17, '2017-06-27 10:28:00', 1),
(32, 32, '3250.00', 18, '2017-07-08 11:33:00', 1),
(33, 33, '23600.00', 19, '2017-08-18 12:02:00', 1),
(34, 34, '3500.00', 20, '2017-09-05 12:21:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_loading_detail`
--

CREATE TABLE `wp_shc_loading_detail` (
  `id` int(11) NOT NULL,
  `deposit_id` int(11) NOT NULL,
  `loading_id` int(11) NOT NULL,
  `charge_for` varchar(250) NOT NULL,
  `charge_amt` decimal(15,2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_loading_detail`
--

INSERT INTO `wp_shc_loading_detail` (`id`, `deposit_id`, `loading_id`, `charge_for`, `charge_amt`, `active`) VALUES
(1, 1, 1, 'loading', '350.00', 1),
(2, 1, 1, 'transportation', '7000.00', 1),
(3, 2, 2, 'loading', '200.00', 1),
(4, 2, 2, 'transportation', '3000.00', 1),
(5, 3, 3, 'loading', '250.00', 1),
(6, 3, 3, 'transportation', '4000.00', 1),
(7, 4, 4, 'loading', '300.00', 1),
(8, 4, 4, 'transportation', '2400.00', 1),
(9, 5, 5, 'loading', '300.00', 1),
(10, 5, 5, 'transportation', '2400.00', 1),
(11, 6, 6, 'loading', '350.00', 1),
(12, 6, 6, 'transportation', '2400.00', 1),
(13, 7, 7, 'loading', '300.00', 1),
(14, 7, 7, 'transportation', '2400.00', 1),
(15, 8, 8, 'loading', '120.00', 1),
(16, 8, 8, 'transportation', '1500.00', 1),
(17, 9, 9, 'loading', '500.00', 1),
(18, 9, 9, 'transportation', '0.00', 1),
(19, 10, 10, 'loading', '500.00', 1),
(20, 10, 10, 'transportation', '2800.00', 1),
(21, 11, 11, 'loading', '400.00', 1),
(22, 11, 11, 'transportation', '2400.00', 1),
(23, 12, 12, 'loading', '250.00', 1),
(24, 12, 12, 'transportation', '1750.00', 1),
(25, 13, 13, 'loading', '800.00', 1),
(26, 13, 13, 'transportation', '4800.00', 1),
(27, 14, 14, 'loading', '2500.00', 1),
(28, 14, 14, 'transportation', '0.00', 1),
(29, 15, 15, 'loading', '600.00', 1),
(30, 15, 15, 'transportation', '0.00', 1),
(31, 16, 16, 'loading', '0.00', 1),
(32, 16, 16, 'transportation', '0.00', 1),
(33, 17, 17, 'loading', '1000.00', 1),
(34, 17, 17, 'transportation', '0.00', 1),
(35, 18, 18, 'loading', '3200.00', 1),
(36, 18, 18, 'transportation', '0.00', 1),
(37, 19, 19, 'loading', '1200.00', 1),
(38, 19, 19, 'transportation', '700.00', 1),
(39, 20, 20, 'loading', '1500.00', 1),
(40, 20, 20, 'transportation', '8000.00', 1),
(41, 21, 21, 'loading', '250.00', 1),
(42, 21, 21, 'transportation', '2400.00', 1),
(43, 22, 22, 'loading', '750.00', 1),
(44, 22, 22, 'transportation', '4500.00', 1),
(45, 23, 23, 'loading', '800.00', 1),
(46, 23, 23, 'transportation', '4500.00', 1),
(47, 24, 24, 'loading', '500.00', 1),
(48, 24, 24, 'transportation', '4500.00', 1),
(49, 25, 25, 'loading', '150.00', 1),
(50, 25, 25, 'transportation', '3000.00', 1),
(51, 26, 26, 'loading', '21200.00', 1),
(52, 26, 26, 'transportation', '63600.00', 1),
(53, 27, 27, 'loading', '300.00', 1),
(54, 27, 27, 'transportation', '3000.00', 1),
(55, 28, 28, 'loading', '350.00', 1),
(56, 28, 28, 'transportation', '2500.00', 1),
(57, 29, 29, 'loading', '0.00', 1),
(58, 29, 29, 'transportation', '0.00', 1),
(59, 30, 30, 'loading', '300.00', 1),
(60, 30, 30, 'transportation', '1500.00', 1),
(61, 31, 31, 'loading', '750.00', 1),
(62, 31, 31, 'transportation', '3000.00', 1),
(63, 32, 32, 'loading', '250.00', 1),
(64, 32, 32, 'transportation', '3000.00', 1),
(65, 33, 33, 'loading', '3600.00', 1),
(66, 33, 33, 'transportation', '20000.00', 1),
(67, 34, 34, 'loading', '3500.00', 1),
(68, 34, 34, 'transportation', '0.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_lost`
--

CREATE TABLE `wp_shc_lost` (
  `id` int(11) NOT NULL,
  `master_id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `lost_qty` int(11) NOT NULL,
  `lost_total` decimal(15,2) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_lost`
--

INSERT INTO `wp_shc_lost` (`id`, `master_id`, `return_id`, `lost_qty`, `lost_total`, `updated_by`, `active`) VALUES
(1, 3, 8, 49, '0.00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_lost_detail`
--

CREATE TABLE `wp_shc_lost_detail` (
  `id` bigint(20) NOT NULL,
  `master_id` bigint(11) NOT NULL,
  `lost_id` bigint(11) NOT NULL,
  `return_id` bigint(11) NOT NULL,
  `lot_id` bigint(11) NOT NULL,
  `lost_qty` int(11) NOT NULL,
  `lost_unit_price` decimal(15,2) NOT NULL,
  `lost_total` decimal(15,2) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_lost_detail`
--

INSERT INTO `wp_shc_lost_detail` (`id`, `master_id`, `lost_id`, `return_id`, `lot_id`, `lost_qty`, `lost_unit_price`, `lost_total`, `active`) VALUES
(1, 3, 1, 8, 7, 49, '0.00', '0.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_lots`
--

CREATE TABLE `wp_shc_lots` (
  `id` int(11) NOT NULL,
  `lot_no` varchar(250) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `product_type` varchar(250) NOT NULL,
  `unit_price` decimal(9,2) NOT NULL,
  `tax1` decimal(9,2) NOT NULL,
  `buying_price` decimal(15,2) NOT NULL,
  `weight` decimal(15,2) NOT NULL,
  `stock_in` int(11) NOT NULL DEFAULT '0',
  `sale_out` int(11) NOT NULL DEFAULT '0',
  `updated_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_lots`
--

INSERT INTO `wp_shc_lots` (`id`, `lot_no`, `product_name`, `product_type`, `unit_price`, `tax1`, `buying_price`, `weight`, `stock_in`, `sale_out`, `updated_by`, `created_at`, `modified_at`, `active`) VALUES
(1, 'CS1', 'Centring Sheet', '900 x 600mm', '1.10', '0.00', '0.00', '0.00', 0, 0, 0, '2017-07-17 06:36:36', '2017-08-09 14:12:48', 1),
(2, 'AS ( 3x1.5 )', 'Adj Centring Sheet', '900 x 400 mm', '0.80', '0.00', '0.00', '0.00', 0, 0, 0, '2017-07-17 10:21:02', '2017-09-14 12:30:51', 1),
(3, 'SPAN (18-F)', 'Tele Span', '3.00x5.75m', '4.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-07-17 10:22:18', '2017-09-14 12:24:46', 1),
(4, 'P12', 'Tele Props ', '2.00x3.70m', '2.00', '0.00', '190.00', '5.00', 0, 0, 0, '2017-07-17 10:23:02', '2017-08-25 19:51:11', 1),
(5, 'P18', 'Tele Props', '3.15 x 5.70m', '3.00', '0.00', '40.00', '10.00', 0, 0, 0, '2017-08-09 12:02:34', '2017-09-11 14:59:21', 1),
(6, 'SH (STD)', 'Stirrup Head', 'Standard', '0.70', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 12:49:29', '2017-09-14 12:26:41', 1),
(7, 'BJ (STD)', 'Base Jack ', 'Standard', '0.70', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 12:51:07', '2017-09-14 12:27:15', 1),
(8, 'CS2', 'Centring Sheet', '1150 x 600 mm', '1.40', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:13:42', '2017-08-09 14:15:38', 1),
(9, 'AS ( 4x1.5 )', 'Adj Centring Sheet', '1150 x 400 mm', '0.90', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:15:17', '2017-09-14 12:30:42', 1),
(10, 'SPAN (N)', 'Tellescopic Span', '2.40 x 4.15 m', '3.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:19:20', '2017-09-14 12:22:38', 1),
(11, 'SPAN (15-F)', 'Tellescopic Span', '3.00 x 4.80 m', '3.50', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:20:31', '2017-09-14 12:22:33', 1),
(12, 'PROPEX', 'Prop Extension', '1m', '1.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:28:09', '0000-00-00 00:00:00', 1),
(13, 'LP10', 'Ledger Pipes', '3m', '1.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:29:31', '2017-08-10 10:45:05', 1),
(14, 'LP20', 'Ledger Pipes', '6m', '1.80', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:30:03', '2017-08-10 10:44:50', 1),
(15, 'BP (STD)', 'Baseplate', '0.150 x 0.150 m', '0.25', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:31:23', '2017-09-14 12:26:11', 1),
(16, 'EJP', 'Expanding Joint Pin', 'Standard', '0.25', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:32:08', '0000-00-00 00:00:00', 1),
(17, 'FC', 'Coupler Fixed', 'Standard', '0.30', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:32:55', '2017-08-10 11:03:50', 1),
(18, 'SC', 'Coupler Swivel', 'Standard', '0.30', '0.00', '150.00', '0.00', 0, 0, 0, '2017-08-09 14:33:50', '2017-09-11 17:55:06', 1),
(19, 'CC10', 'C.Channel', '3m', '2.50', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:36:19', '0000-00-00 00:00:00', 1),
(20, 'CC20', 'C.Channel', '6m', '4.50', '0.00', '350.00', '10.00', 0, 0, 0, '2017-08-09 14:36:48', '2017-08-25 22:49:47', 1),
(21, 'TIER1', 'Tie Rod', '1.2m', '0.30', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:38:02', '0000-00-00 00:00:00', 1),
(22, 'WALT', 'Waller Plate for Tirod', 'Standard', '0.20', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:38:56', '0000-00-00 00:00:00', 1),
(23, 'WNUT', 'Wing Nut', 'Standard', '0.20', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:43:49', '0000-00-00 00:00:00', 1),
(24, 'CLV10', 'Cuplock Vertical', '3m', '1.50', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:44:46', '0000-00-00 00:00:00', 1),
(25, 'CLV8', 'Cuplock Vertical', '2.5m', '1.20', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:49:40', '0000-00-00 00:00:00', 1),
(26, 'CLV6.5', 'Cuplock Vertical', '2m', '1.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:51:14', '0000-00-00 00:00:00', 1),
(27, 'CLV5', 'Cuplock Vertical', '1.5m', '0.90', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:51:51', '0000-00-00 00:00:00', 1),
(28, 'CLV3', 'Cuplock Vertical', '1m', '0.80', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:52:26', '2017-08-09 14:52:37', 1),
(29, 'CLV1.5', 'Cuplock Vertical', '0.50m', '0.60', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:53:19', '2017-08-09 14:53:34', 1),
(30, 'CLH10', 'Cuplock Horizontal', '3m', '1.10', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:54:17', '0000-00-00 00:00:00', 1),
(31, 'CLH6.5', 'Cuplock Horizontal', '2m', '1.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:54:51', '0000-00-00 00:00:00', 1),
(32, 'CLH6', 'Cuplock Horizontal', '1.8m', '1.00', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:55:21', '0000-00-00 00:00:00', 1),
(33, 'CLH4', 'Cuplock Horizontal', '1.2m', '0.70', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:55:53', '0000-00-00 00:00:00', 1),
(34, 'CLH3', 'Cuplock Horizontal', '1m', '0.70', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:56:18', '0000-00-00 00:00:00', 1),
(35, 'CLH2.5', 'Cuplock Horizontal', '0.75m', '0.70', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:56:43', '0000-00-00 00:00:00', 1),
(36, 'JPIN', 'Joint Pin (SPIGOT)', '0.30m', '0.20', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-09 14:57:57', '0000-00-00 00:00:00', 1),
(37, 'WFS', 'Wall Form Sheet', '1200 x 500mm', '2.00', '0.00', '200.00', '1.00', 0, 0, 0, '2017-08-09 14:58:38', '2017-08-20 19:58:30', 1),
(38, 'PP', 'Props Pin', 'Standard', '0.10', '0.00', '0.00', '0.00', 0, 0, 0, '2017-08-10 10:49:26', '0000-00-00 00:00:00', 1),
(39, 'BS ( 15x2 )', 'Beam Side 0.40m', '15 x 2', '0.60', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-14 15:29:49', '2017-09-14 16:01:00', 1),
(40, 'BS ( 15x5.6 )', 'Beam Side 0.40m', '15 x 5.6', '6.85', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-14 15:32:47', '0000-00-00 00:00:00', 1),
(41, 'BS ( 15x8 )', 'Beam Side 0.40m', '15 x 8', '10.28', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-14 15:33:52', '0000-00-00 00:00:00', 1),
(42, 'APSV (3f)', 'APS Vertical', '3f', '0.80', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-15 15:06:31', '2017-09-15 15:08:11', 1),
(43, 'APSV (1f)', 'APS Vertical', '1f', '0.60', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-15 15:07:21', '2017-09-15 15:07:56', 1),
(44, 'APSV (2f)', 'APS Vertical', '2f', '0.60', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-15 15:08:35', '0000-00-00 00:00:00', 1),
(45, 'P15', 'Tele Props ', '2.00x4.50m', '2.50', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-15 16:00:02', '0000-00-00 00:00:00', 1),
(46, 'COUPLER (40x50)', 'Coupler', '40x50mm', '0.30', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-15 16:01:35', '0000-00-00 00:00:00', 1),
(47, 'CLV2', 'Cuplock Vertical', '0.60m', '0.60', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-25 10:45:59', '0000-00-00 00:00:00', 1),
(48, 'BS', 'Beam Side', 'Std', '1.00', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-25 11:45:00', '0000-00-00 00:00:00', 1),
(49, 'SH (L)', 'Stirrup Head', 'Length', '0.80', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-25 17:35:10', '0000-00-00 00:00:00', 1),
(50, 'BJ (2f)', 'Base Jack ', '2 feet', '0.80', '0.00', '0.00', '0.00', 0, 0, 1, '2017-09-25 17:38:43', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_master`
--

CREATE TABLE `wp_shc_master` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `master_date` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_master`
--

INSERT INTO `wp_shc_master` (`id`, `customer_id`, `site_id`, `master_date`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 1, 1, '2017-09-14 05:17:00', '2017-09-14 10:47:15', '0000-00-00 00:00:00', 1, 1),
(2, 3, 3, '2017-09-14 09:13:00', '2017-09-14 14:43:59', '0000-00-00 00:00:00', 1, 1),
(3, 4, 4, '2017-09-14 11:32:00', '2017-09-14 17:03:58', '0000-00-00 00:00:00', 1, 1),
(4, 5, 5, '2017-09-15 05:23:00', '2017-09-15 10:53:47', '0000-00-00 00:00:00', 1, 1),
(5, 6, 6, '2017-09-15 05:53:00', '2017-09-15 11:23:21', '0000-00-00 00:00:00', 1, 1),
(6, 7, 7, '2017-09-15 07:14:00', '2017-09-15 12:45:07', '0000-00-00 00:00:00', 1, 1),
(7, 8, 8, '2017-09-15 08:31:00', '2017-09-15 14:01:49', '0000-00-00 00:00:00', 1, 1),
(8, 9, 9, '2017-08-31 09:09:00', '2017-09-15 14:40:27', '0000-00-00 00:00:00', 1, 1),
(9, 10, 10, '2017-09-15 09:22:00', '2017-09-15 14:52:41', '0000-00-00 00:00:00', 1, 1),
(10, 11, 11, '2017-09-15 10:07:00', '2017-09-15 15:37:28', '0000-00-00 00:00:00', 1, 1),
(11, 12, 12, '2017-09-15 10:23:00', '2017-09-15 15:53:43', '0000-00-00 00:00:00', 1, 1),
(12, 13, 13, '2017-09-15 11:41:00', '2017-09-15 17:11:23', '0000-00-00 00:00:00', 1, 1),
(13, 14, 14, '2017-09-25 04:30:00', '2017-09-25 10:00:36', '0000-00-00 00:00:00', 1, 1),
(14, 15, 15, '2017-09-25 05:11:00', '2017-09-25 10:42:11', '0000-00-00 00:00:00', 1, 1),
(15, 16, 16, '2017-09-25 06:11:00', '2017-09-25 11:41:35', '0000-00-00 00:00:00', 1, 1),
(16, 17, 17, '2017-09-25 06:27:00', '2017-09-25 11:57:36', '0000-00-00 00:00:00', 1, 1),
(17, 18, 18, '2017-09-25 10:27:00', '2017-09-25 15:57:50', '0000-00-00 00:00:00', 1, 1),
(18, 19, 19, '2017-09-25 11:33:00', '2017-09-25 17:03:15', '0000-00-00 00:00:00', 1, 1),
(19, 20, 20, '2017-09-25 11:59:00', '2017-09-25 17:30:24', '0000-00-00 00:00:00', 1, 1),
(20, 21, 21, '2017-09-25 12:21:00', '2017-09-25 17:51:16', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_obc_cheque`
--

CREATE TABLE `wp_shc_obc_cheque` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `cheque_no` varchar(255) NOT NULL,
  `cheque_date` date NOT NULL,
  `cheque_amount` decimal(15,2) NOT NULL,
  `notes` text NOT NULL,
  `extra_notes` text NOT NULL,
  `received_by` varchar(255) NOT NULL,
  `obc_date` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_obc_cheque`
--

INSERT INTO `wp_shc_obc_cheque` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `cheque_no`, `cheque_date`, `cheque_amount`, `notes`, `extra_notes`, `received_by`, `obc_date`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 3, 2016, 1, '', 1, 'NEFT', '2017-03-31', '50055.00', '', '', '', '2017-03-31 00:00:00', '2017-09-14 12:07:55', '0000-00-00 00:00:00', 1, 1),
(2, 3, 2017, 1, '', 1, 'NEFT', '2017-04-18', '32000.00', '', '', '', '2017-04-18 00:00:00', '2017-09-14 12:54:04', '0000-00-00 00:00:00', 1, 1),
(3, 3, 2017, 2, '', 1, 'NEFT', '2017-04-27', '40980.00', '', '', '', '2017-04-27 00:00:00', '2017-09-14 12:54:45', '0000-00-00 00:00:00', 1, 1),
(4, 3, 2017, 3, '', 5, 'NEFT', '2017-08-05', '91000.00', 'NEFT R.No.012', '', '', '2017-09-15 00:00:00', '2017-09-15 11:38:57', '0000-00-00 00:00:00', 1, 1),
(5, 3, 2017, 4, '', 3, 'RTGS', '2017-05-09', '222190.00', 'R.No 004', '', '', '2017-05-09 00:00:00', '2017-09-15 11:51:03', '2017-09-15 12:05:52', 1, 1),
(6, 3, 2017, 5, '', 3, 'NEFT KVB', '2017-05-23', '61494.00', 'R.No 005', '', '', '2017-05-23 00:00:00', '2017-09-15 11:52:08', '0000-00-00 00:00:00', 1, 1),
(7, 3, 2017, 6, '', 3, 'Chq.No 012995 KVB', '2017-06-10', '75354.00', 'KVB', '', '', '2017-06-10 00:00:00', '2017-09-15 11:55:48', '0000-00-00 00:00:00', 1, 1),
(8, 3, 2017, 7, '', 3, 'NEFT R.No 006', '2017-06-28', '82160.00', 'KVB', '', '', '2017-06-28 00:00:00', '2017-09-15 11:56:23', '2017-09-15 11:57:16', 1, 1),
(9, 3, 2017, 8, '', 3, 'Chq.No 012996', '2017-07-10', '75354.00', 'KVB', '', '', '2017-07-10 00:00:00', '2017-09-15 11:59:43', '0000-00-00 00:00:00', 1, 1),
(10, 3, 2017, 9, '', 3, 'Chq. No 012997', '2017-08-10', '75354.00', 'KVB', '', '', '2017-08-11 00:00:00', '2017-09-15 12:00:20', '0000-00-00 00:00:00', 1, 1),
(11, 3, 2017, 10, '', 3, 'Adj Security Deposit & Loading Charges', '2017-09-05', '283684.00', '', '', '', '2017-09-05 00:00:00', '2017-09-15 12:25:03', '0000-00-00 00:00:00', 1, 1),
(12, 3, 2017, 11, '', 6, 'RTGS R.No. 013', '2017-08-09', '260000.00', 'KVB', '', '', '2017-08-09 00:00:00', '2017-09-15 13:53:06', '0000-00-00 00:00:00', 1, 1),
(13, 3, 2017, 12, '', 7, 'R.No 009', '2017-07-20', '7000.00', 'Cash', '', '', '2017-07-20 00:00:00', '2017-09-15 14:21:34', '0000-00-00 00:00:00', 1, 1),
(14, 3, 2017, 13, '', 7, 'Chq.No 844688', '2017-07-21', '102000.00', 'KVB', '', '', '2017-07-21 00:00:00', '2017-09-15 14:28:23', '0000-00-00 00:00:00', 1, 1),
(15, 3, 2017, 14, '', 7, 'Chq.No 844682', '2017-08-24', '39648.00', 'KVB', '', '', '2017-08-24 00:00:00', '2017-09-15 14:29:01', '0000-00-00 00:00:00', 1, 1),
(16, 3, 2017, 15, '', 7, 'Chq.No 844692', '2017-09-13', '79000.00', 'KVB', '', '', '2017-09-13 00:00:00', '2017-09-15 14:29:27', '0000-00-00 00:00:00', 1, 1),
(17, 3, 2017, 16, '', 7, 'R.No 018', '2017-09-13', '43900.00', 'IMPS/KVB', '', '', '2017-09-13 00:00:00', '2017-09-15 14:30:57', '0000-00-00 00:00:00', 1, 1),
(18, 3, 2017, 17, '', 8, 'NEFT R.no 016', '2017-09-01', '40450.00', 'KVB', '', '', '2017-09-01 00:00:00', '2017-09-15 14:45:47', '0000-00-00 00:00:00', 1, 1),
(19, 3, 2017, 18, '', 9, 'Chq. No 166781', '2017-07-22', '86295.00', 'KVB', '', '', '2017-07-24 00:00:00', '2017-09-15 15:19:56', '0000-00-00 00:00:00', 1, 1),
(20, 3, 2017, 19, '', 9, 'Chq. No 16782', '2017-08-22', '37188.00', 'KVB', '', '', '2017-08-22 00:00:00', '2017-09-15 15:20:40', '0000-00-00 00:00:00', 1, 1),
(21, 3, 2017, 20, '', 9, 'Chq. No 166795', '2017-08-31', '50570.00', 'KVB', '', '', '2017-09-01 00:00:00', '2017-09-15 15:21:26', '0000-00-00 00:00:00', 1, 1),
(22, 3, 2017, 21, '', 10, 'Chq. No 366829', '2017-08-19', '62088.00', 'KVB', '', '', '2017-08-22 00:00:00', '2017-09-15 15:44:33', '0000-00-00 00:00:00', 1, 1),
(23, 3, 2017, 22, '', 13, 'NEFT', '0000-00-00', '31767.00', 'KVB', '', 'neft', '2017-04-21 00:00:00', '2017-09-25 10:20:15', '2017-09-25 10:21:58', 1, 1),
(24, 1, 2016, 1, '', 16, 'Cash', '0000-00-00', '20000.00', 'Ref.No 081', '', 'cash', '2017-03-16 00:00:00', '2017-09-25 12:20:48', '0000-00-00 00:00:00', 1, 1),
(25, 1, 2016, 2, '', 16, 'CASH', '0000-00-00', '30000.00', 'Ref. No 084', '', 'cash', '2017-03-28 00:00:00', '2017-09-25 12:21:24', '2017-09-25 12:21:33', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_quotation`
--

CREATE TABLE `wp_shc_quotation` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `quotation_date` datetime NOT NULL,
  `sub_total` decimal(15,2) NOT NULL,
  `discount_avail` varchar(5) NOT NULL,
  `discount_percentage` decimal(10,2) NOT NULL,
  `discount_amt` decimal(15,2) NOT NULL,
  `after_discount_amt` decimal(15,2) NOT NULL,
  `tax_from` varchar(10) NOT NULL,
  `gst_for` varchar(20) NOT NULL,
  `igst_amt` decimal(15,2) NOT NULL,
  `cgst_amt` decimal(15,2) NOT NULL,
  `sgst_amt` decimal(15,2) NOT NULL,
  `vat_amt` decimal(15,2) NOT NULL,
  `tax_include_tot` decimal(15,2) NOT NULL,
  `round_off` decimal(15,2) NOT NULL,
  `hiring_total` decimal(15,2) NOT NULL,
  `for_thirty_days` decimal(15,2) NOT NULL,
  `amount_payable` decimal(15,2) NOT NULL,
  `requirements` text NOT NULL,
  `bank_details` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_quotation`
--

INSERT INTO `wp_shc_quotation` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `customer_id`, `site_id`, `quotation_date`, `sub_total`, `discount_avail`, `discount_percentage`, `discount_amt`, `after_discount_amt`, `tax_from`, `gst_for`, `igst_amt`, `cgst_amt`, `sgst_amt`, `vat_amt`, `tax_include_tot`, `round_off`, `hiring_total`, `for_thirty_days`, `amount_payable`, `requirements`, `bank_details`, `created_at`, `modified_at`, `updated_by`, `active`) VALUES
(1, 3, 2016, 1, '', 1, 1, 1, '2017-03-06 05:22:00', '14235.00', 'yes', '5.00', '711.75', '13523.25', 'vat', 'cgst', '0.00', '0.00', '0.00', '676.16', '14199.41', '0.41', '13523.25', '14199.00', '0.00', '', '', '2017-09-14 10:55:03', '2017-09-14 11:02:39', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_quotation_detail`
--

CREATE TABLE `wp_shc_quotation_detail` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `rate_thirty` decimal(15,2) NOT NULL,
  `rate_ninety` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_quotation_detail`
--

INSERT INTO `wp_shc_quotation_detail` (`id`, `quotation_id`, `lot_id`, `qty`, `unit_price`, `rate_thirty`, `rate_ninety`, `created_at`, `modified_at`, `active`) VALUES
(8, 1, 5, 60, '3.00', '90.00', '5400.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(9, 1, 11, 25, '3.50', '105.00', '2625.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(10, 1, 15, 40, '0.25', '7.50', '300.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(11, 1, 6, 60, '0.70', '21.00', '1260.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(12, 1, 7, 30, '0.70', '21.00', '630.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(13, 1, 8, 80, '1.40', '42.00', '3360.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1),
(14, 1, 1, 20, '1.10', '33.00', '660.00', '2017-09-14 10:55:30', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_return`
--

CREATE TABLE `wp_shc_return` (
  `id` int(11) NOT NULL,
  `bill_from_comp` int(2) NOT NULL,
  `financial_year` int(4) NOT NULL,
  `bill_no` bigint(11) NOT NULL,
  `ref_number` varchar(255) NOT NULL,
  `master_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_return` int(2) NOT NULL,
  `vehicle_number` varchar(255) NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `driver_mobile` varchar(255) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_return`
--

INSERT INTO `wp_shc_return` (`id`, `bill_from_comp`, `financial_year`, `bill_no`, `ref_number`, `master_id`, `return_date`, `created_at`, `is_return`, `vehicle_number`, `driver_name`, `driver_mobile`, `updated_by`, `active`) VALUES
(1, 3, 2017, 1, '', 1, '2017-08-29', '2017-09-14 12:35:43', 1, 'TN02AW3832', '', '', 1, 1),
(2, 3, 2017, 2, '', 3, '2017-07-15', '2017-09-14 17:24:59', 1, 'TN30H7818', '', '', 1, 1),
(3, 3, 2017, 3, '', 3, '2017-07-26', '2017-09-15 09:41:05', 1, 'TN04E2545', '', '', 1, 1),
(4, 3, 2017, 4, '', 3, '2017-08-22', '2017-09-15 09:42:04', 1, 'TN07S3480', '', '', 1, 1),
(5, 3, 2017, 5, '', 3, '2017-08-29', '2017-09-15 09:43:13', 1, 'TN07V5213', '', '', 1, 1),
(6, 3, 2017, 6, '', 3, '2017-09-04', '2017-09-15 09:47:33', 1, 'TN07V5213', '', '', 1, 1),
(7, 3, 2017, 7, '', 3, '2017-09-04', '2017-09-15 09:48:58', 1, 'TN07S3480', '', '', 1, 1),
(8, 3, 2017, 0, '', 3, '2017-09-04', '2017-09-15 10:47:20', 0, '', '', '', 1, 1),
(9, 3, 2017, 8, '', 13, '2017-06-16', '2017-09-25 10:12:53', 1, 'TN21AM4704', 'Dharmaraj', '', 1, 1),
(10, 3, 2017, 9, '', 14, '2017-07-31', '2017-09-25 11:07:06', 1, 'TN18L8701', 'Murugan', '', 1, 1),
(11, 1, 2017, 1, '', 16, '2017-05-16', '2017-09-25 12:14:40', 1, 'TN22CQ1604', 'Siva Kumar', '', 1, 1),
(12, 1, 2017, 2, '', 16, '2017-06-26', '2017-09-25 12:15:46', 1, 'TN67F8683', '', '', 1, 1),
(13, 1, 2017, 3, '', 16, '2017-06-26', '2017-09-25 12:16:32', 1, 'TN21R8137', '', '', 1, 1),
(14, 1, 2017, 4, '', 16, '2017-06-26', '2017-09-25 12:18:23', 1, 'TN67F8683', '', '', 1, 1),
(15, 1, 2017, 5, '', 16, '2017-06-27', '2017-09-25 12:19:18', 1, 'TN21F8137', '', '', 1, 1),
(16, 3, 2017, 10, '', 11, '2017-09-04', '2017-09-25 14:46:24', 1, '', '', '', 1, 1),
(17, 3, 2017, 11, '', 11, '2017-09-04', '2017-09-25 14:51:18', 1, '', '', '', 1, 1),
(18, 1, 2017, 6, '', 17, '2017-07-08', '2017-09-25 16:23:45', 1, 'TN22CR2113', 'Murugan', '', 1, 1),
(19, 1, 2017, 7, '', 17, '2017-08-11', '2017-09-25 16:25:42', 1, 'TN22CQ1604', '', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_return_damage`
--

CREATE TABLE `wp_shc_return_damage` (
  `id` int(11) NOT NULL,
  `master_id` bigint(11) NOT NULL,
  `return_id` bigint(11) NOT NULL,
  `damage_total` decimal(15,2) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_return_damage`
--

INSERT INTO `wp_shc_return_damage` (`id`, `master_id`, `return_id`, `damage_total`, `updated_by`, `active`) VALUES
(1, 13, 9, '0.00', 1, 1),
(2, 14, 10, '0.00', 1, 1),
(3, 16, 11, '0.00', 1, 1),
(4, 16, 12, '0.00', 1, 1),
(5, 16, 13, '0.00', 1, 1),
(6, 16, 14, '200.00', 1, 1),
(7, 16, 15, '0.00', 1, 1),
(8, 11, 16, '0.00', 1, 1),
(9, 11, 17, '0.00', 1, 1),
(10, 17, 18, '0.00', 1, 1),
(11, 17, 19, '0.00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_return_damage_detail`
--

CREATE TABLE `wp_shc_return_damage_detail` (
  `id` int(11) NOT NULL,
  `damage_id` bigint(11) NOT NULL,
  `master_id` bigint(11) NOT NULL,
  `return_id` bigint(11) NOT NULL,
  `damage_detail` text NOT NULL,
  `damage_charge` decimal(15,2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_return_damage_detail`
--

INSERT INTO `wp_shc_return_damage_detail` (`id`, `damage_id`, `master_id`, `return_id`, `damage_detail`, `damage_charge`, `active`) VALUES
(1, 6, 16, 14, 'Props Thread 1 No x Rs.200', '200.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_return_detail`
--

CREATE TABLE `wp_shc_return_detail` (
  `id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `master_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_return_detail`
--

INSERT INTO `wp_shc_return_detail` (`id`, `return_id`, `master_id`, `delivery_detail_id`, `lot_id`, `qty`, `return_date`, `active`) VALUES
(1, 1, 1, 6, 6, 60, '2017-08-29', 1),
(2, 1, 1, 7, 7, 30, '2017-08-29', 1),
(3, 1, 1, 18, 14, 46, '2017-08-29', 1),
(4, 1, 1, 5, 15, 40, '2017-08-29', 1),
(5, 2, 3, 51, 1, 10, '2017-07-15', 0),
(6, 2, 3, 59, 1, 160, '2017-07-15', 0),
(7, 2, 3, 62, 25, 24, '2017-07-15', 0),
(8, 2, 3, 66, 25, 7, '2017-07-15', 0),
(9, 2, 3, 53, 26, 241, '2017-07-15', 0),
(10, 2, 3, 65, 27, 142, '2017-07-15', 0),
(11, 2, 3, 68, 27, 51, '2017-07-15', 0),
(12, 2, 3, 52, 33, 650, '2017-07-15', 0),
(13, 2, 3, 55, 33, 329, '2017-07-15', 0),
(14, 2, 3, 58, 34, 123, '2017-07-15', 0),
(15, 3, 3, 59, 1, 79, '2017-07-26', 0),
(16, 3, 3, 54, 7, 83, '2017-07-26', 0),
(17, 3, 3, 66, 25, 6, '2017-07-26', 0),
(18, 3, 3, 53, 26, 6, '2017-07-26', 0),
(19, 3, 3, 68, 27, 2, '2017-07-26', 0),
(20, 3, 3, 55, 33, 171, '2017-07-26', 0),
(21, 3, 3, 60, 33, 2, '2017-07-26', 0),
(22, 4, 3, 59, 1, 101, '2017-08-22', 0),
(23, 4, 3, 61, 1, 199, '2017-08-22', 0),
(24, 4, 3, 54, 7, 47, '2017-08-22', 0),
(25, 4, 3, 57, 7, 12, '2017-08-22', 0),
(26, 5, 3, 61, 1, 1, '2017-08-29', 0),
(27, 5, 3, 57, 7, 152, '2017-08-29', 0),
(28, 5, 3, 66, 25, 41, '2017-08-29', 0),
(29, 5, 3, 53, 26, 53, '2017-08-29', 0),
(30, 5, 3, 56, 26, 81, '2017-08-29', 0),
(31, 5, 3, 60, 33, 389, '2017-08-29', 0),
(32, 5, 3, 58, 34, 27, '2017-08-29', 0),
(33, 6, 3, 57, 7, 36, '2017-09-04', 0),
(34, 6, 3, 64, 7, 136, '2017-09-04', 0),
(35, 6, 3, 66, 25, 72, '2017-09-04', 0),
(36, 6, 3, 56, 26, 139, '2017-09-04', 0),
(37, 6, 3, 68, 27, 37, '2017-09-04', 0),
(38, 6, 3, 60, 33, 59, '2017-09-04', 0),
(39, 6, 3, 67, 33, 441, '2017-09-04', 0),
(40, 7, 3, 64, 7, 15, '2017-09-04', 1),
(41, 7, 3, 66, 25, 64, '2017-09-04', 1),
(42, 7, 3, 56, 26, 80, '2017-09-04', 1),
(43, 7, 3, 63, 26, 160, '2017-09-04', 1),
(44, 7, 3, 67, 33, 409, '2017-09-04', 1),
(45, 8, 3, 64, 7, 49, '2017-09-04', 1),
(46, 2, 3, 51, 1, 10, '2017-07-15', 1),
(47, 2, 3, 59, 1, 160, '2017-07-15', 1),
(48, 2, 3, 62, 25, 24, '2017-07-15', 1),
(49, 2, 3, 66, 25, 7, '2017-07-15', 1),
(50, 2, 3, 53, 26, 241, '2017-07-15', 1),
(51, 2, 3, 65, 27, 142, '2017-07-15', 1),
(52, 2, 3, 68, 27, 51, '2017-07-15', 1),
(53, 2, 3, 52, 33, 650, '2017-07-15', 1),
(54, 2, 3, 55, 33, 329, '2017-07-15', 1),
(55, 2, 3, 58, 34, 123, '2017-07-15', 1),
(56, 3, 3, 59, 1, 79, '2017-07-26', 1),
(57, 3, 3, 54, 7, 83, '2017-07-26', 1),
(58, 3, 3, 66, 25, 6, '2017-07-26', 1),
(59, 3, 3, 53, 26, 6, '2017-07-26', 1),
(60, 3, 3, 68, 27, 2, '2017-07-26', 1),
(61, 3, 3, 55, 33, 171, '2017-07-26', 1),
(62, 3, 3, 60, 33, 2, '2017-07-26', 1),
(63, 4, 3, 59, 1, 101, '2017-08-22', 1),
(64, 4, 3, 61, 1, 199, '2017-08-22', 1),
(65, 4, 3, 54, 7, 47, '2017-08-22', 1),
(66, 4, 3, 57, 7, 12, '2017-08-22', 1),
(67, 5, 3, 61, 1, 1, '2017-08-29', 1),
(68, 5, 3, 57, 7, 152, '2017-08-29', 1),
(69, 5, 3, 66, 25, 41, '2017-08-29', 1),
(70, 5, 3, 53, 26, 53, '2017-08-29', 1),
(71, 5, 3, 56, 26, 81, '2017-08-29', 1),
(72, 5, 3, 60, 33, 389, '2017-08-29', 1),
(73, 5, 3, 58, 34, 27, '2017-08-29', 1),
(74, 6, 3, 57, 7, 36, '2017-09-04', 1),
(75, 6, 3, 64, 7, 136, '2017-09-04', 1),
(76, 6, 3, 66, 25, 72, '2017-09-04', 1),
(77, 6, 3, 56, 26, 139, '2017-09-04', 1),
(78, 6, 3, 68, 27, 37, '2017-09-04', 1),
(79, 6, 3, 60, 33, 59, '2017-09-04', 1),
(80, 6, 3, 67, 33, 441, '2017-09-04', 1),
(81, 9, 13, 150, 7, 18, '2017-06-16', 0),
(82, 9, 13, 147, 26, 108, '2017-06-16', 0),
(83, 9, 13, 149, 31, 144, '2017-06-16', 0),
(84, 9, 13, 148, 33, 81, '2017-06-16', 0),
(85, 9, 13, 150, 7, 18, '2017-06-16', 1),
(86, 9, 13, 147, 26, 108, '2017-06-16', 1),
(87, 9, 13, 149, 31, 144, '2017-06-16', 1),
(88, 9, 13, 148, 33, 81, '2017-06-16', 1),
(89, 10, 14, 153, 47, 300, '2017-07-31', 0),
(90, 10, 14, 162, 47, 300, '2017-07-31', 1),
(91, 11, 16, 178, 5, 20, '2017-05-16', 1),
(92, 11, 16, 181, 5, 30, '2017-05-16', 1),
(93, 12, 16, 176, 1, 150, '2017-06-26', 1),
(94, 12, 16, 172, 4, 50, '2017-06-26', 1),
(95, 12, 16, 173, 4, 149, '2017-06-26', 1),
(96, 13, 16, 179, 1, 149, '2017-06-26', 1),
(97, 13, 16, 182, 2, 9, '2017-06-26', 1),
(98, 13, 16, 173, 4, 51, '2017-06-26', 1),
(99, 13, 16, 174, 4, 49, '2017-06-26', 1),
(100, 13, 16, 183, 9, 12, '2017-06-26', 1),
(101, 14, 16, 174, 4, 1, '2017-06-26', 1),
(102, 14, 16, 175, 4, 200, '2017-06-26', 1),
(103, 14, 16, 180, 4, 50, '2017-06-26', 1),
(104, 15, 16, 182, 2, 21, '2017-06-27', 1),
(105, 15, 16, 184, 4, 80, '2017-06-27', 1),
(106, 15, 16, 183, 9, 18, '2017-06-27', 1),
(107, 15, 16, 177, 10, 30, '2017-06-27', 1),
(108, 16, 11, 185, 10, 38, '2017-09-04', 1),
(109, 17, 11, 186, 10, 5, '2017-09-04', 1),
(110, 18, 17, 190, 10, 3, '2017-07-08', 1),
(111, 19, 17, 195, 1, 10, '2017-08-11', 1),
(112, 19, 17, 188, 1, 10, '2017-08-11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_special_price`
--

CREATE TABLE `wp_shc_special_price` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `lot_id` int(11) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_special_price`
--

INSERT INTO `wp_shc_special_price` (`id`, `customer_id`, `site_id`, `lot_id`, `price`, `updated_by`, `created_at`, `modified_at`, `active`) VALUES
(1, 3, 3, 40, '1.30', 1, '2017-09-14 15:49:06', '2017-09-14 16:03:30', 1),
(2, 3, 3, 39, '0.50', 1, '2017-09-14 16:01:54', '2017-09-14 16:03:30', 1),
(3, 3, 3, 41, '1.67', 1, '2017-09-14 16:03:00', '2017-09-14 16:03:30', 1),
(4, 6, 6, 1, '1.00', 1, '2017-09-15 11:25:28', '0000-00-00 00:00:00', 1),
(5, 7, 0, 0, '0.00', 1, '2017-09-15 12:44:36', '0000-00-00 00:00:00', 1),
(6, 15, 0, 0, '0.00', 1, '2017-09-25 10:41:15', '2017-09-25 10:46:48', 0),
(7, 15, 15, 47, '0.00', 1, '2017-09-25 10:46:48', '2017-09-25 11:27:11', 1),
(8, 15, 15, 27, '0.80', 1, '2017-09-25 11:27:11', '0000-00-00 00:00:00', 1),
(9, 17, 17, 1, '0.90', 1, '2017-09-25 11:54:47', '2017-09-25 11:57:08', 1),
(10, 17, 17, 2, '0.70', 1, '2017-09-25 11:54:47', '2017-09-25 11:57:08', 1),
(11, 17, 17, 9, '0.80', 1, '2017-09-25 11:54:47', '2017-09-25 11:57:08', 1),
(12, 17, 17, 10, '2.66', 1, '2017-09-25 11:55:31', '2017-09-25 11:57:08', 1),
(13, 17, 17, 4, '1.66', 1, '2017-09-25 11:55:31', '2017-09-25 11:57:08', 1),
(14, 17, 17, 5, '2.66', 1, '2017-09-25 11:56:04', '2017-09-25 11:57:08', 1),
(15, 12, 0, 0, '0.00', 1, '2017-09-25 14:24:28', '2017-09-25 14:35:53', 0),
(16, 12, 0, 10, '0.00', 1, '2017-09-25 14:35:53', '2017-09-25 14:53:33', 0),
(17, 12, 0, 10, '0.00', 1, '2017-09-25 14:49:18', '2017-09-25 14:53:33', 0),
(18, 18, 18, 1, '0.00', 1, '2017-09-25 16:08:28', '2017-09-25 16:09:05', 0),
(19, 19, 19, 28, '1.00', 1, '2017-09-25 17:06:38', '2017-09-25 17:08:32', 1),
(20, 19, 19, 31, '0.70', 1, '2017-09-25 17:08:32', '0000-00-00 00:00:00', 1),
(21, 20, 0, 0, '0.00', 1, '2017-09-25 17:30:47', '2017-09-25 17:38:57', 0),
(22, 20, 20, 50, '0.70', 1, '2017-09-25 17:38:57', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_stock`
--

CREATE TABLE `wp_shc_stock` (
  `id` int(11) NOT NULL,
  `lot_number` varchar(250) NOT NULL,
  `stock_count` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_stock_closing`
--

CREATE TABLE `wp_shc_stock_closing` (
  `id` int(11) NOT NULL,
  `closing_date` date NOT NULL,
  `modified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_stock_closing`
--

INSERT INTO `wp_shc_stock_closing` (`id`, `closing_date`, `modified_at`, `active`) VALUES
(1, '2017-07-31', '2017-10-24 11:06:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_unloading`
--

CREATE TABLE `wp_shc_unloading` (
  `id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `unloading_charge` decimal(15,2) NOT NULL,
  `master_id` int(11) NOT NULL,
  `return_date` datetime NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_unloading`
--

INSERT INTO `wp_shc_unloading` (`id`, `return_id`, `unloading_charge`, `master_id`, `return_date`, `active`) VALUES
(1, 1, '100.00', 1, '2017-08-29 07:04:00', 1),
(2, 2, '0.00', 3, '2017-07-15 00:00:00', 1),
(3, 3, '0.00', 3, '2017-07-26 00:00:00', 1),
(4, 4, '0.00', 3, '2017-08-22 00:00:00', 1),
(5, 5, '0.00', 3, '2017-08-29 00:00:00', 1),
(6, 6, '6200.00', 3, '2017-09-04 00:00:00', 1),
(7, 7, '0.00', 3, '2017-09-04 04:17:00', 1),
(8, 8, '0.00', 3, '2017-09-04 05:17:00', 1),
(9, 9, '350.00', 13, '2017-06-16 00:00:00', 1),
(10, 10, '0.00', 14, '2017-07-31 00:00:00', 1),
(11, 11, '100.00', 16, '2017-05-16 06:43:00', 1),
(12, 12, '500.00', 16, '2017-06-26 06:44:00', 1),
(13, 13, '350.00', 16, '2017-06-26 06:45:00', 1),
(14, 14, '700.00', 16, '2017-06-26 06:47:00', 1),
(15, 15, '300.00', 16, '2017-06-27 06:48:00', 1),
(16, 16, '0.00', 11, '2017-09-04 09:15:00', 1),
(17, 17, '0.00', 11, '2017-09-04 09:20:00', 1),
(18, 18, '0.00', 17, '2017-07-08 10:53:00', 1),
(19, 19, '250.00', 17, '2017-08-11 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_unloading_detail`
--

CREATE TABLE `wp_shc_unloading_detail` (
  `id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `unloading_id` int(11) NOT NULL,
  `charge_for` varchar(250) NOT NULL,
  `charge_amt` decimal(15,2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_unloading_detail`
--

INSERT INTO `wp_shc_unloading_detail` (`id`, `return_id`, `unloading_id`, `charge_for`, `charge_amt`, `active`) VALUES
(1, 1, 1, 'unloading', '100.00', 1),
(2, 1, 1, 'transportation', '0.00', 1),
(3, 1, 1, 'damage', '0.00', 1),
(4, 2, 2, 'unloading', '0.00', 1),
(5, 2, 2, 'transportation', '0.00', 1),
(6, 2, 2, 'damage', '0.00', 1),
(7, 3, 3, 'unloading', '0.00', 1),
(8, 3, 3, 'transportation', '0.00', 1),
(9, 3, 3, 'damage', '0.00', 1),
(10, 4, 4, 'unloading', '0.00', 1),
(11, 4, 4, 'transportation', '0.00', 1),
(12, 4, 4, 'damage', '0.00', 1),
(13, 5, 5, 'unloading', '0.00', 1),
(14, 5, 5, 'transportation', '0.00', 1),
(15, 5, 5, 'damage', '0.00', 1),
(16, 6, 6, 'unloading', '6200.00', 1),
(17, 6, 6, 'transportation', '0.00', 1),
(18, 6, 6, 'damage', '0.00', 1),
(19, 7, 7, 'unloading', '0.00', 1),
(20, 7, 7, 'transportation', '0.00', 1),
(21, 7, 7, 'damage', '0.00', 1),
(22, 8, 8, 'unloading', '0.00', 1),
(23, 8, 8, 'transportation', '0.00', 1),
(24, 8, 8, 'damage', '0.00', 1),
(25, 9, 9, 'unloading', '350.00', 1),
(26, 9, 9, 'transportation', '0.00', 1),
(27, 9, 9, 'damage', '0.00', 1),
(28, 10, 10, 'unloading', '0.00', 1),
(29, 10, 10, 'transportation', '0.00', 1),
(30, 10, 10, 'damage', '0.00', 1),
(31, 11, 11, 'unloading', '100.00', 1),
(32, 11, 11, 'transportation', '0.00', 1),
(33, 11, 11, 'damage', '0.00', 1),
(34, 12, 12, 'unloading', '500.00', 1),
(35, 12, 12, 'transportation', '0.00', 1),
(36, 12, 12, 'damage', '0.00', 1),
(37, 13, 13, 'unloading', '350.00', 1),
(38, 13, 13, 'transportation', '0.00', 1),
(39, 13, 13, 'damage', '0.00', 1),
(40, 14, 14, 'unloading', '500.00', 1),
(41, 14, 14, 'transportation', '0.00', 1),
(42, 14, 14, 'damage', '200.00', 1),
(43, 15, 15, 'unloading', '300.00', 1),
(44, 15, 15, 'transportation', '0.00', 1),
(45, 15, 15, 'damage', '0.00', 1),
(46, 16, 16, 'unloading', '0.00', 1),
(47, 16, 16, 'transportation', '0.00', 1),
(48, 16, 16, 'damage', '0.00', 1),
(49, 17, 17, 'unloading', '0.00', 1),
(50, 17, 17, 'transportation', '0.00', 1),
(51, 17, 17, 'damage', '0.00', 1),
(52, 18, 18, 'unloading', '0.00', 1),
(53, 18, 18, 'transportation', '0.00', 1),
(54, 18, 18, 'damage', '0.00', 1),
(55, 19, 19, 'unloading', '0.00', 1),
(56, 19, 19, 'transportation', '250.00', 1),
(57, 19, 19, 'damage', '0.00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_shc_admin_history`
--
ALTER TABLE `wp_shc_admin_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_companies`
--
ALTER TABLE `wp_shc_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_companies_master`
--
ALTER TABLE `wp_shc_companies_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_customers`
--
ALTER TABLE `wp_shc_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_customer_site`
--
ALTER TABLE `wp_shc_customer_site`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_delivery`
--
ALTER TABLE `wp_shc_delivery`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wp_shc_delivery_detail`
--
ALTER TABLE `wp_shc_delivery_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_deposit`
--
ALTER TABLE `wp_shc_deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_deposit_cheque`
--
ALTER TABLE `wp_shc_deposit_cheque`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_deposit_detail`
--
ALTER TABLE `wp_shc_deposit_detail`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wp_shc_employees`
--
ALTER TABLE `wp_shc_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_employee_attendance`
--
ALTER TABLE `wp_shc_employee_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_hiring`
--
ALTER TABLE `wp_shc_hiring`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_hiring_detail`
--
ALTER TABLE `wp_shc_hiring_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_loading`
--
ALTER TABLE `wp_shc_loading`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_loading_detail`
--
ALTER TABLE `wp_shc_loading_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_lost`
--
ALTER TABLE `wp_shc_lost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_lost_detail`
--
ALTER TABLE `wp_shc_lost_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_lots`
--
ALTER TABLE `wp_shc_lots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_master`
--
ALTER TABLE `wp_shc_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_obc_cheque`
--
ALTER TABLE `wp_shc_obc_cheque`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_quotation`
--
ALTER TABLE `wp_shc_quotation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_quotation_detail`
--
ALTER TABLE `wp_shc_quotation_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_return`
--
ALTER TABLE `wp_shc_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_return_damage`
--
ALTER TABLE `wp_shc_return_damage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_return_damage_detail`
--
ALTER TABLE `wp_shc_return_damage_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_return_detail`
--
ALTER TABLE `wp_shc_return_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_special_price`
--
ALTER TABLE `wp_shc_special_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_stock`
--
ALTER TABLE `wp_shc_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_stock_closing`
--
ALTER TABLE `wp_shc_stock_closing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_unloading`
--
ALTER TABLE `wp_shc_unloading`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_shc_unloading_detail`
--
ALTER TABLE `wp_shc_unloading_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_shc_admin_history`
--
ALTER TABLE `wp_shc_admin_history`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=361;
--
-- AUTO_INCREMENT for table `wp_shc_companies`
--
ALTER TABLE `wp_shc_companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_shc_companies_master`
--
ALTER TABLE `wp_shc_companies_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_shc_customers`
--
ALTER TABLE `wp_shc_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `wp_shc_customer_site`
--
ALTER TABLE `wp_shc_customer_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `wp_shc_delivery`
--
ALTER TABLE `wp_shc_delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;
--
-- AUTO_INCREMENT for table `wp_shc_delivery_detail`
--
ALTER TABLE `wp_shc_delivery_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- AUTO_INCREMENT for table `wp_shc_deposit`
--
ALTER TABLE `wp_shc_deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `wp_shc_deposit_cheque`
--
ALTER TABLE `wp_shc_deposit_cheque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `wp_shc_deposit_detail`
--
ALTER TABLE `wp_shc_deposit_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;
--
-- AUTO_INCREMENT for table `wp_shc_employees`
--
ALTER TABLE `wp_shc_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_shc_employee_attendance`
--
ALTER TABLE `wp_shc_employee_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_shc_hiring`
--
ALTER TABLE `wp_shc_hiring`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `wp_shc_hiring_detail`
--
ALTER TABLE `wp_shc_hiring_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=316;
--
-- AUTO_INCREMENT for table `wp_shc_loading`
--
ALTER TABLE `wp_shc_loading`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `wp_shc_loading_detail`
--
ALTER TABLE `wp_shc_loading_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `wp_shc_lost`
--
ALTER TABLE `wp_shc_lost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_shc_lost_detail`
--
ALTER TABLE `wp_shc_lost_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_shc_lots`
--
ALTER TABLE `wp_shc_lots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `wp_shc_master`
--
ALTER TABLE `wp_shc_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `wp_shc_obc_cheque`
--
ALTER TABLE `wp_shc_obc_cheque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `wp_shc_quotation`
--
ALTER TABLE `wp_shc_quotation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_shc_quotation_detail`
--
ALTER TABLE `wp_shc_quotation_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `wp_shc_return`
--
ALTER TABLE `wp_shc_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `wp_shc_return_damage`
--
ALTER TABLE `wp_shc_return_damage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `wp_shc_return_damage_detail`
--
ALTER TABLE `wp_shc_return_damage_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_shc_return_detail`
--
ALTER TABLE `wp_shc_return_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `wp_shc_special_price`
--
ALTER TABLE `wp_shc_special_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `wp_shc_stock`
--
ALTER TABLE `wp_shc_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_shc_stock_closing`
--
ALTER TABLE `wp_shc_stock_closing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_shc_unloading`
--
ALTER TABLE `wp_shc_unloading`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `wp_shc_unloading_detail`
--
ALTER TABLE `wp_shc_unloading_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
