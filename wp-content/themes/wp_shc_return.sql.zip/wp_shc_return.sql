--
-- Database: `benvin`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_shc_return`
--

CREATE TABLE `wp_shc_return` (
  `id` int(11) NOT NULL,
  `master_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_return` int(2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_shc_return`
--

INSERT INTO `wp_shc_return` (`id`, `master_id`, `return_date`, `created_at`, `is_return`, `active`) VALUES
(1, 2, '2016-11-05', '2017-07-17 11:36:26', 1, 1),
(2, 2, '2016-11-07', '2017-07-17 11:38:06', 1, 1),
(3, 2, '2016-11-08', '2017-07-17 11:39:12', 1, 1),
(4, 2, '2016-10-18', '2017-07-27 14:17:03', 1, 1),
(5, 2, '2016-09-15', '2017-07-27 14:20:56', 1, 1),
(6, 2, '2016-09-15', '2017-07-27 14:32:43', 1, 1),
(7, 2, '2016-09-10', '2017-07-29 17:06:31', 1, 1),
(8, 3, '2017-06-24', '2017-08-09 13:26:37', 1, 1),
(9, 4, '2017-03-06', '2017-08-09 15:44:09', 1, 1),
(10, 4, '2017-03-23', '2017-08-09 15:44:59', 1, 1),
(11, 4, '2017-04-07', '2017-08-09 15:45:50', 1, 1),
(12, 4, '2017-05-02', '2017-08-09 15:46:57', 1, 1),
(13, 4, '2017-06-13', '2017-08-09 15:47:28', 1, 1),
(14, 4, '2017-06-30', '2017-08-09 15:47:53', 1, 1),
(15, 6, '2017-05-16', '2017-08-09 17:50:08', 1, 1),
(16, 5, '2017-01-18', '2017-08-14 11:59:32', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_shc_return`
--
ALTER TABLE `wp_shc_return`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_shc_return`
--
ALTER TABLE `wp_shc_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
