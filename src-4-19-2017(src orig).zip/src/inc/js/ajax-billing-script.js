jQuery(document).ready(function(){

  jQuery('#billing_customer').select2({
      allowClear: true,
      width: '100%',
      multiple: false,
      minimumInputLength: 1,
      ajax: {
          type: 'POST',
          url: frontendajax.ajaxurl,
          delay: 250,
          dataType: 'json',
          data: function(params) {
            return {
              action: 'get_customer_name', // search term
              page: 1,
              search_key: params.term,
            };
          },
          processResults: function(data) {
            var results = [];
            return {
                results: jQuery.map(data.result, function(obj) {
                    return { id: obj.id, customer_name: obj.name, mobile: obj.mobile, type: obj.type.toLowerCase() };
                })
            };
          },
          cache: true
      },
      templateResult: formatCustomerNameResult,
      templateSelection: formatCustomerName
  }).on("select2:select", function (e) {
    jQuery("input[name=customer_type][value='"+e.params.data.type+"']").attr('checked', 'checked');

    //Generate Invoice id
    if(jQuery('#billing_no').val() == '') {
      generateBill(e.params.data.id);
    }

    
  });

});

    function formatCustomerName (state) {
      if (!state.id) {
        return state.id;
      }
      var $state = jQuery(
        '<span>' +
          state.customer_name +
        '</span>'
      );
      return $state;
    };

    function formatCustomerNameResult(data) {
      if (!data.id) { // adjust for custom placeholder values
        return 'Searching ...';
      }
      var $state = jQuery(
        '<span>Name : ' +
          data.customer_name +
        '</span>' +
        '<br><span> Mobile : ' +
          data.mobile +
        '</span>'
      );
      return $state;
    }

    function generateBill(customer_id = 0) {
      var bill_date = jQuery('#billing_date').val();
      var center = jQuery('input[name="shop_name"]:checked').val();


      jQuery.ajax({
          type: "POST",
          url: frontendajax.ajaxurl,
          data: {
            action : 'create_bill_invoice',
            bill_date : bill_date,
            center : center,
            customer_id : customer_id,
          },
          success: function (data) {
            var obj = jQuery.parseJSON(data);
            if(obj.success == 1) {
              jQuery('#billing_no').val(obj.bill_id);
              jQuery('#invoice_id').val(obj.invoice_id);

              jQuery('.bill_submit').css('display','block');
              jQuery('.bill_submit').attr('data-billno', obj.bill_id);
            }

          }
      });
    }




jQuery('.bill_submit').live('click', function(){

  console.log(jQuery(this).attr('data-billno'));


    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
          action : 'update_bill',
          bill_data : jQuery('#new_billing :input').serialize(),
        },
        success: function (data) {
          var obj = jQuery.parseJSON(data);
          if(obj.success == 1) {
            window.location.replace('admin.php?page=new_billing&bill_no='+obj.billing_no+'&action=invoice');
          } else {
            alert('Something went wrong!');
          }
        }
    });

});




jQuery(document).ready(function(){
  jQuery('.print_bill').on('click',function(){
      var inv_id = jQuery(this).attr('data-inv-id');
      var datapass =   home_page.url+'invoice?inv_id='+inv_id;

      // billing_list_single
      var thePopup = window.open( datapass, "Customer Listing","scrollbars=yes,menubar=0,location=0,top=50,left=300,height=500,width=750" );
        thePopup.print();  
  });
});


jQuery('#ck_stk_available').live('click', function(){
  if(jQuery('.stock_ck_avail_box').hasClass('active') == true) {
    jQuery('.stock_ck_avail_box').removeClass('active');
    jQuery('.stock_ck_avail_box').addClass('active-n');
  } else {
    jQuery('.stock_ck_avail_box').removeClass('active-n');
    jQuery('.stock_ck_avail_box').addClass('active');
  }
});

jQuery('#close_check_availa_box').live('click', function(){
  jQuery('.stock_ck_avail_box').removeClass('active');
  jQuery('.stock_ck_avail_box').addClass('active-n');
});







//Payment method script

jQuery(document).ready(function(){


  jQuery('.payment_cash').on('click',function(){

    jQuery('.payment-container').css('display','none');
    jQuery('.cash-container').css('display','none');

    jQuery('.cash-container input').val(0).change();
    jQuery('.cash-container').find('.cash-amt').text(0);

    populateBill();







  });

  jQuery('.cash_payment .c_cash').live('change',function(){
    var cash_tot = 0;
    jQuery('.cash_payment .c_cash').parent().parent().each(function(){
      cash_tot += Number(jQuery(this).find('.c_cash').val());
    })
    jQuery(this).parent().parent().parent().parent().find('.payment_final').val(cash_tot).change();
  });

  jQuery('.card_payment .c_cash').live('change',function(){
    var card_tot = 0;
    jQuery('.card_payment .c_cash').parent().parent().each(function(){
      card_tot += Number(jQuery(this).find('.c_cash').val());
    })
    jQuery(this).parent().parent().parent().parent().find('.payment_final').val(card_tot).change();
  });

  jQuery('.neft_payment .c_cash').live('change',function(){
    var neft_tot = 0;
    jQuery('.neft_payment .c_cash').parent().parent().each(function(){
      neft_tot += Number(jQuery(this).find('.c_cash').val());
    })
    jQuery(this).parent().parent().parent().parent().find('.payment_final').val(neft_tot).change();
  });

  jQuery('.cheque_payment .c_cash').live('change',function(){
    var cheque_tot = 0;
    jQuery('.cheque_payment .c_cash').parent().parent().each(function(){
      cheque_tot += Number(jQuery(this).find('.c_cash').val());
    })
    jQuery(this).parent().parent().parent().parent().find('.payment_final').val(cheque_tot).change();
  });  






  jQuery('.payment_final').live('change',function(){
    var payment_mode = jQuery(this).attr('data-mode');
    var payment_total = jQuery(this).val();
    populateBill();
  });


  jQuery('.cash-container input').live('change', function(){
    var paid_total = 0;
    var fee_total = 0;
    jQuery('.cash-container input').each(function(e, a){
      paid_total += Number(jQuery(this).val());
    });
    jQuery('.cash_total').text(paid_total);
    jQuery('.cash_total_input').val(paid_total);
    jQuery('.fee-span').text();

    fee_total = (1.5/100)*Number(jQuery('input.card_input').val());
    jQuery('.fee-span').text(fee_total.toFixed(2));

    jQuery('.total-pay-span').text(paid_total + fee_total);

    var sub_total = jQuery('.final_total').val();
    jQuery('.balance-pay-span').text(sub_total - paid_total);

  });



  jQuery('.final_total').on('change', function(){
    populateBill();
  })
});


function populateBill() {

    jQuery('.payment_cash:checked').each(function(){

      var content = jQuery(this).val();
      var content_id = '#'+content;
      var content_class = '.'+content;

      jQuery(content_id).css('display','block');
      jQuery(content_class).css('display','block');

      var amt_val = jQuery(content_id).find('.payment_final').val();

      jQuery(content_class).find('.cash-amt').text(amt_val);
      jQuery(content_class).find('input').val(amt_val).change();
    });

}

