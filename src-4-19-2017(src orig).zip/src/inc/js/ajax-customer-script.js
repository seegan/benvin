jQuery('a.customer_edit').live('click', function(e) {
    e.preventDefault();
    jQuery('#src_info_box').bPopup();
});

jQuery('#edit_customer .submit-button').live('click',function () {
    var customer_name = jQuery('#edit_customer #customer_name').val();
    var customer_mobile = jQuery('#edit_customer #customer_mobile').val();
    var customer_address = jQuery('#edit_customer #customer_address').val();
    var customer_type = jQuery('#edit_customer #customer_type').val();
    var customer_id = jQuery('#edit_customer #customer_id').val();

    if(customer_id != '' && customer_name != '' && customer_mobile != '' && validatePhone(customer_mobile) ) {
        customer_edit_submit_popup('post_customer_edit_popup', 'dummy');
    } else {
        alert_popup('<span class="error_msg">Enter the mandatory fields!!</span>', 'Alert!');
    }
});




jQuery('.popup-add-customer').live('click', function() {
    create_popup('get_customer_create_form_popup', 'Add New Customer');
});
jQuery('a.customer_edit').live('click', function() {
    customer_edit_popup('edit_customer_create_form_popup', 'Edit Customer', this);
});


function customer_edit_popup(action= '', title = '', data = '') {

    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
            key : 'edit_popup_content',
            action : action,
            id : jQuery(data).data('id'),
            roll_id : jQuery(data).data('roll'),
        },
        success: function (data) {
            jQuery('#popup-title').html(title);
            clear_main_popup();
            jQuery('#popup-content').html(data);
        }
    });
}



function customer_create_submit_popup(action = '', data = '') {
    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
        	key : 'post_popup_content',
			data : jQuery("#add_customer").serialize(),
            action : action
        },
        success: function (data) {

            if (/^[\],:{}\s]*$/.test(data.replace(/\\["\\\/bfnrtu]/g, '@').
            replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
            replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

                var obj = jQuery.parseJSON(data);
                if(obj.success == 0) {
                    alert_popup('<span class="error_msg">Something Went Wrong! try again!</span>', 'Error');
                } else {
                    clear_main_popup();
                    jQuery('#src_info_box').bPopup().close();
                    alert_popup('<span class="success_msg">Customer Account Created!</span>', 'Success');   
                }
            } else {
                jQuery('.list_customers').html(data);
                clear_main_popup();
                jQuery('#src_info_box').bPopup().close();
                alert_popup('<span class="success_msg">Customer Account Created!</span>', 'Success'); 
            }
        }
    });
}


function customer_edit_submit_popup(action = '', data = '') {
    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
            key : 'edit_popup_content',
            data : jQuery("#edit_customer").serialize(),
            action : action
        },
        success: function (data) {
                var obj = jQuery.parseJSON(data);
                if(obj.success == 1) {
                    var update_row = "#customer-data-"+obj.id;
                    jQuery(update_row).html(obj.content);
                    clear_main_popup();
                    jQuery('#src_info_box').bPopup().close();
                    alert_popup('<span class="success_msg">Customer Updated!</span>', 'Success'); 

                } else {
                    alert_popup('<span class="error_msg">Can\'t Edit this data try again!</span>', 'Error');  
                }
        }
    });
}






function validatePhone(txtPhone) {
    var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
    if (filter.test(txtPhone)) {
        return true;
    }
    else {
        return false;
    }
}

function clear_main_popup() {
	jQuery('#popup-content').html('');   
    jQuery('#popup-content-s').html('');          	
}

function clear_alert_popup() {
	jQuery('#popup-title_alert').html('');
	jQuery('#popup-content_alert .err_message').html('');           	
}

function alert_popup(msg = '', title = '') {
	clear_alert_popup();
	jQuery('#popup-title_alert').html(title);
    if(title == 'Error') {
        jQuery('#popup-content_alert .succ_message').css('display','none');
        jQuery('#popup-content_alert .err_message').css('display','block');

        jQuery('#popup-content_alert .err_message').html(msg);

    }
    if(title = 'Success') {
        jQuery('#popup-content_alert .succ_message').css('display','block');
        jQuery('#popup-content_alert .err_message').css('display','none');

        jQuery('#popup-content_alert .succ_message').html(msg);
    }

	jQuery('#my-button1').click();
}



/*Updated for filter 11/10/16*/
jQuery('.customer_filter #per_page, .customer_filter #customer_name, .customer_filter #customer_mobile, .customer_filter #customer_type').live('change', function(){

    var per_page = jQuery('#per_page').val();
    var customer_name = jQuery('#customer_name').val();
    var customer_mobile = jQuery('#customer_mobile').val();
    var customer_type = jQuery('#customer_type').val();


    jQuery.ajax({
      type: "POST",
      url: frontendajax.ajaxurl,
      data: {
          per_page : per_page,
          customer_name : customer_name,
          customer_mobile : customer_mobile,
          customer_type : customer_type,
          action : 'customer_list_filter'
      },

      success: function (data) {

          if (/^[\],:{}\s]*$/.test(data.replace(/\\["\\\/bfnrtu]/g, '@').
          replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
          replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

              var obj = jQuery.parseJSON(data);
              if(obj.success == 0) {
                  alert_popup('<span class="error_msg">Something Went Wrong! try again!</span>', 'Error');
              }
          } else {
              jQuery('.list_customers').html(data);
          }
      }
    }); 
});


jQuery(document).ready(function(){
    jQuery("#search_from" ).datepicker({dateFormat: "yy-mm-dd"});
    jQuery("#search_to" ).datepicker({dateFormat: "yy-mm-dd"});
});
/*End Updated for filter 11/10/16*/