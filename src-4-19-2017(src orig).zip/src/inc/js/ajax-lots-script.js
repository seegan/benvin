jQuery('.popup-add-lot').live('click', function() { 
  create_popup('get_lot_create_form_popup', 'Add New Lot');
});

jQuery('a.lot_edit').live('click', function() {
  edit_popup('edit_lot_create_form_popup', 'Edit Lot', this);
});


jQuery('a.lot_edit').live('click', function(e) {
    e.preventDefault();
    jQuery('#src_info_box').bPopup();
}, function() {
  setTimeout(function() {
      jQuery('#src_info_box').bPopup().reposition();
  }, 200);
});



jQuery('.bagweight .bag_weight').live('change', function() {
    var bag_weight_checked = jQuery('input[name=bag_weight]:checked').val();
    jQuery('input[name=slab_system]').val(bag_weight_checked);

   if(bag_weight_checked == '1') {
    jQuery('.dummy_slot_number').css('display','block');

    jQuery('.group_retail').css('display','block');
    jQuery('.group_retail_no_slab').css('display','none');

    jQuery('.group_wholesale').css('display','block');
    jQuery('.wholesale_no_slab').css('display','none');


   }
   if(bag_weight_checked == '0') {
    jQuery('.dummy_slot_number').css('display','none');

    jQuery('.group_retail').css('display','none');
    jQuery('.group_retail_no_slab').css('display','block');

    jQuery('.group_wholesale').css('display','none');
    jQuery('.wholesale_no_slab').css('display','block');

   }
});




jQuery('.slab .dummy_slab_system').live('change', function() {
   var slab_system_checked = jQuery('input[name=dummy_slab_system]:checked').val();


   if(slab_system_checked == '1') {
      jQuery('.group_retail_dummy').css('display','block');
      jQuery('.retail_no_slab_dummy').css('display','none');

      jQuery('.group_wholesale_dummy').css('display','block');
      jQuery('.wholesale_no_slab_dummy').css('display','none');

   }
   if(slab_system_checked == '0') {
      jQuery('.group_retail_dummy').css('display','none');
      jQuery('.retail_no_slab_dummy').css('display','block');

      jQuery('.group_wholesale_dummy').css('display','none');
      jQuery('.wholesale_no_slab_dummy').css('display','block');
   }
});















/*form submit*/


jQuery('#add_lot').live('submit', function(){
    var lot_number = jQuery('#lot_number').val();
    var brand_name = jQuery('#brand_name').val();
    var product_name = jQuery('#product_name').val();
    var weight = jQuery('#weight').val();

    if(lot_number != '' && brand_name != '' && product_name != '' && weight != '' ) {
         lot_create_submit_popup('lot_create_submit_popup');
    } else {
         alert_popup('<span class="error_msg">Enter the mandatory fields!!</span>', 'Alert!');
    }
});


function lot_create_submit_popup(action = '', data = '') {
    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
            data : jQuery("#add_lot").serialize(),
            action : action
        },

        success: function (data) {

            if (/^[\],:{}\s]*$/.test(data.replace(/\\["\\\/bfnrtu]/g, '@').
            replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
            replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

                var obj = jQuery.parseJSON(data);
                if(obj.success == 0) {
                    alert_popup('<span class="error_msg">Something Went Wrong! try again!</span>', 'Error');
                } else {
                    clear_main_popup();
                    jQuery('#src_info_box').bPopup().close();
                    alert_popup('<span class="success_msg">CLot Created!</span>', 'Success');   
                }
            } else {
                jQuery('.list_customers').html(data);
                clear_main_popup();
                jQuery('#src_info_box').bPopup().close();
                alert_popup('<span class="success_msg">Lot Created!</span>', 'Success'); 
            }
        }

    });
}



/*form edit*/


jQuery('#edit_lot').live('submit', function(){
    var lot_number = jQuery('#lot_number').val();
    var brand_name = jQuery('#brand_name').val();
    var product_name = jQuery('#product_name').val();
    var weight = jQuery('#weight').val();

    if(lot_number != '' && brand_name != '' && product_name != '' && weight != '' ) {
         lot_update_submit_popup('lot_update_submit_popup');
    } else {
         alert_popup('<span class="error_msg">Enter the mandatory fields!!</span>', 'Alert!');
    }
});


function lot_update_submit_popup(action = '', data = '') {
    jQuery.ajax({
        type: "POST",
        url: frontendajax.ajaxurl,
        data: {
            data : jQuery("#edit_lot").serialize(),
            action : action
        },

        success: function (data) {
          var obj = jQuery.parseJSON(data);
          if(obj.success == 1) {
              clear_main_popup();
              jQuery('#src_info_box').bPopup().close();
              alert_popup('<span class="success_msg">Lot Updated!</span>', 'Success'); 

          } else {
              alert_popup('<span class="error_msg">Can\'t Edit this data, Try again!</span>', 'Error');  
          }
        }

    });
}

/*Updated for filter 11/10/16*/
jQuery('.lot_filter #per_page, .lot_filter #search_lot, .lot_filter #search_brand, .lot_filter #search_product').live('change', function(){

  var per_page = jQuery('#per_page').val();
  var lot_number = jQuery('#search_lot').val();
  var search_brand = jQuery('#search_brand').val();
  var search_product = jQuery('#search_product').val();



  jQuery.ajax({
      type: "POST",
      url: frontendajax.ajaxurl,
      data: {
          per_page : per_page,
          lot_number : lot_number,
          search_brand : search_brand,
          search_product : search_product,
          action : 'lot_list_filter'
      },

      success: function (data) {

          if (/^[\],:{}\s]*$/.test(data.replace(/\\["\\\/bfnrtu]/g, '@').
          replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
          replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

              var obj = jQuery.parseJSON(data);
              if(obj.success == 0) {
                  alert_popup('<span class="error_msg">Something Went Wrong! try again!</span>', 'Error');
              }
          } else {
              jQuery('.list_customers').html(data);
          }
      }
  });
});
/*End Updated for filter 11/10/16*/