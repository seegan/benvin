<?php
add_action('admin_menu', 'admin_menu_register');

function admin_menu_register(){

	add_menu_page(
	    __( 'Stocks', 'src'),
	    'Stocks',
	    'lot_list',
	    'stock',
	    'list_lots',
	    'dashicons-welcome-widgets-menus',
	    8
	);
	add_submenu_page('stock', 'Lot List', 'Lot List', 'lot_list', 'stock', 'list_lots' );
	add_submenu_page('stock', 'Stock List', 'Stock List', 'stock_list', 'list_stocks', 'list_stocks' );




	add_menu_page(
	    __( 'Customers', 'src'),
	    'Customers',
	    'customers',
	    'customer',
	    'list_customers',
	    'dashicons-groups',
	    8
	);


	add_menu_page(
	    __( 'Admin Users', 'src'),
	    'Admin Users',
	    'add_new_user',
	    'admin_users',
	    'add_admin_users',
	    'dashicons-id',
	    9
	);
	add_submenu_page('admin_users', 'New Admin User', 'New Admin User', 'add_new_user', 'admin_users', 'add_admin_users' );
	add_submenu_page('admin_users', 'Admin Users List', 'Admin Users List', 'user_list', 'list_admin_users', 'list_admin_users' );
	add_submenu_page('admin_users', 'Admin Roles', 'Admin Roles', 'manage_options', 'list_role', 'list_admin_roles' );
	add_submenu_page('admin_users', 'Add Admin Roles', 'Add Admin Roles', 'manage_options', 'add_role', 'add_admin_roles' );


	add_menu_page(
	    __( 'Sales & Others', 'src'),
	    'Sales & Others',
	    'purchase_sales',
	    'sales_others',
	    'billing_list',
	    'dashicons-list-view',
	    8
	);
	add_submenu_page('sales_others', 'Billing List', 'Billing List', 'purchase_sales', 'sales_others', 'billing_list' );
	add_submenu_page('sales_others', 'New Billing', 'New Billing', 'purchase_sales', 'new_billing', 'new_billing' );
	add_submenu_page('sales_others', 'Petty Cash', 'Petty Cash', 'petty_cash', 'petty_cash', 'petty_cash' );
	add_submenu_page('sales_others', 'Income List', 'Income List', 'income_list', 'income_list', 'income_list' );


	add_menu_page(
	    __( 'Employee List', 'src'),
	    'Employee',
	    'add_new_employee',
	    'employee_list',
	    'employee_list',
	    'dashicons-businessman',
	    8
	);
	add_submenu_page('employee_list', 'Employee List', 'Employee List', 'add_new_employee', 'employee_list', 'employee_list' );
	add_submenu_page('employee_list', 'Attendance List', 'Attendance List', 'attendance_list', 'attendance_list', 'attendance_list' );
	add_submenu_page('employee_list', 'Salary List', 'Salary List', 'salary_list', 'salary_list', 'salary_list' );



	add_menu_page(
	    __( 'Report', 'src'),
	    'Report',
	    'reports',
	    'report_list',
	    'report_list',
	    'dashicons-clipboard',
	    9
	);
	add_submenu_page('report_list', 'Stock Status Report', 'Stock Status Report', 'reports', 'report_list', 'report_list' );
	add_submenu_page('report_list', 'Stock Sale Report', 'Stock Sale Report', 'manage_options', 'sale_report_list', 'sale_report_list' );
}





function list_lots() {
    require 'stocks/list_lots.php';
}
function list_stocks() {
    require 'stocks/list_stocks.php';	
}




function list_customers() {
    require 'customers/list_customers.php';
}


function add_admin_users() {
    require 'admin-users/add_admin.php';
}
function list_admin_users() {
    require 'admin-users/list_admin.php';
}

function add_admin_roles() {
    require 'admin-users/add_role.php';
}
function list_admin_roles() {
    require 'admin-users/list_role.php';
}



function billing_list() {
    require 'sales/list_billing.php';
}
function new_billing() {
	require 'sales/add_billing.php';
}
function petty_cash() {
	require 'sales/petty_cash.php';
}
function income_list() {
	require 'sales/income_list.php';
}


function employee_list() {
	require 'employee/list_employee.php';
}
function attendance_list() {
	require 'employee/list_attendance.php';
}
function salary_list() {
	require 'employee/list_salary.php';
}


function report_list() {
	require 'report/list_report.php';
}
function sale_report_list() {
	require 'report/list_sale_report.php';
}






add_action( 'admin_bar_menu', 'wp_admin_bar_my_custom_account_menu', 11 );
function wp_admin_bar_my_custom_account_menu( $wp_admin_bar ) {
	$user_id = get_current_user_id();
	$current_user = wp_get_current_user();
	$profile_url = get_edit_profile_url( $user_id );

	if ( 0 != $user_id ) {
		/* Add the "My Account" menu */
		$avatar = get_avatar( $user_id, 28 );
		$howdy = sprintf( __('Welcome, %1$s'), $current_user->display_name );
		$class = empty( $avatar ) ? '' : 'with-avatar';

		$wp_admin_bar->add_menu( array(
		'id' => 'my-account',
		'parent' => 'top-secondary',
		'title' => $howdy . $avatar,
		'href' => $profile_url,
		'meta' => array(
		'class' => $class,
		),
		) );

	}
}

function my_admin_bar_render() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('comments');
    $wp_admin_bar->remove_menu('updates');
    $wp_admin_bar->remove_menu('new-content');

}
add_action( 'wp_before_admin_bar_render', 'my_admin_bar_render' );