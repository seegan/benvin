<?php
$lot_id = isset( $_POST['id'] ) ? $_POST['id'] : 0;
$lot_details = get_lot($lot_id);

$original_slab_system = $lot_details['lot_data']->slab_system;
$original_bag_weight = $lot_details['lot_data']->bag_weight;

$dummy_slab_system = $lot_details['dummy_lot_data']->slab_system;



//echo "<pre>";
//var_dump($lot_details);
?>
<style type="text/css">

</style>
<div class="form-grid">
	<form method="post" name="edit_lot" id="edit_lot" class="popup_form" onsubmit="return false;">
		<input type="hidden" name="lot_id" value="<?php echo $lot_details['lot_original_id']; ?>">
		<input type="hidden" name="dummy_lot_id" value="<?php echo $lot_details['lot_dummy_id']; ?>">
		<div class="form_detail">
			<label>Enter Lot
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="lot_number" value="<?php echo $lot_details['lot_number']; ?>" name="lot_number">
		</div>
		<div class="form_detail">
			<label style="width: 115px;">Brand Name 
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="brand_name" name="brand_name" autocomplete="off" value="<?php echo $lot_details['lot_data']->brand_name; ?>">
		</div>
		<div class="form_detail">
			<label>Product Name
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<select name="product_name" id="product_name">
		        <option selected><?php echo $lot_details['lot_data']->product_name; ?></option>
		        <option>R.R</option>
		        <option>Idly</option>
		        <option>B.R</option>
		        <option>Wheat</option>
		        <option>R.R.(T)</option>
		        <option>Idly-IR 20</option>
		        <option>Basmati</option>
		        <option>R.H</option>
		        <option>25 KG B.R</option>
		        <option>Others</option>
		    </select>
		</div>
		<div class="form_detail">
			<label style="width: 115px;">Weight
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<select name="weight">
				<option <?php echo ($lot_details['lot_data']->weight == 5) ? 'selected' : ''; ?> value="5">5kg</option>
				<option <?php echo ($lot_details['lot_data']->weight == 10) ? 'selected' : ''; ?> value="10">10kg</option>
				<option <?php echo ($lot_details['lot_data']->weight == 25) ? 'selected' : ''; ?> value="25">25kg</option>
				<option <?php echo ($lot_details['lot_data']->weight == 50) ? 'selected' : ''; ?> value="50">50kg</option>
				<option <?php echo ($lot_details['lot_data']->weight == 75) ? 'selected' : ''; ?> value="75">75kg</option>
			</select>
		</div>


		<div class="form_detail">
			<label>
				Stock Alert (Kg)
			</label>
			<div class="slab">
				<input type="text" name="stock_alert" class="stock_alert" autocomplete="off" value="<?php echo $lot_details['lot_data']->stock_alert; ?>">

				<input type="text" name="product_name1" id="product_name1" style="display:none;">
				<input type="hidden" name="slab_system" id="slab_system" value="<?php echo $original_bag_weight; ?>">
			</div>
		</div>

		<div class="form_detail">
			<label>
				Basic Price (Rs)
			</label>
			<div class="slab">
				<input type="text" name="basic_price" class="basic_price" autocomplete="off" value="<?php echo $lot_details['lot_data']->basic_price; ?>">
			</div>
		</div>

		<div class="form_detail">
			<label>Consider Bag weight?
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<div style="float:right;margin-top: 10px;margin-right: 25px;" class="bagweight">
				<input type="radio" name="bag_weight" class="bag_weight" value="1" <?php echo ($original_bag_weight == '1') ? 'checked' : ''; ?>> Yes &nbsp;&nbsp;
				<input type="radio" name="bag_weight" class="bag_weight" value="0" <?php echo ($original_bag_weight == '1') ? '' : 'checked'; ?>> No
			</div>

		</div>

		<div style="clear:both;"></div>
		<div class="table-simple price_range" style="width: 97%;">
			<h3>Retail Sale Price Range</h3>


				<div class="retail-repeater group_retail" style="display:<?php echo ($original_slab_system == '1') ? 'block' : 'none'; ?>;">

				  	<div data-repeater-list="group_retail" class="div-table">
					    <div class="div-table-row">
						    <div class="div-table-head">S.No</div>
						    <div class="div-table-head">From Weight</div>
						    <div class="div-table-head">To Weight</div>
						    <div class="div-table-head">Price</div>
						    <div class="div-table-head">Option</div>
						</div>

<?php
if( $lot_details['original_retail'] && $original_slab_system == '1' && count($lot_details['original_retail'])>0 ) {
	foreach ($lot_details['original_retail'] as $or_value) {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off" value="<?php echo $or_value->weight_from; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off" value="<?php echo $or_value->weight_to; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off" value="<?php echo $or_value->price; ?>">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

<?php
}

?>
				    </div>

				    	<ul class="icons-labeled">
							<li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add Price Range Retail Sale</a></li>
						</ul>
				</div>



				<div class="group_retail_no_slab" style="display:<?php echo ($original_slab_system == '1') ? 'none' : 'block'; ?>;">
				  	<div class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">From Weight</div>
						    <div class="div-table-head">To Weight</div>
						    <div class="div-table-head">Price</div>
						</div>

<?php
if( $lot_details['original_retail'] && $original_slab_system != '1' && count($lot_details['original_retail'])>0 ) {
	foreach ($lot_details['original_retail'] as $orns_value) {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_retail_no_slab" class="weight_from" autocomplete="off" value="<?php echo $orns_value->weight_from; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_retail_no_slab" class="weight_to" autocomplete="off" value="<?php echo $orns_value->weight_to; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_retail_no_slab" class="price" autocomplete="off" value="<?php echo $orns_value->price; ?>">
						    </div>
				        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_retail_no_slab" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_retail_no_slab" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_retail_no_slab" class="price" autocomplete="off">
						    </div>
				        </div>
<?php
}
?>
				    </div>
				</div>


			<h3>Wholesale Price Range</h3>

				<div class="retail-wholesale group_wholesale" style="display:<?php echo ($original_slab_system == '1') ? 'block' : 'none'; ?>;">
				  	<div data-repeater-list="group_wholesale" class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">S.No</div>
						    <div class="div-table-head">From Weight</div>
						    <div class="div-table-head">To Weight</div>
						    <div class="div-table-head">Price</div>
						    <div class="div-table-head">Option</div>
						</div>

<?php
if( $lot_details['original_wholesale'] && $original_slab_system == '1' && count($lot_details['original_wholesale'])>0 ) {
	foreach ($lot_details['original_wholesale'] as $ow_value) {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off" value="<?php echo $ow_value->weight_from; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off" value="<?php echo $ow_value->weight_to; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off" value="<?php echo $ow_value->price; ?>">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

<?php
}

?>
				    </div>
						<ul class="icons-labeled">
							<li><a href="javascript:void(0);" id="add_new_price_range2" data-repeater-create><span class="icon-block-color add-c"></span>Add Price Range Wholesale</a></li>
						</ul>
				</div>

		
				<div class="wholesale_no_slab" style="display:<?php echo ($original_slab_system == '1') ? 'none' : 'block'; ?>;">
				  	<div class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">From Weight</div>
						    <div class="div-table-head">To Weight</div>
						    <div class="div-table-head">Price</div>
						</div>
<?php
if( $lot_details['original_wholesale'] && $original_slab_system != '1' && count($lot_details['original_wholesale'])>0 ) {
	foreach ($lot_details['original_wholesale'] as $owns_value) {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_wholesale_no_slab" class="weight_from" autocomplete="off" value="<?php echo $owns_value->weight_from; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_wholesale_no_slab" class="weight_to" autocomplete="off" value="<?php echo $owns_value->weight_to; ?>">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_wholesale_no_slab" class="price" autocomplete="off" value="<?php echo $owns_value->price; ?>">
						    </div>
				        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_wholesale_no_slab" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_wholesale_no_slab" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_wholesale_no_slab" class="price" autocomplete="off">
						    </div>
				        </div>
<?php
}
?>
				    </div>
				</div>

			</div>


			<div style="clear:both;"></div>


			<div class="dummy_slot_number" style="display:<?php echo ($original_bag_weight == '1') ? 'block' : 'none'; ?>; margin-top:20px;">
				<div class="form_detail">
					<label>Dummy Lot Number
						<abbr class="require" title="Required Field">*</abbr>
					</label>
					<input type="text" id="dummy_slot_number" name="dummy_slot_number" value="<?php echo ($lot_details['dummy_lot_data'] && $lot_details['dummy_lot_data']->lot_number) ? $lot_details['dummy_lot_data']->lot_number : ''; ?>" autocomplete="off">
				</div>

				<div class="form_detail">
					<label>Slab System ?
						<abbr class="require" title="Required Field">*</abbr>
					</label>
					<div style="float:right;margin-top: 10px;margin-right: 25px;" class="slab">
						<input type="radio" name="dummy_slab_system" class="dummy_slab_system" value="1" <?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $dummy_slab_system == '1') ? 'checked' : '' ?>> Yes &nbsp;&nbsp;
						<input type="radio" name="dummy_slab_system" class="dummy_slab_system" value="0" <?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $dummy_slab_system == '1') ? '' : 'checked' ?>> No
					</div>
				</div>

				<div style="clear:both;"></div>
				<div class="table-simple price_range" style="width: 97%;">
					<h3>Retail Sale Price Range</h3>


					<div class="retail-repeater-dummy group_retail_dummy" style="display:<?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $dummy_slab_system == '1') ? 'block' : 'none' ?>">
					  	<div data-repeater-list="group_dummy_retail" class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">S.No</div>
							    <div class="div-table-head">From Weight</div>
							    <div class="div-table-head">To Weight</div>
							    <div class="div-table-head">Price</div>
							    <div class="div-table-head">Option</div>
							</div>
<?php
if( $lot_details['dummy_retail'] && $dummy_slab_system == '1' && count($lot_details['dummy_retail'])>0 ) {
	foreach ($lot_details['dummy_retail'] as $dr_value) {
?>
					    	<div data-repeater-item class="repeterin div-table-row">
								<div class="div-table-col rowno">1</div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_from" class="weight_from" autocomplete="off" value="<?php echo $dr_value->weight_from; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_to" class="weight_to" autocomplete="off" value="<?php echo $dr_value->weight_to; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="price" class="price" autocomplete="off" value="<?php echo $dr_value->price; ?>">
							    </div>
							    <div class="div-table-col">
							    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
							    	<input type="hidden" value="Delete"/>
							    </div>
					        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

<?php
}

?>
					    </div>
					    	<ul class="icons-labeled">
								<li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add Price Range Retail Sale</a></li>
							</ul>
					</div>

					<div class="retail_no_slab_dummy" style="display:<?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $dummy_slab_system == '1') ? 'none' : 'block' ?>">
					  	<div class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">From Weight</div>
							    <div class="div-table-head">To Weight</div>
							    <div class="div-table-head">Price</div>
							</div>

<?php
if( $lot_details['dummy_retail'] && $dummy_slab_system != '1' && count($lot_details['dummy_retail'])>0 ) {
	foreach ($lot_details['dummy_retail'] as $drns_value) {
?>
					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_retail_no_slab" class="weight_from" autocomplete="off"  value="<?php echo $drns_value->weight_from; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_retail_no_slab" class="weight_to" autocomplete="off"  value="<?php echo $drns_value->weight_to; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_retail_no_slab" class="price" autocomplete="off"  value="<?php echo $drns_value->price; ?>">
							    </div>
					        </div>
<?php
	}
} else {
?>
					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_retail_no_slab" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_retail_no_slab" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_retail_no_slab" class="price" autocomplete="off">
							    </div>
					        </div>
<?php	
}
?>

					    </div>
					</div>

					<h3>Wholesale Price Range</h3>
					<div class="retail-wholesale-dummy group_wholesale_dummy" style="display:<?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $lot_details['dummy_lot_data']->slab_system == '1') ? 'block' : 'none' ?>">
					  	<div data-repeater-list="group_dummy_wholesale" class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">S.No</div>
							    <div class="div-table-head">From Weight</div>
							    <div class="div-table-head">To Weight</div>
							    <div class="div-table-head">Price</div>
							    <div class="div-table-head">Option</div>
							</div>

<?php
if( $lot_details['dummy_wholesale'] && $dummy_slab_system == '1' && count($lot_details['dummy_wholesale'])>0 ) {
	foreach ($lot_details['dummy_wholesale'] as $dw_value) {
?>
					    	<div data-repeater-item class="repeterin div-table-row">
								<div class="div-table-col rowno">1</div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_from" class="weight_from" autocomplete="off" value="<?php echo $dw_value->weight_from; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_to" class="weight_to" autocomplete="off" value="<?php echo $dw_value->weight_to; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="price" class="price" autocomplete="off" value="<?php echo $dw_value->price; ?>">
							    </div>
							    <div class="div-table-col">
							    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
							    	<input type="hidden" value="Delete"/>
							    </div>
					        </div>
<?php
	}
} else {
?>
				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

<?php
}

?>
					    </div>
							<ul class="icons-labeled">
								<li><a href="javascript:void(0);" id="add_new_price_range2" data-repeater-create><span class="icon-block-color add-c"></span>Add Price Range Wholesale</a></li>
							</ul>
					</div>


					<div class="wholesale_no_slab_dummy" style="display:<?php echo (isset($lot_details['dummy_lot_data']->slab_system) && $dummy_slab_system == '1') ? 'none' : 'block' ?>">
					  	<div class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">From Weight</div>
							    <div class="div-table-head">To Weight</div>
							    <div class="div-table-head">Price</div>
							</div>
<?php
if( $lot_details['dummy_wholesale'] && $dummy_slab_system != '1' && count($lot_details['dummy_wholesale'])>0 ) {
	foreach ($lot_details['dummy_wholesale'] as $dwns_value) {
?>
					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_wholesale_no_slab" class="weight_from" autocomplete="off" value="<?php echo $dwns_value->weight_from; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_wholesale_no_slab" class="weight_to" autocomplete="off" value="<?php echo $dwns_value->weight_to; ?>">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_wholesale_no_slab" class="price" autocomplete="off" value="<?php echo $dwns_value->price; ?>">
							    </div>
					        </div>
<?php
	}
} else {
?>

					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_wholesale_no_slab" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_wholesale_no_slab" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_wholesale_no_slab" class="price" autocomplete="off">
							    </div>
					        </div>
<?php	
}
?>					        

					    </div>
					</div>



				</div>
			</div>



		<div class="button_sub">
			<button type="submit" name="edit_customer_list" id="btn_submit" class="submit-button">Submit</button>
		</div>
	</form>



</div>


<script type="text/javascript">


    jQuery('.retail-repeater').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-repeater .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {

        }
    });

    jQuery('.retail-wholesale').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-wholesale .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-wholesale .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {
        }
    });







    /*second set*/

    jQuery('.retail-repeater-dummy').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater-dummy .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-repeater-dummy .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {

        }
    });

    jQuery('.retail-wholesale-dummy').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-wholesale-dummy .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-wholesale-dummy .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {
        }
    });








</script>