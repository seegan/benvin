<style type="text/css">

	.leftLabel .fldTitle {
	    float: left;
	    width: 30%;
	    margin: 0 10px 0 0;
	    padding: 3px 0 0;
	}
	.leftLabel .choiceFld {
	    float: left;
	    width: 30%;
	    margin: 0 10px 0 0;
	}
	label.fldTitle, legend.fldTitle, legend.choiceFld {
	    font-size: 100%;
	    padding: 0 0 .2em 0;
	}
	.fldTitle {
	    float: none;
	    margin: 0 10px 5px 0;
	    display: block;
	}
	.leftLabel div.fieldwrap {
	    float: left;
	    width: 67%;
	    clear: right;
	}	
	.form-grid .left {
	    width: 50%;
	}
	.left {
	    float: left;
	}
	.form-grid input[type="text"] {
	    width: 40%;
	}

	.group_retail input[type="text"] {
	    width: 70px;
        margin: 0 auto;
	}


	.sale-lot-no {
		width: 150px;
	}
	.sale-rowno {
		width: 30px;
        height:30px;
	}
	.sale-sale-option {
		width: 150px;
	}
	.sale-weight {
		width: 280px;
	}
    .sale-product {
        min-width: 262px;
    }
    .unit-price-orig {
        min-width: 80px;
    }
    .sale-brand {
        width: 300px;
    }
    .sale-unit-price {
        width: 100px;
    }
    .sale-price {
        width: 75px;
    }
    .sale-option {
        width: 45px;
    }





.type-slider {
    width: 150px;
    background: #e6e6e6;
    height: 31px;
    border-radius: 12px;
    margin: 0 auto;
    top: 5px;
}
.slide-in {
    width: 75px;
    height: 30px;
    float:left;
    background:#f8f8f8;
    
}
.slide-in:nth-child(1) {
    border-radius: 12px 0px 0px 12px;
}
.slide-in:nth-child(2) {
    border-radius: 0px 12px 12px 0px;
}
.slide-in.active {
    width: 75px;
    height: 30px;
background: rgb(157,193,58); /* Old browsers */
background: -moz-linear-gradient(top,  rgb(157,193,58) 9%, rgb(146,191,22) 23%, rgb(86,138,17) 88%, rgb(86,138,17) 88%, rgb(86,138,17) 90%, rgb(86,138,17) 90%, rgb(86,138,17) 100%, rgb(157,193,58) 100%, rgb(86,138,17) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  rgb(157,193,58) 9%,rgb(146,191,22) 23%,rgb(86,138,17) 88%,rgb(86,138,17) 88%,rgb(86,138,17) 90%,rgb(86,138,17) 90%,rgb(86,138,17) 100%,rgb(157,193,58) 100%,rgb(86,138,17) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  rgb(157,193,58) 9%,rgb(146,191,22) 23%,rgb(86,138,17) 88%,rgb(86,138,17) 88%,rgb(86,138,17) 90%,rgb(86,138,17) 90%,rgb(86,138,17) 100%,rgb(157,193,58) 100%,rgb(86,138,17) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#9dc13a', endColorstr='#568a11',GradientType=0 ); /* IE6-9 */

}
.slide-in:not(.active) {
    -moz-box-shadow: inset 0px 1px 7px #b5b1b1;
    -webkit-box-shadow: inset 0px 1px 7px #b5b1b1;
    box-shadow: inset 0px 1px 7px #b5b1b1;
    color: #000;
}
.type-slider div {
    line-height: 32px;
    text-align: center;
    cursor: pointer;
    color: #fff;
    font-weight: bold;
    font-size: 12px;
}


.type-bill-slider {
    width: 40px;
    height: 31px;
    border-radius: 12px;
    margin: 0 auto;
    top: -10px;
    left: -5px;
}
.bill-slide-in {
    width: 15px;
    height: 15px;
    float:left;
    background:#f8f8f8;
    
}
.bill-slide-in:nth-child(1) {
    border-radius: 0px 0px 0px 0px;
    margin-right: 3px;
}
.bill-slide-in:nth-child(2) {
    border-radius: 0px 0px 0px 0px;
}
.bill-slide-in.active {
    width: 15px;
    height: 15px;
background: rgb(157,193,58); /* Old browsers */
background: -moz-linear-gradient(top,  rgb(157,193,58) 9%, rgb(146,191,22) 23%, rgb(86,138,17) 88%, rgb(86,138,17) 88%, rgb(86,138,17) 90%, rgb(86,138,17) 90%, rgb(86,138,17) 100%, rgb(157,193,58) 100%, rgb(86,138,17) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  rgb(157,193,58) 9%,rgb(146,191,22) 23%,rgb(86,138,17) 88%,rgb(86,138,17) 88%,rgb(86,138,17) 90%,rgb(86,138,17) 90%,rgb(86,138,17) 100%,rgb(157,193,58) 100%,rgb(86,138,17) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  rgb(157,193,58) 9%,rgb(146,191,22) 23%,rgb(86,138,17) 88%,rgb(86,138,17) 88%,rgb(86,138,17) 90%,rgb(86,138,17) 90%,rgb(86,138,17) 100%,rgb(157,193,58) 100%,rgb(86,138,17) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#9dc13a', endColorstr='#568a11',GradientType=0 ); /* IE6-9 */

}
.bill-slide-in:not(.active) {
    -moz-box-shadow: inset 0px 1px 7px #b5b1b1;
    -webkit-box-shadow: inset 0px 1px 7px #b5b1b1;
    box-shadow: inset 0px 1px 7px #b5b1b1;
    color: #000;
}
.type-bill-slider div {
    line-height: 32px;
    text-align: center;
    cursor: pointer;
    color: #fff;
    font-weight: bold;
    font-size: 12px;
}
#bill_round {
    border-radius: 13px;
}
#bill_square {

}
#bill_leaf {
    border-radius: 0 6px;
    margin-left: 10px;
    margin-top: 5px;
}




/*Tool tip*/
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 240px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}
.type-container {
    position: relative;
}

.original .type-slider, .original .weight-original-block, .duplicate .weight-duplicate-block, .original .unit_price, .duplicate .unit_price_input {
    display: block;
}
.duplicate .type-slider, .original .weight-duplicate-block, .duplicate .weight-original-block, .duplicate .unit_price, .original .unit_price_input {
    display: none;
}

.lot_search .select2-container {
    width: 123px;
}

.select2-container {
    z-index: 9998;
}
.payment-container, .payment-container-top {
    float: left;
    margin-right: 55px;
}
.method-span-txt {
    width: 200px;
}
.billing-structure {
    width: 400px;
}
</style>


<div class="form-grid">
    <form method="post" name="new_billing" id="new_billing" class="leftLabel" onsubmit="return false;">
        <ul>
            <li>
                <label class="fldTitle">Billing Date
                <abbr class="require" title="Required Field">*</abbr>
                </label>
                <div class="fieldwrap">
                    <span class="left">
                    	<input type="text" name="billing_date" class="billing_date" value="<?php echo date("Y-m-d", time()); ?>" id="billing_date">
                    </span>
                    <span class="left">
                    <label class="fldTitle">Bill No</label>
                    <input type="hidden" name="billing_no" id="billing_no" autocomplete="off" value="">
                    <input type="text" value="" disabled="" id="invoice_id">
                    </span>
                </div>
            </li>
            <li>
                <legend class="choiceFld">Select the Shop<abbr title="Required Field" class="require">*</abbr></legend>
                <div class="fieldwrap input-uniform">
                    <span>
                        <input type="radio" name="shop_name" value="rice_center" checked><label class="choice">Saravana Rice Center</label>
                    </span>
                    &nbsp;&nbsp;
                    <span>
                        <input type="radio" name="shop_name" value="rice_mandy"><label class="choice">Saravana Rice Mandy</label>
                    </span>
                </div>
            </li>
            <li>
                <label id="customer" for="customer" class="fldTitle">Select the Customer
                    <abbr class="require" title="Required Field">*</abbr>
                </label>
                <div class="fieldwrap">
                    <span class="left">
                        <select id="billing_customer" name="billing_customer"></select>

	                    </span>
	                    <span class="left append_cus_last_bill">
                    </span>
                </div>
            </li>
            <li>
                <label id="customer_type" for="customer_type" class="fldTitle">Set the Customer Type</label>
                <div class="fieldwrap input-uniform">
                    <span class="left">
                        <span>
                            <input type="radio" name="customer_type" value="retail" checked><label class="choice">Retail</label>
                        </span>
                        &nbsp;&nbsp;
                        <span>
                            <input type="radio" name="customer_type" value="wholesale"><label class="choice">Wholesale</label>
                        </span>
                    </span>



<span class="left">

    <ul class="icons-labeled ck_stk">
        <li>
            <a id="ck_stk_available"><span class="icon-block-black magnifying-glass-b"></span>Check Stock Availability</a>
        </li>
    </ul>
    <div class="stock_ck_avail_box active-n">
        <img src="<?php echo get_template_directory_uri(); ?>/inc/images/top_arr.png" class="top_arr_avail">
        <div style="padding: 15px;">
            <h2 style="margin-top:5px;">Check Stock Availability</h2>
            <a href="#" style="float: right; margin-top: -40px;" id="close_check_availa_box"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/x.png"></a>
            <div style="width: 100%; border-bottom: 1px solid #ccc; padding: 5px 0px 15px 0px;" class="lot_search">
                <b>Filter :</b>&nbsp;
                <select name="search_lotn" id="search_lotn">
                    <option value="-">Lot Name</option>
                </select>&nbsp;&nbsp;
                <select name="search_brandn" id="search_brandn">
                    <option value="-">Brand Name</option>
                </select>&nbsp;&nbsp;
                <select name="search_stockn" id="search_stockn">
                    <option value="-">Stock Name</option>
                </select>
                <!-- <input type="text" name="search_lot_rate" id="search_lot_rate" autocomplete="off" placeholder="Enter Rate"> -->&nbsp;&nbsp;
                <input name="search_avail_stock" type="button" value="Search" class="submit-button search_avail_stock">
                <img alt="Loader" src="<?php echo get_template_directory_uri(); ?>/inc/images/ajax-loader.gif" id="search_loader" style="display: none;">
            </div>
        </div>
        <div class="load_stock_available" style="overflow-y: scroll; padding: 10px; height: 250px;">
            <div class="module table-simple">
                <table class="display">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Lot Name</th>
                            <th>Brand </th>
                            <th>Stock Name</th>
                            <th>Stock Balance (Kg)</th>
                        </tr>
                    </thead>
                    <tbody class="stock_search_filter">
                        <tr>
                            <td colspan="5">Search Details Search</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</span>






                </div>
            </li>
            <li>          	


				<div class="retail-repeater group_retail">
				  	<div data-repeater-list="group_retail" class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">S.No</div>
						    <div class="div-table-head">Lot Number</div>
						    <div class="div-table-head">Sale Option</div>
						    <div class="div-table-head">Weight</div>
						    <div class="div-table-head">Brand</div>
						    <div class="div-table-head">Product Name</div>
                            <div class="div-table-head">Unit Price</div>
                            <div class="div-table-head">Discount price</div>
                            <div class="div-table-head">Total</div>
						    <div class="div-table-head">Option</div>
						</div>

				    	<div data-repeater-item class="repeterin div-table-row original">
    							<div class="div-table-col sale-rowno">
                                    <div class="type-container">
                                        <div class="type-bill-slider" style="position:absolute;">
                                            <div class="bill-slide-in active" id="bill_round" data-stype="original" data-sstype="original"></div>
                                            <div class="bill-slide-in" id="bill_square" data-stype="duplicate" data-sstype="out_stock"></div>
                                            <div class="bill-slide-in" id="bill_leaf" data-stype="duplicate" data-sstype="health_store"></div>
                                            <input type="radio" class="type_bill" name="type_bill" value="original" checked>
                                            <input type="radio" class="type_bill" name="type_bill" value="duplicate">

                                            <input type="hidden" name="type_bill_h" class="type_bill_h" value="original">
                                            <!-- For NST -->
                                            <input type="hidden" name="type_bill_s" class="type_bill_s" value="original">
                                        </div>
                                    </div>
                                    <div class="rowno">1</div>
                                </div>
    						    <div class="div-table-col sale-lot-no">
                                    <input type="hidden" name="lot_parent" id="input_lot_parent" >
                                    <input type="hidden" name="lot_slab" id="input_lot_slab" value="0">
    						    	<select name="lot_number" class="lot_id"></select>
    						    </div>
    						    <div class="div-table-col sale-sale-option">
    						    	
                                    <div style="position:relative;">
                                      <div class="type-slider" style="position:absolute;">
                                        <div class="slide-in active" data-stype="retail">Retail</div>
                                        <div class="slide-in" data-stype="wholesale">Wholesale</div>
                                        <input type="radio" class="sale_type" name="sale_type" value="retail" checked>
                                        <input type="radio" class="sale_type" name="sale_type" value="wholesale">

                                        <input type="hidden" class="sale_type_h" name="sale_type_h" value="retail">
                                        
                                      </div>
                                    </div>

    						    </div>
    						    <div class="div-table-col sale-weight">


                                  <div class="weight-original-block">
                                    <div class="weight_cal_section">
                                      <div class="slab_system_no">
                                        <input type="text" name="weight" class="weight" autocomplete="off" placeholder="">
                                        X
                                        <input type="text" name="unit_count" class="unit_count" autocomplete="off" placeholder="Count">
                                        =
                                        <input type="text" name="slab_no_total" class="total" autocomplete="off" placeholder="Weight">
                                      </div>
                                      <div class="slab_system_yes" style="display:none;">
                                        <input type="text" name="slab_yes_total" class="total" autocomplete="off" placeholder="Weight">
                                      </div>

                                    </div>
                                    <div class="weight_cal_tooltip">
                                      <div class="tooltip tootip-black" data-stockalert="1">
                                        <span class="tooltiptext">
                                            Slab System : <span class="slab_sys_txt">--</span>
                                            <hr class="tooltip-hr">
                                            Stock Avail : <span class="stock_weight_txt">--</span> kg
                                        </span>
                                      </div>
                                    </div>
                                    <div style="clear:both;"></div>
                                  </div>


                                  <div class="weight-duplicate-block">
                                    <div class="weight_cal_section">
                                      <div class="" style="display:block;">
                                        <input type="text" name="lot_duplicate_total" class="total duplicate_total" autocomplete="off" placeholder="Weight" value="0">
                                      </div>

                                    </div>
                                    <div style="clear:both;"></div>
                                  </div>


    						    </div>

    						    <div class="div-table-col sale-brand" style="position:relative;">
    						    	<div class="brand_name_data"></div>
                                    <div class="brand_checkbox" style="width: 20px;position: absolute;right: 0;top: 40%;">
                                        <input type="checkbox" name="brand_checkbox_input" class="brand_checkbox_input" value="1" checked>
                                    </div>
    						    </div>
    						    <div class="div-table-col sale-product">
    						    	<div class="product_name_data"></div>
    						    </div>
                                <div class="div-table-col unit-price-orig">
                                    <div class="unit-price-orig-txt"></div>
                                    <div class="unit-price-orig-hidden">
                                        <input type="hidden" name="price_orig_hidden" value="">
                                    </div>
                                </div>
                                <div class="div-table-col sale-unit-price">
                                  <div class="sale_unit_price">
                                    <input type="text" name="unit_price_original" class="unit_price" value="0">
                                    <input type="text" name="unit_price_duplicate" class="unit_price_input" value="0">
                                  </div>
                                </div>
                                <div class="div-table-col sale-price">
                                  <div class="sale_total_price">
                                    <input  type="text" name="total_price" class="total_price" value="0" readonly="">
                                  </div>
                                </div>
    						    <div class="div-table-col sale-option">
    						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
    						    	<input type="hidden" value="Delete"/>
    						    </div>
				        </div>



				    </div>


                    <div class="div-table">
                        <div class="div-table-row">
                            <div class="div-table-col rowno sale-rowno"></div>
                            <div class="div-table-col sale-lot-no">
                            </div>
                            <div class="div-table-col sale-sale-option">
                            </div>
                            <div class="div-table-col sale-weight">
                            </div>
                            <div class="div-table-col sale-brand">
                            </div>
                            <div class="div-table-col sale-product">
                            </div>
                            <div class="div-table-col unit-price-orig">
                            </div>
                            <div class="div-table-col sale-unit-price" style="padding-top: 20px;">
                                Actual Total
                            </div>
                            <div class="div-table-col sale-price">
                                <div class="actual_total">
                                    <input  type="text" name="actual_price" class="actual_price" value="0" readonly="">
                                </div>
                            </div>
                            <div class="div-table-col sale-option">
                            </div>
                        </div>
                        <div class="div-table-row">
                            <div class="div-table-col rowno sale-rowno"></div>
                            <div class="div-table-col sale-lot-no">
                            </div>
                            <div class="div-table-col sale-sale-option">
                            </div>
                            <div class="div-table-col sale-weight">
                            </div>
                            <div class="div-table-col sale-brand">
                            </div>
                            <div class="div-table-col sale-product">
                            </div>
                            <div class="div-table-col unit-price-orig">
                            </div>
                            <div class="div-table-col sale-unit-price" style="padding-top: 20px;">
                                Discount  (Rs)
                            </div>
                            <div class="div-table-col sale-price">
                                <div class="discount_total">
                                    <input  type="text" name="discount" class="discount" value="0">
                                </div>                            
                            </div>
                            <div class="div-table-col sale-option">
                            </div>
                        </div>
                        <div class="div-table-row">
                            <div class="div-table-col rowno sale-rowno"></div>
                            <div class="div-table-col sale-lot-no">
                            </div>
                            <div class="div-table-col sale-sale-option">
                            </div>
                            <div class="div-table-col sale-weight">
                            </div>
                            <div class="div-table-col sale-brand">
                            </div>
                            <div class="div-table-col sale-product">
                            </div>
                            <div class="div-table-col unit-price-orig">
                            </div>                            
                            <div class="div-table-col sale-unit-price" style="padding-top: 20px;">
                                Sub Total
                            </div>
                            <div class="div-table-col sale-price">
                                <div class="final_total_price">
                                    <input  type="text" name="final_total" class="final_total" value="0" readonly="">
                                </div>                             
                            </div>
                            <div class="div-table-col sale-option">
                            </div>
                        </div>
                    </div>

			    	<ul class="icons-labeled">
						<li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add Price Range Retail Sale</a></li>
					</ul>
				</div>

<style type="text/css">
    .payment-span {
        float: left;
    }
    .payment-modes {
        float: left;
    }
    .cash_payment,.card_payment, .neft_payment, .cheque_payment {
        width: 430px;
    }
    .method-span-txt {
        float: left;
    }
    .method-container {
        float: left;
    }
    .payment-mode-detail {
        float: left;
    }
    .payment-detail-container {
        float: left;
        margin-top: 20px;
        width:800px;
    }
    .billing-structure {
        width: 600px;
        margin:0 auto;
    }
    .cash-span {
        float: left;
        width: 300px;
    }
    .cash-amt {
        float: left;
    }
    .cash-container {
        margin-top: 20px;
    }
    .cash-container {
        display: none;
    }
    .text-span {
        font-weight: bold;
    }
</style>
                <div class="payment-mode">
                    <div class="payment-container-top">
                        <div class="payment-span">
                            <b>Mode of payment :</b> 
                            <input type="checkbox" name="payment_cash[]" value="cash_content" class="payment_cash"> Cash 
                            <input type="checkbox" name="payment_cash[]" value="card_content" class="payment_cash"> Card Swipe 
                            <input type="checkbox" name="payment_cash[]" value="neft_content" class="payment_cash"> Neft / RTGS 
                            <input type="checkbox" name="payment_cash[]" value="cheque_content" class="payment_cash"> Cheque  
                            <!-- <input type="checkbox" name="payment_cash" value="credit"> Credit -->
                        </div>
                    </div>
                </div>
                <div style="clear:both;"></div>
                <div class="payment-mode-detail">




                    <div class="payment-container" style="display:none;" id="cash_content">
                        <div class="method-span-txt" style="margin-top:20px;">
                            <span style="font-size:20px;margin-right: 20px;">Cash Payment : </span>
                        </div>
                        <div class="method-container">
                            <div class="retail-repeater-method cash_payment" style="margin-top:20px;">
                                <div data-repeater-list="cash_payment" class="div-table">

                                    <div class="div-table-row">
                                        <div class="div-table-head" style="width:187px;">Note</div>
                                        <div class="div-table-head" style="width:187px;">Amount Paid</div>
                                        <div class="div-table-head" style="width:56px;">Option</div>
                                    </div>

                                    <div data-repeater-item class="repeterin div-table-row">
                                            <div class="div-table-col">
                                                <input type="text" name="cash_description" style="width:90%;" class="c_description">
                                            </div>
                                            <div class="div-table-col">
                                                <input type="text" name="cash" style="width:40%;" class="c_cash">
                                            </div>
                                            <div class="div-table-col">
                                                <a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="">x</a>
                                                <input type="hidden" value="Delete"/>
                                            </div>
                                    </div>
                                </div>


                                <div class="div-table">
                                    <div class="div-table-row">                           
                                        <div class="div-table-col sale-unit-price" style="padding-top: 20px;width:183px;">
                                            Total
                                        </div>
                                        <div class="div-table-col" style="width:188px;">
                                            <div class="payment_final_cash">
                                                <input type="text" name="payment_final[cash]" class="payment_final" value="0" readonly="" data-mode="cash">
                                            </div>                             
                                        </div>
                                        <div class="div-table-col" style="width:60px;">
                                        </div>
                                    </div>
                                </div>

                                <ul class="icons-labeled">
                                    <li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>

                    <div style="clear:both;"></div>

                    <div class="payment-container" style="display:none;" id="card_content">
                        <div class="method-span-txt" style="margin-top:20px;">
                            <span style="font-size:20px;margin-right: 20px;">Card Swipe : </span>
                        </div>
                        <div class="method-container">
                            <div class="retail-repeater-method card_payment" style="margin-top:20px;">
                                <div data-repeater-list="card_payment" class="div-table">

                                    <div class="div-table-row">
                                        <div class="div-table-head" style="width:187px;">Note</div>
                                        <div class="div-table-head" style="width:187px;">Amount Paid</div>
                                        <div class="div-table-head" style="width:56px;">Option</div>
                                    </div>

                                    <div data-repeater-item class="repeterin div-table-row">
                                            <div class="div-table-col">
                                                <input type="text" name="cash_description" style="width:90%;" class="c_description">
                                            </div>
                                            <div class="div-table-col">
                                                <input type="text" name="card" style="width:40%;" class="c_cash">
                                            </div>
                                            <div class="div-table-col">
                                                <a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="">x</a>
                                                <input type="hidden" value="Delete"/>
                                            </div>
                                    </div>
                                </div>


                                <div class="div-table">
                                    <div class="div-table-row">
                                        <div class="div-table-col sale-unit-price" style="padding-top: 20px;width:183px;">
                                            Total (extra 1.5%)
                                        </div>
                                        <div class="div-table-col" style="width:188px;">
                                            <div class="payment_final_card">
                                                <input  type="text" name="payment_final[card]" class="payment_final" value="0" readonly="" data-mode="card">
                                            </div>
                                        </div>
                                        <div class="div-table-col" style="width:60px;">
                                        </div>
                                    </div>
                                </div>

                                <ul class="icons-labeled">
                                    <li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>

                    <div style="clear:both;"></div>

                    <div class="payment-container" style="display:none;" id="neft_content">
                        <div class="method-span-txt" style="margin-top:20px;">
                            <span style="font-size:20px;margin-right: 20px;">Neft / RTGS : </span>
                        </div>
                        <div class="method-container">
                            <div class="retail-repeater-method neft_payment" style="margin-top:20px;">
                                <div data-repeater-list="neft_payment" class="div-table">

                                    <div class="div-table-row">
                                        <div class="div-table-head" style="width:187px;">Note</div>
                                        <div class="div-table-head" style="width:187px;">Amount Paid</div>
                                        <div class="div-table-head" style="width:56px;">Option</div>
                                    </div>

                                    <div data-repeater-item class="repeterin div-table-row">
                                            <div class="div-table-col">
                                                <input type="text" name="neft_description" style="width:90%;" class="c_description">
                                            </div>
                                            <div class="div-table-col">
                                                <input type="text" name="neft" style="width:40%;" class="c_cash">
                                            </div>
                                            <div class="div-table-col">
                                                <a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="">x</a>
                                                <input type="hidden" value="Delete"/>
                                            </div>
                                    </div>
                                </div>


                                <div class="div-table">
                                    <div class="div-table-row">                           
                                        <div class="div-table-col sale-unit-price" style="padding-top: 20px;width:183px;">
                                            Total
                                        </div>
                                        <div class="div-table-col" style="width:188px;">
                                            <div class="payment_final_neft">
                                                <input  type="text" name="payment_final[neft]" class="payment_final" value="0" readonly="" data-mode="neft">
                                            </div>                             
                                        </div>
                                        <div class="div-table-col" style="width:60px;">
                                        </div>
                                    </div>
                                </div>

                                <ul class="icons-labeled">
                                    <li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>

                    <div style="clear:both;"></div>

                    <div class="payment-container" style="display:none;" id="cheque_content">
                        <div class="method-span-txt" style="margin-top:20px;">
                            <span style="font-size:20px;margin-right: 20px;">Cheque : </span>
                        </div>
                        <div class="method-container">
                            <div class="retail-repeater-method cheque_payment" style="margin-top:20px;">
                                <div data-repeater-list="cheque_payment" class="div-table">

                                    <div class="div-table-row">
                                        <div class="div-table-head" style="width:187px;">Note</div>
                                        <div class="div-table-head" style="width:187px;">Amount Paid</div>
                                        <div class="div-table-head" style="width:56px;">Option</div>
                                    </div>

                                    <div data-repeater-item class="repeterin div-table-row">
                                            <div class="div-table-col">
                                                <input type="text" name="cheque_description" style="width:90%;" class="c_description">
                                            </div>
                                            <div class="div-table-col">
                                                <input type="text" name="cheque" style="width:40%;" class="c_cash">
                                            </div>
                                            <div class="div-table-col">
                                                <a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="">x</a>
                                                <input type="hidden" value="Delete"/>
                                            </div>
                                    </div>
                                </div>


                                <div class="div-table">
                                    <div class="div-table-row">                           
                                        <div class="div-table-col sale-unit-price" style="padding-top: 20px;width:183px;">
                                            Total
                                        </div>
                                        <div class="div-table-col" style="width:188px;">
                                            <div class="payment_final_cheque">
                                                <input  type="text" name="payment_final[cheque]" class="payment_final" value="0" readonly="" data-mode="cheque">
                                            </div>                             
                                        </div>
                                        <div class="div-table-col" style="width:60px;">
                                        </div>
                                    </div>
                                </div>

                                <ul class="icons-labeled">
                                    <li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>

                </div>

                <div class="payment-detail-container">
                    <div class="billing-structure">
                        <div class="cash-container cash_content">
                            <div class="cash-span">
                                Cash Total
                            </div>
                            <div class="cash-amt cash_amt">
                                0
                            </div>
                            <input type="hidden" name="instalment[cash]" class="cash_input">
                            <div style="clear:both;"></div>
                        </div>
                        <div class="cash-container card_content">
                            <div class="cash-span">
                                Card Total (1.5% extra swipe)
                            </div>
                            <div class="cash-amt card_amt">
                                0
                            </div>
                            <input type="hidden" name="instalment[card]" class="card_input">
                            <div style="clear:both;"></div>
                        </div>
                        <div class="cash-container neft_content">
                            <div class="cash-span">
                                NEFT Total
                            </div>
                            <div class="cash-amt neft_amt">
                                0
                            </div>
                            <input type="hidden" name="instalment[neft]" class="neft_input">
                            <div style="clear:both;"></div>
                        </div>
                        <div class="cash-container cheque_content">
                            <div class="cash-span">
                                Cheque Total
                            </div>
                            <div class="cash-amt cheque_amt">
                                0
                            </div>
                            <input type="hidden" name="instalment[cheque]" class="cheque_input">
                            <div style="clear:both;"></div>
                        </div>
                        <div style="clear:both;"></div>
                        <div>
                            <hr>
                        </div>
                        <div class="">
                            <div class="cash-span">
                                <span class="text-span">
                                    Amount Paid
                                </span>
                            </div>
                            <div class="cash-amt cash_total">
                                0
                            </div>
                            <input type="hidden" name="cash_total_input" class="cash_total_input" value="0">
                            <div style="clear:both;"></div>
                        </div>
                        <div style="clear:both;"></div>
                        <div class="">
                            <div class="cash-span">
                                <span class="text-span">
                                    Fee
                                </span>
                            </div>
                            <div class="cash-amt">
                                <span class="fee-span">
                                    0.00
                                </span>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                        <div>
                            <hr>
                        </div>
                        <div style="clear:both;"></div>
                        <div class="">
                            <div class="cash-span">
                                <span class="text-span">
                                    Total Amount To be Paid
                                </span>
                            </div>
                            <div class="cash-amt amt_paid">
                                <span class="total-pay-span">
                                0
                                </span>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                        <div>
                            <hr>
                        </div>
                        <div style="clear:both;"></div>
                        <div class="">
                            <div class="cash-span">
                                <span class="text-span">
                                Balance Amount to be paid
                                </span>
                            </div>
                            <div class="cash-amt amt_paid">
                                <span class="balance-pay-span">
                                    0
                                </span>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                        <div class="payment_done_cls" style="margin-top:20px;">
                            <input type="checkbox" name="payment_done" id="payment_done"> Payment Completed
                        </div>
                    </div>
                </div>



            </li>
            <li class="buttons bottom-round noboder">
                <div class="fieldwrap">
                    <input name="bill_submit" type="button" value="Create Invoice" class="submit-button bill_submit" style="display:none;">
                </div>
            </li>
        </ul>
    </form>
</div>




<script type="text/javascript">

    jQuery('.retail-repeater').repeater({
        defaultValues: {

          sale_type: ['retail'],
          type_bill: ['original'],
          brand_checkbox_input : 1,
          type_bill_h : 'original',
          sale_type_h : 'retail',
          total_price : 0,
          lot_duplicate_total : 0,
          unit_price_duplicate : 0,
          unit_price_original : 0,

          slab_no_total : 0,
          slab_yes_total : 0,

        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          });
          populate_select2(this, 'new');
          jQuery(this).slideDown();

          //console.log(jQuery(this).find('.type_bill:input[type=radio]:checked').val());
          //console.log(jQuery('input[type=radio][name=customer_type]:checked').val());
          console.log(jQuery(this).find('.type-slider [data-stype="'+jQuery('input[type=radio][name=customer_type]:checked').val()+'"]').click())
          

        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);

                var count = 1;
                jQuery('.retail-repeater .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                });
            }
        },
        ready: function (setIndexes) {
            
        }
    });



    jQuery('.retail-repeater-method').repeater({
        defaultValues: {

          sale_type: ['retail'],

        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater-method .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          });
          jQuery(this).slideDown();

        },
        hide: function (deleteElement) {

            if(confirm('Are you sure you want to delete this element?')) {

                var delete_val = jQuery(this).find('.c_cash').val();
                var current_total  = jQuery(this).parent().parent().find('.payment_final').val();
                var cur_bal = current_total - delete_val;
                jQuery(this).parent().parent().find('.payment_final').val(cur_bal).change();
                jQuery(this).slideUp(deleteElement);

            }
        },
        ready: function (setIndexes) {
            
        }
    });






    jQuery(document).ready(function(){
        jQuery("#billing_date" ).datepicker({dateFormat: "yy-mm-dd"});
    });
</script>