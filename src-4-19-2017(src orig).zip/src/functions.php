<?php
require get_template_directory() . '/inc/admin/functions.php';
require get_template_directory() . '/inc/admin/menu-functions.php';
require get_template_directory() . '/inc/admin/pagination-functions.php';

require get_template_directory() . '/inc/admin/admin-dashboard.php';
require get_template_directory() . '/inc/admin/report-functions.php';

/*$lot_details = get_lot(1);
echo "<pre>";
var_dump($lot_details);

die();*/
//Assign capabilities global
function src_global_var() {
    global $src_capabilities;
	$src_capabilities = array( 
		'dashboard' => 'Dashboard', 
		'customers' => 'Customers',  
		'stocks' => array(
			'name' => 'Stocks',
			'data' => array(
				'lot_list' => 'Lot(s) List',
				'stock_list' => 'Stock List', 
			),
		),
		'sales_others' => array(
			'name' => 'Sales & Others',
			'data' => array(
				'purchase_sales' => 'Purchase & Sales', 
				'petty_cash' => 'Petty Cash', 
				'income_list' => 'Income List', 
			),
		),
		'employee' => array(
			'name' => 'Employee',
			'data' => array(
				'add_new_employee' => 'Add New Employee', 
				'employee_list' => 'Employee\'s List', 
				'attendance_list' => 'Attendance List', 
				'salary_list' => 'Salary List', 
			),
		),
		'admin_users' => array(
			'name' => 'Admin Users',
			'data' => array(
				'add_new_user' => 'Add New User', 
				'user_list' => 'User\'s List', 
			),

		),
		'sms_alert' => array(
			'name' => 'SMS Alert',
			'data' => array(
				'sms_to_customer' => 'SMS to Customer', 
				'sms_to_user' => 'SMS to User', 
			),
		),
		'reports' => 'Reports', 
		'settings' => 'Settings'
	);

}
add_action( 'init', 'src_global_var' );


//create role capabilities
function custom_role_administrator() {
	global $src_capabilities;
	$admin_role = get_role( 'administrator' );

	$data = '';
	foreach ($src_capabilities as $key => $c_value) {
		if( is_array($c_value) ) {
			foreach ($c_value['data'] as $key_val => $name_value) {
				$data[] =  $key_val;
			}
		} else {
			$data[] = $key;
		}
	}
	foreach( $data as $cap ) {
	        $admin_role->add_cap( $cap );
	}

	if(!get_role('customer')) {
		add_role( 'customer', 'Customer', array( 'read' => true, 'level_0' => true ) );
	}
	if(!get_role('employee')) {
	    add_role( 'employee', 'Employee', array( 'read' => true, 'level_0' => true ) );
	}
}
add_action('switch_theme', 'custom_role_administrator');
