--
-- Database: `test_src`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2016-08-20 10:05:18', '2016-08-20 10:05:18', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_customers`
--

CREATE TABLE `wp_customers` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `payment_type` varchar(255) NOT NULL DEFAULT 'immediate',
  `created_at` datetime NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_customers`
--

INSERT INTO `wp_customers` (`id`, `name`, `mobile`, `address`, `type`, `payment_type`, `created_at`, `modified_at`, `active`) VALUES
(1, 'seegan last', '3453543545', '34534534', 'Retail', 'Immediate', '2016-09-12 12:42:39', '2016-09-12 07:12:39', 1),
(2, 'seegan2', '34645654', 'sdfdsf, dsfsdf, dsfsdf', 'Wholesale', 'Immediate', '2016-09-09 11:00:00', '2016-09-09 05:30:00', 1),
(3, 'FFFddd', '5345435345', 'fsdfdsfsd, dsfsdfsd,dsfsfsdf', 'Retail', 'Immediate', '2016-09-09 11:08:15', '2016-09-09 05:38:15', 1),
(4, 'Test', '5343434', 'dsfsdfsdf', 'Retail', 'Immediate', '2016-09-09 11:13:05', '2016-09-09 05:43:05', 1),
(5, 'sdsadsadsa', '343434', 'fsdfdsf', 'Retail', 'Immediate', '2016-09-09 11:14:48', '2016-09-09 05:44:48', 1),
(6, 'fgdgfd', '4534543', 'dfgdfgdfg', 'Retail', 'Immediate', '2016-09-09 11:16:35', '2016-09-09 05:46:35', 1),
(7, 'SEEEEE', '9952380502', 'Kattuvilai, Karungal', 'Wholesale', 'Immediate', '2016-09-09 11:38:26', '2016-09-09 06:08:26', 1),
(8, '465436', '43534543', '5rsfgvsdgfsdgf', 'Retail', 'Immediate', '2016-09-12 12:15:43', '2016-09-12 06:45:43', 1),
(9, 'fdgfdg', '5476546754', 'fgfdgfdg', 'Retail', 'Immediate', '2016-09-12 12:10:44', '2016-09-12 06:40:44', 1),
(10, 'fdgfdg', '5476546754', 'fgfdgfdg', 'Retail', 'Immediate', '2016-09-12 12:16:31', '2016-09-12 06:46:31', 1),
(11, 'fdgfdg', '5476546754', 'fgfdgfdg', 'Retail', 'Immediate', '2016-09-12 12:14:10', '2016-09-12 06:44:10', 1),
(12, 'ssssseegggannn', '3345435435', 'gvdfsgfdg', 'Retail', 'Immediate', '2016-09-12 11:49:05', '2016-09-12 06:19:05', 1),
(13, 'seegan', '3345435435', 'gvdfsgfdg', 'Retail', 'Immediate', '2016-09-12 11:53:49', '2016-09-12 06:23:49', 1),
(14, 'erfsdfsdf', '35435435', 'dfdsgfdgdg', 'Wholesale', 'Immediate', '2016-09-12 07:20:30', '2016-11-15 06:24:39', 0),
(15, '4543534', '56546546', 'gdfgdfg', 'Retail', 'Immediate', '2016-09-12 07:21:17', '2016-09-12 01:51:17', 1),
(16, '4543534', '56546546', 'gdfgdfg', 'Retail', 'Immediate', '2016-09-12 07:21:31', '2016-09-12 01:51:31', 1),
(17, 'fdgfdg', '5435435', 'dfgfdgfdg', 'Retail', 'Immediate', '2016-09-12 07:22:10', '2016-09-12 01:52:10', 1),
(18, 'fdgfdg', '453465465', 'dfgfdgdfg', 'Retail', 'Immediate', '2016-09-12 07:25:02', '2016-09-12 01:55:02', 1),
(19, 'sdfdsfsdf', '543543534', 'fsdfsdfsdf', 'Retail', 'Immediate', '2016-09-13 05:17:54', '2016-09-12 23:47:54', 1),
(20, 'etrdtgrt', '435345435', 'dsfdsfsd', 'Retail', 'Immediate', '2016-09-12 07:30:34', '2016-09-12 02:00:34', 1),
(21, 'dfsdsfsdf', '43543534', 'fsdfdsfsdf', 'Bulk', 'Immediate', '2016-09-13 05:19:55', '2016-09-12 23:49:55', 1),
(22, 'testname', '43645654', 'dfgdfsgfdg', 'Retail', 'Immediate', '2016-09-13 05:16:01', '2016-09-12 23:46:01', 1),
(23, 'dfgdfgfdg', '5654645', 'fgfdgf', 'Retail', 'Immediate', '2016-09-13 08:59:48', '2016-09-13 03:29:48', 1),
(24, 'fgdfgdfg', '456462424', 'dfgdfgfdg', 'Retail', 'Immediate', '2016-09-13 09:00:11', '2016-09-13 03:30:11', 1),
(25, 'QWERTY', '65456745645', 'dfgdfgdfgfdg', 'Retail', 'Immediate', '2016-09-12 09:01:43', '2016-09-12 03:31:43', 1),
(26, 'seedf', '343434', 'fsdfdsf', 'Retail', 'Immediate', '2016-09-13 05:14:49', '2016-09-12 23:44:49', 1),
(27, 'QWERTY', '65456745645', 'dfgdfgdfgfdg', 'Wholesale', 'Immediate', '2016-09-13 05:20:06', '2016-09-12 23:50:06', 1),
(28, 'fdsfd', '435435', 'rsdfsdf', 'Retail', 'Immediate', '2016-09-12 10:41:31', '2016-09-12 05:11:31', 1),
(29, 'fdgdfgfd', '43543543', 'dfgdfgdfg', 'Retail', 'Immediate', '2016-09-13 05:15:44', '2016-09-12 23:45:44', 1),
(30, 'seegan', '54654645', 'xcvgxcc', 'Bulk', 'Immediate', '2016-10-05 06:54:03', '2016-10-05 01:24:03', 1),
(31, 'fdgdfg', '43543534', 'gfdgfdg', 'Retail', 'Immediate', '2016-09-12 10:50:35', '2016-09-12 05:20:35', 1),
(32, 'testpaginate', '45435345345', 'sdfsdfdsf', 'Retail', 'Immediate', '2016-09-12 11:30:37', '2016-09-12 06:00:37', 1),
(33, 'testdasas', '454354', 'dsfsdfdsf', 'Retail', 'Immediate', '2016-09-14 05:31:08', '2016-09-14 00:01:08', 1),
(34, 'vivek', '436534543', 'fdgdfg', 'Wholesale', 'Immediate', '2016-11-19 04:57:00', '2016-11-18 23:27:00', 1),
(35, 'Ranga raj', '5345345', 'fdsdfsd', 'Retail', 'Immediate', '2016-11-19 05:01:26', '2016-11-18 23:31:26', 1),
(36, 'Seegan sdf', '9952380502', 'fdgdfg', 'Wholesale', 'credit', '2016-11-21 09:56:43', '2016-11-21 04:26:43', 1),
(37, 'Sowmiya', '56565464', 'cfvxcv', 'Retail', 'immediate', '2017-02-08 04:29:37', '2017-02-07 22:59:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_employees`
--

CREATE TABLE `wp_employees` (
  `id` int(11) NOT NULL,
  `emp_no` varchar(20) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_mobile` int(15) NOT NULL,
  `emp_address` text NOT NULL,
  `emp_salary` decimal(9,2) NOT NULL,
  `emp_joining` datetime NOT NULL,
  `emp_created_at` datetime NOT NULL,
  `emp_modified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `emp_current_status` int(2) NOT NULL DEFAULT '1',
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_employees`
--

INSERT INTO `wp_employees` (`id`, `emp_no`, `emp_name`, `emp_mobile`, `emp_address`, `emp_salary`, `emp_joining`, `emp_created_at`, `emp_modified_at`, `emp_current_status`, `active`) VALUES
(1, '', 'first name', 435435, '45435, fdgfdgfdg, fgfdg', '4543.00', '2016-11-01 00:00:00', '2016-11-05 05:43:37', '2016-11-05 15:06:07', 1, 1),
(2, '', 'seega', 324234, 'sdfsdf, dsfdsf', '5434534.00', '2016-11-02 00:00:00', '2016-11-05 06:06:51', '2016-11-05 15:06:11', 0, 1),
(3, '', '43543', 435345, 'fgdgfg', '450.00', '2016-10-04 00:00:00', '2016-11-05 04:29:40', '2017-01-30 14:19:10', 0, 1),
(4, '', '0', 324543543, 'sdfdsf,sdfdsfds,dsfdsf', '20000.00', '2016-11-06 00:00:00', '2016-11-05 04:31:22', '2016-11-05 15:06:19', 0, 1),
(5, '', 'erewrer', 33434234, 'dfgdfg', '12334.00', '2016-11-03 00:00:00', '2016-11-10 11:23:23', '2016-11-10 16:53:23', 1, 1),
(6, '', 'seegan', 534534343, 'fgdgf, fgfdg', '300.00', '2016-10-04 00:00:00', '2016-11-05 04:34:02', '2017-01-30 14:19:36', 0, 1),
(7, '', 'test', 3245235, 'gfgdfgdf', '4000.00', '2016-11-05 00:00:00', '2016-11-05 06:06:22', '2016-11-05 15:06:32', 0, 1),
(8, '', 'lllqq', 3432453, 'gfdgdf', '45345.00', '2016-11-06 00:00:00', '2016-11-05 06:06:35', '2016-11-05 15:06:35', 1, 1),
(9, '', 'test', 3245235, 'gfgdfgdf', '3242.00', '2016-11-07 00:00:00', '2016-11-05 06:06:29', '2016-11-05 15:06:41', 1, 1),
(10, '', 'time test', 343434, 'gdfdg', '4545.00', '2014-11-05 00:00:00', '2016-11-05 06:18:33', '2016-11-05 11:48:33', 1, 1),
(11, '', 'dfgdff', 2147483647, 'dfhg', '456.00', '2016-11-10 00:00:00', '2016-11-10 04:29:12', '2016-11-10 09:59:12', 1, 1),
(12, '', 'sdfg', 2147483647, 'sg', '346.00', '2016-11-10 00:00:00', '2016-11-10 04:29:25', '2016-11-10 09:59:25', 1, 1),
(13, '', 'ert', 2147483647, 'dsfg', '346.00', '2016-11-10 00:00:00', '2016-11-10 04:29:36', '2016-11-15 17:26:57', 1, 0),
(14, '', 'sdfg', 2147483647, 'sdfg', '345.00', '2016-11-10 00:00:00', '2016-11-10 04:29:50', '2016-11-10 09:59:50', 1, 1),
(15, '', 'ert', 2147483647, 'adfg', '354.00', '2016-11-10 00:00:00', '2016-11-10 12:28:43', '2016-11-15 17:27:06', 1, 0),
(16, '', 'dgf', 2147483647, 'ar', '345.00', '2016-11-10 00:00:00', '2016-11-10 04:30:23', '2016-11-10 10:00:23', 1, 1),
(17, '', 'sdfg', 2147483647, 'adg', '0.00', '2016-11-10 00:00:00', '2016-11-10 04:30:34', '2016-11-10 10:00:34', 1, 1),
(18, '', 'asdg', 2147483647, 'asd', '45.00', '2016-11-10 00:00:00', '2016-11-10 12:04:15', '2016-11-10 17:34:15', 0, 1),
(19, '', 'asdf', 214748364, 'asdf', '45.00', '2016-11-10 00:00:00', '2016-11-11 11:31:07', '2016-11-11 17:01:07', 1, 1),
(20, '', 'asdf', 2147483647, 'asdf', '345.00', '2016-11-10 00:00:00', '2016-11-10 04:31:25', '2016-11-10 10:01:25', 1, 1),
(21, '', 'sdfg', 2147483647, 'dgr', '354.00', '2016-11-10 00:00:00', '2016-11-10 04:31:51', '2016-11-10 10:01:51', 1, 1),
(22, '', 'etr', 2147483647, 'dg', '345.00', '2016-11-10 00:00:00', '2016-11-10 12:28:26', '2016-11-10 17:58:26', 1, 1),
(23, '', 'ertetr', 2147483647, 'dfg', '456.00', '2016-11-10 00:00:00', '2016-11-10 04:32:37', '2016-11-10 10:02:37', 1, 1),
(24, '', 'Evan', 2147483647, 'Vellore', '25000.00', '2016-11-10 00:00:00', '2016-11-10 04:33:31', '2016-11-10 10:03:31', 1, 1),
(25, '', 'test see', 232323, 'fgfdgfd', '100.00', '2016-11-19 00:00:00', '2016-11-19 09:37:00', '2017-01-30 17:49:52', 1, 1),
(26, '', 'vivek', 5656565, 'fdgdfgfdg', '500.00', '2016-11-01 00:00:00', '2017-02-08 05:08:03', '2017-02-08 10:38:03', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_employee_attendance`
--

CREATE TABLE `wp_employee_attendance` (
  `id` int(11) NOT NULL,
  `emp_id` int(20) NOT NULL,
  `emp_attendance` int(2) NOT NULL,
  `attendance_date` datetime DEFAULT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_employee_attendance`
--

INSERT INTO `wp_employee_attendance` (`id`, `emp_id`, `emp_attendance`, `attendance_date`, `active`) VALUES
(1, 4, 1, '2016-11-05 00:00:00', 0),
(2, 4, 0, '2016-11-05 00:00:00', 0),
(3, 3, 1, '2016-11-05 00:00:00', 0),
(4, 3, 0, '2016-11-05 00:00:00', 0),
(5, 3, 1, '2016-11-05 00:00:00', 0),
(6, 2, 1, '2016-11-05 00:00:00', 0),
(7, 3, 0, '2016-11-05 00:00:00', 0),
(8, 2, 1, '2016-11-05 00:00:00', 0),
(9, 3, 0, '2016-11-04 00:00:00', 1),
(10, 8, 0, '2016-11-05 00:00:00', 1),
(11, 9, 1, '2016-11-05 00:00:00', 1),
(12, 5, 0, '2016-11-05 00:00:00', 0),
(13, 5, 1, '2016-11-05 00:00:00', 0),
(14, 5, 0, '2016-11-05 00:00:00', 0),
(15, 5, 0, '2016-11-05 00:00:00', 1),
(16, 3, 0, '2016-11-05 00:00:00', 0),
(17, 3, 1, '2016-11-05 00:00:00', 1),
(18, 2, 1, '2016-11-09 00:00:00', 1),
(19, 2, 1, '2016-11-10 00:00:00', 1),
(20, 6, 0, '2016-11-10 00:00:00', 1),
(21, 8, 1, '2016-11-10 00:00:00', 1),
(22, 1, 1, '2016-11-11 00:00:00', 0),
(23, 2, 1, '2016-11-11 00:00:00', 1),
(24, 4, 1, '2016-11-09 00:00:00', 1),
(25, 26, 1, '2017-02-08 00:00:00', 1),
(26, 1, 1, '2017-09-05 00:00:00', 1),
(27, 1, 0, '2017-09-04 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_employee_salary`
--

CREATE TABLE `wp_employee_salary` (
  `id` int(11) NOT NULL,
  `emp_id` int(20) NOT NULL,
  `sal_status` varchar(250) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `sal_update_date` datetime NOT NULL,
  `amount` decimal(9,2) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_employee_salary`
--

INSERT INTO `wp_employee_salary` (`id`, `emp_id`, `sal_status`, `remark`, `sal_update_date`, `amount`, `updated_at`, `active`) VALUES
(1, 3, 'advance', '', '2017-01-28 00:00:00', '1000.00', '2017-01-30 12:27:29', 1),
(2, 1, 'salary', '', '2016-11-07 00:00:00', '0.00', '2017-01-29 13:02:27', 1),
(3, 2, '', '', '2016-11-07 00:00:00', '0.00', '2016-11-07 17:54:48', 1),
(4, 2, '', '', '2016-11-07 00:00:00', '0.00', '2017-01-29 13:53:51', 1),
(5, 7, '', '', '2016-11-07 00:00:00', '0.00', '2016-11-11 17:54:48', 1),
(6, 3, 'advance', '', '2017-01-27 00:00:00', '2000.00', '2017-01-30 12:39:59', 1),
(7, 7, '', '', '2016-11-07 00:00:00', '0.00', '2016-11-09 17:54:48', 1),
(8, 7, '', '', '2016-11-08 00:00:00', '0.00', '2016-11-08 11:45:11', 1),
(9, 4, '', '', '2016-11-10 00:00:00', '0.00', '2017-01-29 13:53:58', 0),
(10, 5, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:11:49', 1),
(11, 6, 'salary', '', '2016-11-10 00:00:00', '7000.00', '2017-01-29 15:13:38', 1),
(12, 8, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:12:27', 1),
(13, 9, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:12:55', 1),
(14, 10, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:13:11', 1),
(15, 11, 'salary', '', '2016-11-10 00:00:00', '5000.00', '2017-01-29 13:12:25', 1),
(16, 12, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:13:52', 1),
(17, 13, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:14:13', 1),
(18, 14, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:14:38', 1),
(19, 15, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:14:59', 1),
(20, 16, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:15:28', 1),
(21, 17, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:15:58', 1),
(22, 18, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:16:28', 1),
(23, 19, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:16:59', 1),
(24, 20, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:17:34', 1),
(25, 21, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:17:54', 1),
(26, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:20:38', 1),
(27, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:21:45', 1),
(28, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:22:28', 1),
(29, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:22:56', 1),
(30, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:23:13', 1),
(31, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:23:29', 1),
(32, 1, '', '', '2017-01-29 00:00:00', '0.00', '2017-01-29 14:07:33', 1),
(33, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:23:57', 1),
(34, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:24:15', 1),
(35, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:24:35', 1),
(36, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:24:48', 1),
(37, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:25:06', 1),
(38, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:25:24', 1),
(39, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:25:51', 1),
(40, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:26:09', 1),
(41, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:26:23', 1),
(42, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:26:39', 1),
(43, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:26:57', 1),
(44, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:27:12', 1),
(45, 1, '', '', '2016-11-10 00:00:00', '0.00', '2016-11-10 10:27:43', 1),
(46, 6, 'advance', '', '2016-11-10 00:00:00', '1000.00', '2017-01-29 15:13:42', 1),
(47, 2, '', '', '2017-01-28 00:00:00', '0.00', '2017-01-29 12:17:03', 1),
(48, 7, '', '', '2017-01-29 00:00:00', '0.00', '2017-01-29 12:17:48', 1),
(49, 3, 'salary', '', '2017-01-26 00:00:00', '1000.00', '2017-01-30 12:07:00', 1),
(56, 3, 'salary', '', '2017-01-31 00:00:00', '2250.00', '2017-01-31 15:38:30', 1),
(57, 3, 'advance', '', '2017-01-31 00:00:00', '750.00', '2017-01-31 15:38:30', 1),
(58, 3, 'advance', '', '2017-01-31 00:00:00', '1000.00', '2017-01-31 15:45:28', 1),
(59, 6, 'salary', '', '2017-02-03 00:00:00', '25500.00', '2017-02-03 16:17:51', 1),
(60, 6, 'advance', '', '2017-02-03 00:00:00', '1000.00', '2017-02-03 16:17:51', 1),
(61, 6, 'salary', 'sal', '2017-02-04 00:00:00', '300.00', '2017-02-04 10:40:41', 1),
(62, 6, 'advance', 'adv_prv', '2017-02-04 00:00:00', '700.00', '2017-02-04 10:40:41', 1),
(63, 26, 'advance', 'adv', '2017-02-08 00:00:00', '1000.00', '2017-02-08 10:39:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_employee_salary_data`
--

CREATE TABLE `wp_employee_salary_data` (
  `id` int(11) NOT NULL,
  `salary_id` int(10) NOT NULL,
  `amount` decimal(9,2) NOT NULL,
  `from_advance` int(2) NOT NULL,
  `have_to_pay` varchar(250) NOT NULL,
  `total_working_days` int(10) NOT NULL,
  `leave_taken` int(10) NOT NULL,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_income_list`
--

CREATE TABLE `wp_income_list` (
  `id` int(11) NOT NULL,
  `cash_date` datetime NOT NULL,
  `cash_amount` decimal(9,2) NOT NULL,
  `cash_description` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_income_list`
--

INSERT INTO `wp_income_list` (`id`, `cash_date`, `cash_amount`, `cash_description`, `created_at`, `modified_at`, `active`) VALUES
(1, '2016-11-18 00:00:00', '10.00', 'ha ha ha', '2016-11-08 12:58:49', '2016-11-15 17:37:04', 0),
(2, '2016-11-10 00:00:00', '65.00', 'ghgfdg', '2016-11-08 14:15:04', '0000-00-00 00:00:00', 1),
(3, '2016-11-16 00:00:00', '12000.00', 'fthyjufgh', '2016-11-16 11:44:54', '0000-00-00 00:00:00', 1),
(4, '2016-11-21 00:00:00', '1000.00', 'wrw', '2016-11-21 14:27:19', '0000-00-00 00:00:00', 1),
(5, '2017-01-25 00:00:00', '643.00', 'rtdf', '2017-01-25 18:16:20', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_lots`
--

CREATE TABLE `wp_lots` (
  `id` bigint(20) NOT NULL,
  `lot_number` varchar(255) NOT NULL,
  `brand_name` text NOT NULL,
  `product_name` text NOT NULL,
  `weight` float NOT NULL,
  `bag_weight` int(2) NOT NULL,
  `lot_type` varchar(255) NOT NULL,
  `slab_system` int(2) NOT NULL,
  `parent_id` varchar(255) NOT NULL,
  `stock_alert` int(11) NOT NULL DEFAULT '1',
  `basic_price` decimal(9,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_lots`
--

INSERT INTO `wp_lots` (`id`, `lot_number`, `brand_name`, `product_name`, `weight`, `bag_weight`, `lot_type`, `slab_system`, `parent_id`, `stock_alert`, `basic_price`, `created_at`, `modified_at`, `active`) VALUES
(1, 'LOT0001', 'KKTT', 'Rise', 50, 0, 'original', 0, '0', 1, '0.00', '2016-10-18 02:28:07', '2016-11-15 16:34:42', 1),
(2, 'LOT0002', 'ESR', 'Samba', 75, 1, 'original', 1, '0', 1, '0.00', '2016-10-18 02:34:09', '0000-00-00 00:00:00', 1),
(3, 'DLOT0002', 'ESR', 'Samba', 75, 1, 'dummy', 1, '2', 1, '0.00', '2016-10-18 02:34:09', '2016-10-19 15:02:00', 1),
(4, '11', 'src', 'src special', 5, 0, 'original', 0, '0', 1, '0.00', '2016-10-19 06:10:49', '0000-00-00 00:00:00', 1),
(5, '1111', 'src', 'src special', 5, 1, 'original', 1, '0', 1, '0.00', '2016-10-19 06:12:03', '0000-00-00 00:00:00', 1),
(6, '11.1', 'src', 'src special', 5, 1, 'dummy', 1, '5', 1, '0.00', '2016-10-19 06:12:03', '2016-10-19 17:12:47', 1),
(7, 'OUTSTOCK1', 'Out Brand', 'Out Product', 75, 0, 'original', 0, '0', 1, '0.00', '2016-10-26 02:39:18', '2016-10-26 13:57:04', 1),
(8, 'OUT2323', 'Basu', 'AQWEE', 5, 0, 'original', 0, '0', 1, '0.00', '2016-10-26 05:03:47', '0000-00-00 00:00:00', 1),
(9, 'lot108', 'BB', 'Idly', 50, 0, 'original', 0, '0', 1, '0.00', '2016-11-02 07:15:17', '0000-00-00 00:00:00', 1),
(10, 'qwerty', 'Sri Krishna', '50Kg GR', 5, 1, 'original', 1, '0', 1, '0.00', '2016-11-03 00:48:05', '0000-00-00 00:00:00', 1),
(11, 'dQWERTY', 'Sri Krishna', '50Kg GR', 5, 1, 'dummy', 1, '10', 1, '0.00', '2016-11-03 00:48:06', '0000-00-00 00:00:00', 1),
(12, 'fgfg', 'rtgertret', 'ASAS', 50, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:38:56', '2016-11-15 17:20:32', 0),
(13, 'sasd', 'ffasd', 'B.R', 5, 0, 'original', 0, '0', 1, '10.00', '2016-11-09 22:41:22', '2017-01-09 15:02:02', 1),
(14, 'asdf', 'sdfgh', 'R.R.(T)', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:41:56', '0000-00-00 00:00:00', 1),
(15, 'ddd', 'ddd', 'Wheat', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:42:26', '0000-00-00 00:00:00', 1),
(16, 'sdf', 'asdf', 'B.R', 5, 0, 'original', 0, '0', 1, '200.00', '2016-11-09 22:42:52', '2017-02-02 14:27:35', 1),
(17, 'gfh', 'dfgy', 'R.R.(T)', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:43:17', '2016-11-15 17:17:13', 0),
(18, 'dfg', 'sdfg', 'R.H', 5, 0, 'original', 0, '0', 1, '300.00', '2016-11-09 22:43:42', '2016-12-19 10:34:04', 1),
(19, 'jk', 'hjk', 'Idly-IR 20', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:44:02', '2016-11-15 17:06:08', 0),
(20, 'sdfg', 'sdfg', 'B.R', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:44:50', '0000-00-00 00:00:00', 1),
(21, 'jhg', 'kljh', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:45:22', '0000-00-00 00:00:00', 1),
(22, 'ghd', 'dgqq', 'Wheat', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:46:22', '2016-11-10 09:51:17', 1),
(23, 'kjhkj', 'kjh', 'Wheat', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:46:58', '0000-00-00 00:00:00', 1),
(24, 'lkhk', 'gjkhg', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:47:46', '2016-11-11 16:51:26', 1),
(25, 'hgd', 'hjfh', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:48:12', '0000-00-00 00:00:00', 1),
(26, 'hjgf', 'gfdg', 'Idly', 10, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:48:52', '0000-00-00 00:00:00', 1),
(27, 'dfsd', 'sf', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-09 22:49:35', '0000-00-00 00:00:00', 1),
(28, 'lotghh', 'aa', 'B.R', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:11:28', '0000-00-00 00:00:00', 1),
(29, 'lota', 'll', 'Wheat', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:12:14', '0000-00-00 00:00:00', 1),
(30, 'lotb', 'mm', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:12:52', '0000-00-00 00:00:00', 1),
(31, 'lotc', 'ss', 'Basmati', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:13:20', '2016-11-10 15:01:05', 1),
(32, 'lot', 'ssa', 'Wheat', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:27:04', '0000-00-00 00:00:00', 1),
(33, 'lot1234', 'ssabcd', 'B.R', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:27:36', '0000-00-00 00:00:00', 1),
(34, 'lothiol', 'ssfgh', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:28:29', '0000-00-00 00:00:00', 1),
(35, 'lotkkkk', 'ssdfgh', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:28:50', '0000-00-00 00:00:00', 1),
(36, 'lotkjh', 'sslkj', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:29:26', '0000-00-00 00:00:00', 1),
(37, 'lotkjhdrr', 'ssnkjkj', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:30:43', '0000-00-00 00:00:00', 1),
(38, 'lotqwert', 'ssbbbjiyty', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:31:12', '2016-11-10 16:51:31', 1),
(39, 'lotbnm', 'ssnvbg', 'Idly', 5, 0, 'original', 0, '0', 1, '0.00', '2016-11-10 01:32:00', '0000-00-00 00:00:00', 1),
(40, '30', 'sungate', 'B.R', 75, 1, 'original', 1, '0', 1, '0.00', '2016-11-18 10:33:53', '0000-00-00 00:00:00', 1),
(41, '55', 'arc', 'Select Product Typ', 5, 1, 'original', 1, '0', 1, '0.00', '2016-11-19 04:36:48', '0000-00-00 00:00:00', 1),
(42, 'ASDFGHJ', 'seegsn', 'Basmati', 50, 0, 'original', 0, '0', 45, '0.00', '2016-11-22 01:22:57', '2016-11-22 12:23:24', 1),
(43, 'RYWQQ', 'dfdf', 'Idly', 50, 1, 'original', 1, '0', 20, '50.00', '2016-11-22 03:18:14', '0000-00-00 00:00:00', 1),
(44, 'RYWQQ-D', 'dfdf', 'Idly', 50, 1, 'dummy', 1, '43', 20, '50.00', '2016-11-22 03:18:14', '0000-00-00 00:00:00', 1),
(45, 'SKU2700', 'Krishna', 'B.R', 75, 1, 'original', 1, '0', 75, '2000.00', '2017-02-07 23:11:35', '0000-00-00 00:00:00', 1),
(46, 'DSKU2700', 'Krishna', 'B.R', 75, 1, 'dummy', 1, '45', 75, '2000.00', '2017-02-07 23:11:35', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_lots_detail`
--

CREATE TABLE `wp_lots_detail` (
  `id` bigint(20) NOT NULL,
  `lot_id` bigint(20) NOT NULL,
  `lot_number` varchar(255) NOT NULL,
  `weight_from` double NOT NULL,
  `weight_to` double NOT NULL,
  `price` float NOT NULL,
  `lot_type` text NOT NULL,
  `sale_type` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_lots_detail`
--

INSERT INTO `wp_lots_detail` (`id`, `lot_id`, `lot_number`, `weight_from`, `weight_to`, `price`, `lot_type`, `sale_type`, `created_at`, `active`) VALUES
(1, 1, 'LOT0001', 0, 10, 50, 'original', 'retail', '2016-10-18 02:28:07', 0),
(2, 1, 'LOT0001', 0, 10, 40, 'original', 'wholesale', '2016-10-18 02:28:07', 0),
(3, 2, 'LOT0002', 0, 10, 50, 'original', 'retail', '2016-10-18 02:34:09', 0),
(4, 2, 'LOT0002', 10, 20, 45, 'original', 'retail', '2016-10-18 02:34:09', 0),
(5, 2, 'LOT0002', 20, 30, 40, 'original', 'retail', '2016-10-18 02:34:09', 0),
(6, 2, 'LOT0002', 0, 10, 48, 'original', 'wholesale', '2016-10-18 02:34:09', 0),
(7, 2, 'LOT0002', 10, 20, 43, 'original', 'wholesale', '2016-10-18 02:34:09', 0),
(8, 2, 'LOT0002', 20, 30, 38, 'original', 'wholesale', '2016-10-18 02:34:09', 0),
(9, 3, 'DLOT0002', 0, 10, 55, 'dummy', 'retail', '2016-10-18 02:34:09', 0),
(10, 3, 'DLOT0002', 10, 20, 50, 'dummy', 'retail', '2016-10-18 02:34:09', 0),
(11, 3, 'DLOT0002', 20, 30, 45, 'dummy', 'retail', '2016-10-18 02:34:09', 0),
(12, 3, 'DLOT0002', 0, 10, 53, 'dummy', 'wholesale', '2016-10-18 02:34:09', 0),
(13, 3, 'DLOT0002', 10, 20, 48, 'dummy', 'wholesale', '2016-10-18 02:34:09', 0),
(14, 3, 'DLOT0002', 20, 30, 43, 'dummy', 'wholesale', '2016-10-18 02:34:09', 0),
(15, 2, 'LOT0002', 0, 10, 50, 'original', 'retail', '2016-10-19 04:02:00', 1),
(16, 2, 'LOT0002', 10, 20, 45, 'original', 'retail', '2016-10-19 04:02:00', 1),
(17, 2, 'LOT0002', 20, 30, 40, 'original', 'retail', '2016-10-19 04:02:00', 1),
(18, 2, 'LOT0002', 30, 33, 44, 'original', 'retail', '2016-10-19 04:02:00', 1),
(19, 2, 'LOT0002', 33, 34, 67, 'original', 'retail', '2016-10-19 04:02:00', 1),
(20, 2, 'LOT0002', 34, 37, 77, 'original', 'retail', '2016-10-19 04:02:00', 1),
(21, 2, 'LOT0002', 37, 38, 78, 'original', 'retail', '2016-10-19 04:02:00', 1),
(22, 2, 'LOT0002', 0, 10, 48, 'original', 'wholesale', '2016-10-19 04:02:00', 1),
(23, 2, 'LOT0002', 10, 20, 43, 'original', 'wholesale', '2016-10-19 04:02:00', 1),
(24, 2, 'LOT0002', 20, 30, 38, 'original', 'wholesale', '2016-10-19 04:02:00', 1),
(25, 3, 'DLOT0002', 0, 10, 55, 'dummy', 'retail', '2016-10-19 04:02:00', 1),
(26, 3, 'DLOT0002', 10, 20, 50, 'dummy', 'retail', '2016-10-19 04:02:01', 1),
(27, 3, 'DLOT0002', 20, 30, 45, 'dummy', 'retail', '2016-10-19 04:02:01', 1),
(28, 3, 'DLOT0002', 0, 10, 53, 'dummy', 'wholesale', '2016-10-19 04:02:01', 1),
(29, 3, 'DLOT0002', 10, 20, 48, 'dummy', 'wholesale', '2016-10-19 04:02:01', 1),
(30, 3, 'DLOT0002', 20, 30, 43, 'dummy', 'wholesale', '2016-10-19 04:02:01', 1),
(31, 4, '11', 1, 5, 50, 'original', 'retail', '2016-10-19 06:10:49', 1),
(32, 4, '11', 1, 5, 45, 'original', 'wholesale', '2016-10-19 06:10:49', 1),
(33, 5, '1111', 1, 5, 60, 'original', 'retail', '2016-10-19 06:12:03', 0),
(34, 5, '1111', 5, 10, 40, 'original', 'retail', '2016-10-19 06:12:03', 0),
(35, 5, '1111', 1, 5, 49, 'original', 'wholesale', '2016-10-19 06:12:03', 0),
(36, 5, '1111', 5, 10, 29, 'original', 'wholesale', '2016-10-19 06:12:03', 0),
(37, 6, '11.1', 1, 5, 100, 'dummy', 'retail', '2016-10-19 06:12:03', 0),
(38, 6, '11.1', 1, 5, 90, 'dummy', 'wholesale', '2016-10-19 06:12:03', 0),
(39, 5, '1111', 1, 5, 60, 'original', 'retail', '2016-10-19 06:12:47', 1),
(40, 5, '1111', 5, 10, 40, 'original', 'retail', '2016-10-19 06:12:47', 1),
(41, 5, '1111', 1, 5, 49, 'original', 'wholesale', '2016-10-19 06:12:47', 1),
(42, 5, '1111', 5, 10, 29, 'original', 'wholesale', '2016-10-19 06:12:47', 1),
(43, 6, '11.1', 1, 5, 100, 'dummy', 'retail', '2016-10-19 06:12:47', 1),
(44, 6, '11.1', 1, 5, 90, 'dummy', 'wholesale', '2016-10-19 06:12:47', 1),
(45, 7, 'OUTSTOCK1', 0, 10, 20, 'original', 'retail', '2016-10-26 02:39:18', 0),
(46, 7, 'OUTSTOCK1', 0, 10, 15, 'original', 'wholesale', '2016-10-26 02:39:18', 0),
(47, 7, 'OUTSTOCK1', 0, 10, 20, 'original', 'retail', '2016-10-26 02:57:04', 1),
(48, 7, 'OUTSTOCK1', 0, 10, 15, 'original', 'wholesale', '2016-10-26 02:57:04', 1),
(49, 8, 'OUT2323', 0, 0, 0, 'original', 'retail', '2016-10-26 05:03:47', 1),
(50, 8, 'OUT2323', 0, 0, 0, 'original', 'wholesale', '2016-10-26 05:03:47', 1),
(51, 9, 'lot108', 0, 10, 10, 'original', 'retail', '2016-11-02 07:15:17', 1),
(52, 9, 'lot108', 0, 10, 8, 'original', 'wholesale', '2016-11-02 07:15:17', 1),
(53, 10, 'qwerty', 0, 100, 20, 'original', 'retail', '2016-11-03 00:48:05', 1),
(54, 10, 'qwerty', 100, 200, 18.4, 'original', 'retail', '2016-11-03 00:48:06', 1),
(55, 10, 'qwerty', 200, 300, 17.5, 'original', 'retail', '2016-11-03 00:48:06', 1),
(56, 10, 'qwerty', 0, 100, 19.3, 'original', 'wholesale', '2016-11-03 00:48:06', 1),
(57, 10, 'qwerty', 100, 200, 16.2, 'original', 'wholesale', '2016-11-03 00:48:06', 1),
(58, 10, 'qwerty', 200, 300, 17.1, 'original', 'wholesale', '2016-11-03 00:48:06', 1),
(59, 11, 'dQWERTY', 0, 100, 22.25, 'dummy', 'retail', '2016-11-03 00:48:06', 1),
(60, 11, 'dQWERTY', 100, 200, 20.3, 'dummy', 'retail', '2016-11-03 00:48:06', 1),
(61, 11, 'dQWERTY', 200, 300, 18.55, 'dummy', 'retail', '2016-11-03 00:48:06', 1),
(62, 11, 'dQWERTY', 0, 100, 21.45, 'dummy', 'wholesale', '2016-11-03 00:48:06', 1),
(63, 11, 'dQWERTY', 100, 200, 19.95, 'dummy', 'wholesale', '2016-11-03 00:48:06', 1),
(64, 11, 'dQWERTY', 200, 300, 18.3, 'dummy', 'wholesale', '2016-11-03 00:48:06', 1),
(65, 12, 'fgfg', 0, 10, 10, 'original', 'retail', '2016-11-09 22:38:56', 1),
(66, 12, 'fgfg', 0, 10, 8, 'original', 'wholesale', '2016-11-09 22:38:56', 1),
(67, 13, 'sasd', 0, 10, 250, 'original', 'retail', '2016-11-09 22:41:22', 0),
(68, 13, 'sasd', 0, 10, 240, 'original', 'wholesale', '2016-11-09 22:41:22', 0),
(69, 14, 'asdf', 0, 10, 900, 'original', 'retail', '2016-11-09 22:41:56', 1),
(70, 14, 'asdf', 1, 10, 800, 'original', 'wholesale', '2016-11-09 22:41:56', 1),
(71, 15, 'ddd', 0, 10, 700, 'original', 'retail', '2016-11-09 22:42:26', 1),
(72, 15, 'ddd', 0, 10, 600, 'original', 'wholesale', '2016-11-09 22:42:26', 1),
(73, 16, 'sdf', 0, 10, 200, 'original', 'retail', '2016-11-09 22:42:52', 0),
(74, 16, 'sdf', 0, 10, 100, 'original', 'wholesale', '2016-11-09 22:42:52', 0),
(75, 17, 'gfh', 0, 10, 200, 'original', 'retail', '2016-11-09 22:43:17', 1),
(76, 17, 'gfh', 0, 10, 100, 'original', 'wholesale', '2016-11-09 22:43:17', 1),
(77, 18, 'dfg', 0, 10, 300, 'original', 'retail', '2016-11-09 22:43:42', 0),
(78, 18, 'dfg', 0, 10, 250, 'original', 'wholesale', '2016-11-09 22:43:42', 0),
(79, 19, 'jk', 0, 10, 100, 'original', 'retail', '2016-11-09 22:44:02', 1),
(80, 19, 'jk', 0, 10, 50, 'original', 'wholesale', '2016-11-09 22:44:02', 1),
(81, 20, 'sdfg', 0, 10, 200, 'original', 'retail', '2016-11-09 22:44:50', 1),
(82, 20, 'sdfg', 0, 10, 100, 'original', 'wholesale', '2016-11-09 22:44:50', 1),
(83, 21, 'jhg', 0, 10, 100, 'original', 'retail', '2016-11-09 22:45:22', 1),
(84, 21, 'jhg', 0, 10, 80, 'original', 'wholesale', '2016-11-09 22:45:22', 1),
(85, 22, 'ghd', 0, 10, 500, 'original', 'retail', '2016-11-09 22:46:22', 0),
(86, 22, 'ghd', 0, 10, 400, 'original', 'wholesale', '2016-11-09 22:46:22', 0),
(87, 23, 'kjhkj', 0, 10, 200, 'original', 'retail', '2016-11-09 22:46:58', 1),
(88, 23, 'kjhkj', 0, 10, 100, 'original', 'wholesale', '2016-11-09 22:46:58', 1),
(89, 24, 'lkhk', 0, 10, 300, 'original', 'retail', '2016-11-09 22:47:46', 0),
(90, 24, 'lkhk', 0, 10, 200, 'original', 'wholesale', '2016-11-09 22:47:46', 0),
(91, 25, 'hgd', 0, 10, 500, 'original', 'retail', '2016-11-09 22:48:12', 1),
(92, 25, 'hgd', 0, 10, 400, 'original', 'wholesale', '2016-11-09 22:48:12', 1),
(93, 26, 'hjgf', 0, 10, 500, 'original', 'retail', '2016-11-09 22:48:52', 1),
(94, 26, 'hjgf', 0, 10, 400, 'original', 'wholesale', '2016-11-09 22:48:52', 1),
(95, 27, 'dfsd', 0, 10, 200, 'original', 'retail', '2016-11-09 22:49:35', 1),
(96, 27, 'dfsd', 0, 10, 100, 'original', 'wholesale', '2016-11-09 22:49:35', 1),
(97, 13, 'sasd', 0, 10, 250, 'original', 'retail', '2016-11-09 22:51:07', 0),
(98, 13, 'sasd', 0, 10, 240, 'original', 'wholesale', '2016-11-09 22:51:07', 0),
(99, 22, 'ghd', 0, 10, 500, 'original', 'retail', '2016-11-09 22:51:17', 1),
(100, 22, 'ghd', 0, 10, 400, 'original', 'wholesale', '2016-11-09 22:51:17', 1),
(101, 28, 'lotghh', 0, 10, 900, 'original', 'retail', '2016-11-10 01:11:28', 1),
(102, 28, 'lotghh', 0, 10, 800, 'original', 'wholesale', '2016-11-10 01:11:28', 1),
(103, 29, 'lota', 0, 10, 100, 'original', 'retail', '2016-11-10 01:12:14', 1),
(104, 29, 'lota', 0, 10, 90, 'original', 'wholesale', '2016-11-10 01:12:14', 1),
(105, 30, 'lotb', 0, 10, 100, 'original', 'retail', '2016-11-10 01:12:52', 1),
(106, 30, 'lotb', 0, 10, 90, 'original', 'wholesale', '2016-11-10 01:12:52', 1),
(107, 31, 'lotc', 0, 10, 100, 'original', 'retail', '2016-11-10 01:13:20', 0),
(108, 31, 'lotc', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:13:20', 0),
(109, 32, 'lot', 0, 10, 100, 'original', 'retail', '2016-11-10 01:27:04', 1),
(110, 32, 'lot', 0, 10, 200, 'original', 'wholesale', '2016-11-10 01:27:04', 1),
(111, 33, 'lot1234', 0, 10, 200, 'original', 'retail', '2016-11-10 01:27:36', 1),
(112, 33, 'lot1234', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:27:36', 1),
(113, 34, 'lothiol', 0, 10, 200, 'original', 'retail', '2016-11-10 01:28:29', 1),
(114, 34, 'lothiol', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:28:29', 1),
(115, 35, 'lotkkkk', 0, 10, 200, 'original', 'retail', '2016-11-10 01:28:50', 1),
(116, 35, 'lotkkkk', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:28:50', 1),
(117, 36, 'lotkjh', 0, 10, 200, 'original', 'retail', '2016-11-10 01:29:26', 1),
(118, 36, 'lotkjh', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:29:26', 1),
(119, 37, 'lotkjhdrr', 0, 10, 100, 'original', 'retail', '2016-11-10 01:30:43', 1),
(120, 37, 'lotkjhdrr', 0, 10, 90, 'original', 'wholesale', '2016-11-10 01:30:43', 1),
(121, 38, 'lotqwert', 0, 10, 100, 'original', 'retail', '2016-11-10 01:31:12', 0),
(122, 38, 'lotqwert', 0, 10, 95, 'original', 'wholesale', '2016-11-10 01:31:12', 0),
(123, 39, 'lotbnm', 0, 10, 200, 'original', 'retail', '2016-11-10 01:32:00', 0),
(124, 39, 'lotbnm', 0, 10, 100, 'original', 'wholesale', '2016-11-10 01:32:00', 0),
(125, 31, 'lotc', 0, 10, 100, 'original', 'retail', '2016-11-10 04:01:05', 1),
(126, 31, 'lotc', 0, 10, 100, 'original', 'wholesale', '2016-11-10 04:01:05', 1),
(127, 38, 'lotqwert', 0, 10, 100, 'original', 'retail', '2016-11-10 05:51:31', 1),
(128, 38, 'lotqwert', 0, 10, 95, 'original', 'wholesale', '2016-11-10 05:51:31', 1),
(129, 24, 'lkhk', 0, 10, 300, 'original', 'retail', '2016-11-11 05:51:19', 0),
(130, 24, 'lkhk', 0, 10, 200, 'original', 'wholesale', '2016-11-11 05:51:19', 0),
(131, 24, 'lkhk', 0, 10, 300, 'original', 'retail', '2016-11-11 05:51:26', 1),
(132, 24, 'lkhk', 0, 10, 200, 'original', 'wholesale', '2016-11-11 05:51:26', 1),
(133, 1, 'LOT0001', 0, 10, 50, 'original', 'retail', '2016-11-15 05:34:42', 1),
(134, 1, 'LOT0001', 0, 10, 40, 'original', 'wholesale', '2016-11-15 05:34:42', 1),
(135, 40, '30', 0, 4.9, 55.2, 'original', 'retail', '2016-11-18 10:33:53', 0),
(136, 40, '30', 5, 29.9, 55, 'original', 'retail', '2016-11-18 10:33:53', 0),
(137, 40, '30', 30, 36.9, 54.9, 'original', 'retail', '2016-11-18 10:33:53', 0),
(138, 40, '30', 37, 49.9, 54.7, 'original', 'retail', '2016-11-18 10:33:53', 0),
(139, 40, '30', 50, 74.9, 54.6, 'original', 'retail', '2016-11-18 10:33:53', 0),
(140, 40, '30', 75, 100, 54.2, 'original', 'retail', '2016-11-18 10:33:53', 0),
(141, 40, '30', 0, 100, 55.2, 'original', 'wholesale', '2016-11-18 10:33:54', 0),
(142, 40, '30', 0, 4.9, 55.2, 'original', 'retail', '2016-11-18 10:35:07', 1),
(143, 40, '30', 5, 29.9, 55, 'original', 'retail', '2016-11-18 10:35:07', 1),
(144, 40, '30', 30, 36.9, 54.9, 'original', 'retail', '2016-11-18 10:35:07', 1),
(145, 40, '30', 37, 49.9, 54.7, 'original', 'retail', '2016-11-18 10:35:07', 1),
(146, 40, '30', 50, 74.9, 54.6, 'original', 'retail', '2016-11-18 10:35:07', 1),
(147, 40, '30', 75, 100, 54.2, 'original', 'retail', '2016-11-18 10:35:07', 1),
(148, 40, '30', 0, 100, 55.2, 'original', 'wholesale', '2016-11-18 10:35:07', 1),
(149, 41, '55', 0, 9, 55, 'original', 'retail', '2016-11-19 04:36:48', 1),
(150, 41, '55', 10, 75, 50, 'original', 'retail', '2016-11-19 04:36:48', 1),
(151, 41, '55', 0, 0, 0, 'original', 'wholesale', '2016-11-19 04:36:48', 1),
(152, 39, 'lotbnm', 0, 10, 200, 'original', 'retail', '2016-11-21 03:02:17', 1),
(153, 39, 'lotbnm', 0, 10, 100, 'original', 'wholesale', '2016-11-21 03:02:17', 1),
(154, 42, 'ASDFGHJ', 0, 40, 100, 'original', 'retail', '2016-11-22 01:22:57', 0),
(155, 42, 'ASDFGHJ', 0, 40, 80, 'original', 'wholesale', '2016-11-22 01:22:57', 0),
(156, 42, 'ASDFGHJ', 0, 40, 100, 'original', 'retail', '2016-11-22 01:23:24', 1),
(157, 42, 'ASDFGHJ', 0, 40, 80, 'original', 'wholesale', '2016-11-22 01:23:24', 1),
(158, 43, 'RYWQQ', 0, 10, 50, 'original', 'retail', '2016-11-22 03:18:14', 1),
(159, 43, 'RYWQQ', 10, 20, 48, 'original', 'retail', '2016-11-22 03:18:14', 1),
(160, 43, 'RYWQQ', 20, 30, 45, 'original', 'retail', '2016-11-22 03:18:14', 1),
(161, 43, 'RYWQQ', 0, 10, 49, 'original', 'wholesale', '2016-11-22 03:18:14', 1),
(162, 43, 'RYWQQ', 10, 20, 47, 'original', 'wholesale', '2016-11-22 03:18:14', 1),
(163, 43, 'RYWQQ', 20, 30, 44, 'original', 'wholesale', '2016-11-22 03:18:14', 1),
(164, 44, 'RYWQQ-D', 0, 10, 50, 'dummy', 'retail', '2016-11-22 03:18:14', 1),
(165, 44, 'RYWQQ-D', 0, 10, 49, 'dummy', 'wholesale', '2016-11-22 03:18:14', 1),
(166, 18, 'dfg', 0, 10, 300, 'original', 'retail', '2016-12-18 23:34:04', 1),
(167, 18, 'dfg', 0, 10, 250, 'original', 'wholesale', '2016-12-18 23:34:04', 1),
(168, 13, 'sasd', 0, 10, 250, 'original', 'retail', '2017-01-09 04:02:02', 1),
(169, 13, 'sasd', 0, 10, 240, 'original', 'wholesale', '2017-01-09 04:02:02', 1),
(170, 16, 'sdf', 0, 10, 200, 'original', 'retail', '2017-02-02 03:27:35', 1),
(171, 16, 'sdf', 0, 10, 100, 'original', 'wholesale', '2017-02-02 03:27:35', 1),
(172, 45, 'SKU2700', 0, 10, 100, 'original', 'retail', '2017-02-07 23:11:35', 1),
(173, 45, 'SKU2700', 10, 20, 90, 'original', 'retail', '2017-02-07 23:11:35', 1),
(174, 45, 'SKU2700', 0, 10, 90, 'original', 'wholesale', '2017-02-07 23:11:35', 1),
(175, 45, 'SKU2700', 10, 20, 80, 'original', 'wholesale', '2017-02-07 23:11:35', 1),
(176, 46, 'DSKU2700', 0, 10, 90, 'dummy', 'retail', '2017-02-07 23:11:35', 1),
(177, 46, 'DSKU2700', 10, 20, 80, 'dummy', 'retail', '2017-02-07 23:11:35', 1),
(178, 46, 'DSKU2700', 0, 10, 80, 'dummy', 'wholesale', '2017-02-07 23:11:35', 1),
(179, 46, 'DSKU2700', 0, 20, 70, 'dummy', 'wholesale', '2017-02-07 23:11:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/benvin-last', 'yes'),
(2, 'home', 'http://localhost/benvin-last', 'yes'),
(3, 'blogname', 'SRC - Saravana Rice', 'yes'),
(4, 'blogdescription', 'SRC Stock Management', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'src@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:37:"user-role-editor/user-role-editor.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'src', 'yes'),
(41, 'stylesheet', 'src', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'wp_user_roles', 'a:15:{s:1:"_";a:2:{s:4:"name";s:2:"  ";s:12:"capabilities";a:2:{s:8:"lot_list";b:1;s:10:"stock_list";b:1;}}s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:89:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"ure_edit_roles";b:1;s:16:"ure_create_roles";b:1;s:16:"ure_delete_roles";b:1;s:23:"ure_create_capabilities";b:1;s:23:"ure_delete_capabilities";b:1;s:18:"ure_manage_options";b:1;s:15:"ure_reset_roles";b:1;s:9:"dashboard";b:1;s:9:"customers";b:1;s:8:"lot_list";b:1;s:10:"stock_list";b:1;s:14:"purchase_sales";b:1;s:10:"petty_cash";b:1;s:11:"income_list";b:1;s:5:"cap_1";b:1;s:5:"cap_2";b:1;s:5:"cap_3";b:1;s:16:"add_new_employee";b:1;s:13:"employee_list";b:1;s:15:"attendance_list";b:1;s:11:"salary_list";b:1;s:12:"add_new_user";b:1;s:9:"user_list";b:1;s:15:"sms_to_customer";b:1;s:11:"sms_to_user";b:1;s:7:"reports";b:1;s:8:"settings";b:1;s:6:"seegan";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:10:"new_seegan";a:2:{s:4:"name";s:10:"New Seegan";s:12:"capabilities";a:8:{s:7:"reports";b:1;s:11:"salary_list";b:1;s:8:"settings";b:1;s:11:"sms_to_user";b:1;s:10:"stock_list";b:1;s:15:"sms_to_customer";b:1;s:15:"attendance_list";b:1;s:9:"user_list";b:1;}}s:9:"ranga_raj";a:2:{s:4:"name";s:9:"Ranga Raj";s:12:"capabilities";a:1:{s:12:"add_new_user";b:1;}}s:9:"role_test";a:2:{s:4:"name";s:9:"Role Test";s:12:"capabilities";a:3:{s:14:"purchase_sales";b:1;s:10:"petty_cash";b:1;s:11:"income_list";b:1;}}s:10:"role_tests";a:2:{s:4:"name";s:10:"Role Tests";s:12:"capabilities";a:5:{s:8:"lot_list";b:1;s:16:"add_new_employee";b:1;s:13:"employee_list";b:1;s:15:"attendance_list";b:1;s:11:"salary_list";b:1;}}s:5:"sales";a:2:{s:4:"name";s:15:"Sales Executive";s:12:"capabilities";a:6:{s:16:"add_new_employee";b:1;s:13:"employee_list";b:1;s:4:"read";b:1;s:14:"purchase_sales";b:1;s:10:"petty_cash";b:1;s:11:"income_list";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:5:"vivek";a:2:{s:4:"name";s:5:"Vivek";s:12:"capabilities";a:4:{s:9:"dashboard";b:1;s:9:"customers";b:1;s:8:"lot_list";b:1;s:10:"stock_list";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"employee";a:2:{s:4:"name";s:8:"Employee";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:10:"hr_manager";a:2:{s:4:"name";s:10:"HR Manager";s:12:"capabilities";a:3:{s:16:"add_new_employee";b:1;s:13:"employee_list";b:1;s:4:"read";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:4:{i:1504586778;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1504605919;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1504605932;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(123, 'recently_activated', 'a:0:{}', 'yes'),
(129, 'user_role_editor', 'a:1:{s:11:"ure_version";s:6:"4.27.1";}', 'yes'),
(130, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:68:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"ure_edit_roles";b:1;s:16:"ure_create_roles";b:1;s:16:"ure_delete_roles";b:1;s:23:"ure_create_capabilities";b:1;s:23:"ure_delete_capabilities";b:1;s:18:"ure_manage_options";b:1;s:15:"ure_reset_roles";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no'),
(131, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(152, '_transient_twentysixteen_categories', '1', 'yes'),
(179, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1471843453;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(180, 'current_theme', 'SRC', 'yes'),
(181, 'theme_mods_src', 'a:1:{i:0;b:0;}', 'yes'),
(182, 'theme_switched', '', 'yes'),
(244, 'theme_mods_twentyfifteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1481191851;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(373, 'ure_role_additional_options_values', 'a:2:{s:9:"ranga_raj";a:0:{}s:10:"new_seegan";a:0:{}}', 'yes'),
(441, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:13:"src@gmail.com";s:7:"version";s:5:"4.5.7";s:9:"timestamp";i:1489668328;}', 'yes'),
(1488, 'WPLANG', '', 'yes'),
(1595, 'qnimate_some_text', '', 'yes'),
(2371, 'db_upgraded', '', 'yes'),
(2372, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.8.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.8.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.1";s:7:"version";s:5:"4.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.8.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.8.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.1";s:7:"version";s:5:"4.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}}s:12:"last_checked";i:1504579921;s:15:"version_checked";s:5:"4.7.5";s:12:"translations";a:0:{}}', 'no'),
(2374, '_site_transient_timeout_theme_roots', '1504581723', 'no'),
(2375, '_site_transient_theme_roots', 'a:10:{s:14:"micro-electric";s:7:"/themes";s:6:"piqued";s:7:"/themes";s:8:"poseidon";s:7:"/themes";s:3:"shc";s:7:"/themes";s:3:"src";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";s:3:"xyz";s:7:"/themes";s:9:"xyzforall";s:7:"/themes";}', 'no'),
(2376, '_site_transient_timeout_browser_f9694186c5800b9905943d3f44ede836', '1505184726', 'no'),
(2377, '_site_transient_browser_f9694186c5800b9905943d3f44ede836', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"60.0.3112.113";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(2378, 'can_compress_scripts', '1', 'no'),
(2379, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1504579936;s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":8:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.3.4";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.3.4.zip";s:6:"tested";s:5:"4.8.1";s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:3:{s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:35:"my-wp-translate/my-wp-translate.php";O:8:"stdClass":6:{s:2:"id";s:29:"w.org/plugins/my-wp-translate";s:4:"slug";s:15:"my-wp-translate";s:6:"plugin";s:35:"my-wp-translate/my-wp-translate.php";s:11:"new_version";s:5:"1.0.3";s:3:"url";s:46:"https://wordpress.org/plugins/my-wp-translate/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/my-wp-translate.1.0.3.zip";}s:9:"og/og.php";O:8:"stdClass":6:{s:2:"id";s:16:"w.org/plugins/og";s:4:"slug";s:2:"og";s:6:"plugin";s:9:"og/og.php";s:11:"new_version";s:5:"2.4.5";s:3:"url";s:33:"https://wordpress.org/plugins/og/";s:7:"package";s:51:"https://downloads.wordpress.org/plugin/og.2.4.5.zip";}}}', 'no'),
(2380, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1504579940;s:7:"checked";a:10:{s:14:"micro-electric";s:5:"1.0.1";s:6:"piqued";s:5:"1.0.0";s:8:"poseidon";s:3:"1.3";s:3:"shc";s:0:"";s:3:"src";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.7";s:15:"twentyseventeen";s:3:"1.2";s:13:"twentysixteen";s:3:"1.3";s:3:"xyz";s:0:"";s:9:"xyzforall";s:0:"";}s:8:"response";a:3:{s:8:"poseidon";a:4:{s:5:"theme";s:8:"poseidon";s:11:"new_version";s:5:"1.4.1";s:3:"url";s:38:"https://wordpress.org/themes/poseidon/";s:7:"package";s:56:"https://downloads.wordpress.org/theme/poseidon.1.4.1.zip";}s:13:"twentyfifteen";a:4:{s:5:"theme";s:13:"twentyfifteen";s:11:"new_version";s:3:"1.8";s:3:"url";s:43:"https://wordpress.org/themes/twentyfifteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentyfifteen.1.8.zip";}s:15:"twentyseventeen";a:4:{s:5:"theme";s:15:"twentyseventeen";s:11:"new_version";s:3:"1.3";s:3:"url";s:45:"https://wordpress.org/themes/twentyseventeen/";s:7:"package";s:61:"https://downloads.wordpress.org/theme/twentyseventeen.1.3.zip";}}s:12:"translations";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_payment_history`
--

CREATE TABLE `wp_payment_history` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `payment_paid` decimal(9,2) NOT NULL,
  `update_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_payment_history`
--

INSERT INTO `wp_payment_history` (`id`, `sale_id`, `payment_paid`, `update_at`, `active`) VALUES
(1, 54, '1440.00', '2017-01-25 14:53:21', 0),
(2, 54, '1440.00', '2017-01-25 14:53:47', 0),
(3, 54, '1440.00', '2017-01-25 14:57:06', 0),
(4, 54, '1983.00', '2017-01-25 14:57:39', 0),
(5, 54, '2553.00', '2017-01-25 18:01:46', 0),
(6, 54, '3009.00', '2017-01-25 18:11:02', 0),
(7, 54, '3009.00', '2017-01-25 18:12:01', 0),
(8, 54, '3009.00', '2017-01-26 17:56:35', 0),
(9, 54, '3009.00', '2017-01-26 17:57:02', 0),
(10, 54, '3664.00', '2017-01-26 17:57:18', 1),
(11, 56, '1634.00', '2017-01-27 10:08:48', 0),
(12, 56, '1634.00', '2017-01-27 10:09:00', 0),
(13, 56, '1634.00', '2017-01-27 10:21:02', 0),
(14, 56, '1634.00', '2017-01-27 10:21:12', 0),
(15, 56, '1634.00', '2017-01-27 10:26:56', 0),
(16, 56, '1634.00', '2017-01-27 10:59:31', 0),
(17, 56, '1634.00', '2017-01-27 11:01:55', 0),
(18, 56, '1634.00', '2017-01-27 11:04:25', 0),
(19, 56, '3947.00', '2017-01-27 11:46:23', 0),
(20, 56, '3947.00', '2017-01-27 12:04:32', 1),
(21, 55, '0.00', '2017-01-27 16:55:13', 0),
(22, 57, '2000.00', '2017-02-02 17:36:11', 1),
(23, 55, '1200.00', '2017-02-03 10:22:51', 0),
(24, 55, '1200.00', '2017-02-03 10:24:16', 0),
(25, 55, '1200.00', '2017-02-03 12:57:27', 0),
(26, 55, '1200.00', '2017-02-03 12:57:32', 1),
(27, 58, '3000.00', '2017-02-03 15:49:39', 1),
(28, 36, '5850.00', '2017-02-03 16:07:17', 1),
(29, 60, '1200.00', '2017-02-08 10:30:37', 0),
(30, 60, '880.00', '2017-02-08 10:33:21', 1),
(31, 62, '0.00', '2017-03-02 11:41:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_payment_installment`
--

CREATE TABLE `wp_payment_installment` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `payment_history_id` int(11) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `initial_total` decimal(9,2) NOT NULL,
  `fee_total` decimal(9,2) NOT NULL,
  `sub_total` decimal(9,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_payment_installment`
--

INSERT INTO `wp_payment_installment` (`id`, `sale_id`, `payment_history_id`, `payment_method`, `description`, `initial_total`, `fee_total`, `sub_total`, `payment_date`, `active`) VALUES
(1, 51, 0, 'cash_payment', '', '234.00', '0.00', '234.00', '2017-01-23 15:00:49', 0),
(2, 51, 0, 'cash_payment', '', '754.00', '0.00', '754.00', '2017-01-23 15:00:49', 0),
(3, 51, 0, 'card_payment', 'ggff', '543.00', '8.15', '551.15', '2017-01-23 15:00:50', 0),
(4, 51, 0, 'card_payment', 'fgf', '653.00', '9.80', '662.80', '2017-01-23 15:00:50', 0),
(5, 51, 0, 'neft_content', 'fgfdg', '5654.00', '0.00', '5654.00', '2017-01-23 15:00:50', 0),
(6, 51, 0, 'cheque_content', '', '342.00', '0.00', '342.00', '2017-01-23 15:00:50', 0),
(7, 51, 0, 'cash_payment', '', '234.00', '0.00', '234.00', '2017-01-23 15:04:52', 0),
(8, 51, 0, 'cash_payment', '', '754.00', '0.00', '754.00', '2017-01-23 15:04:52', 0),
(9, 51, 0, 'card_payment', 'ggff', '543.00', '8.15', '551.15', '2017-01-23 15:04:52', 0),
(10, 51, 0, 'card_payment', 'fgf', '653.00', '9.80', '662.80', '2017-01-23 15:04:53', 0),
(11, 51, 0, 'neft_content', 'fgfdg', '5654.00', '0.00', '5654.00', '2017-01-23 15:04:53', 0),
(12, 51, 0, 'cheque_content', '', '342.00', '0.00', '342.00', '2017-01-23 15:04:53', 0),
(13, 51, 0, 'cash_payment', '', '234.00', '0.00', '234.00', '2017-01-23 15:22:40', 1),
(14, 51, 0, 'cash_payment', '', '754.00', '0.00', '754.00', '2017-01-23 15:22:40', 1),
(15, 51, 0, 'card_payment', 'ggff', '543.00', '8.15', '551.15', '2017-01-23 15:22:40', 1),
(16, 51, 0, 'card_payment', 'fgf', '653.00', '9.80', '662.80', '2017-01-23 15:22:40', 1),
(17, 51, 0, 'neft_content', 'fgfdg', '5654.00', '0.00', '5654.00', '2017-01-23 15:22:40', 1),
(18, 51, 0, 'cheque_content', '', '342.00', '0.00', '342.00', '2017-01-23 15:22:40', 1),
(19, 52, 0, 'cash_payment', '', '324.00', '0.00', '324.00', '2017-01-25 12:17:01', 1),
(20, 52, 0, 'cash_payment', '', '543.00', '0.00', '543.00', '2017-01-25 12:17:01', 1),
(21, 52, 0, 'card_payment', '', '654.00', '9.81', '663.81', '2017-01-25 12:17:01', 1),
(22, 52, 0, 'card_payment', '', '213.00', '3.20', '216.20', '2017-01-25 12:17:01', 1),
(23, 53, 0, 'card_payment', '', '432.00', '6.48', '438.48', '2017-01-25 12:19:14', 0),
(24, 53, 0, 'card_payment', '', '432.00', '6.48', '438.48', '2017-01-25 12:19:41', 0),
(25, 53, 0, 'card_payment', '', '432.00', '6.48', '438.48', '2017-01-25 12:20:00', 1),
(26, 54, 3, 'cash_payment', '', '675.00', '0.00', '675.00', '2017-01-25 14:57:06', 0),
(27, 54, 3, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-25 14:57:06', 0),
(28, 54, 4, 'cash_payment', '', '675.00', '0.00', '675.00', '2017-01-25 14:57:39', 0),
(29, 54, 4, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-25 14:57:39', 0),
(30, 54, 4, 'card_payment', '', '543.00', '8.15', '551.15', '2017-01-25 14:57:39', 0),
(31, 54, 5, 'cash_payment', '', '675.00', '0.00', '675.00', '2017-01-25 18:01:46', 0),
(32, 54, 5, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-25 18:01:46', 0),
(33, 54, 5, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-25 18:01:46', 0),
(34, 54, 5, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-25 18:01:46', 0),
(35, 54, 6, 'cash_payment', '', '675.00', '0.00', '675.00', '2017-01-25 18:11:02', 0),
(36, 54, 6, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-25 18:11:02', 0),
(37, 54, 6, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-25 18:11:02', 0),
(38, 54, 6, 'neft_content', '', '456.00', '0.00', '456.00', '2017-01-25 18:11:02', 0),
(39, 54, 6, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-25 18:11:02', 0),
(40, 54, 7, 'cash_payment', '', '675.00', '0.00', '675.00', '2017-01-25 18:12:01', 0),
(41, 54, 7, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-25 18:12:01', 0),
(42, 54, 7, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-25 18:12:01', 0),
(43, 54, 7, 'neft_content', '', '456.00', '0.00', '456.00', '2017-01-25 18:12:01', 0),
(44, 54, 7, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-25 18:12:01', 0),
(45, 54, 8, 'cash_payment', 'rtydrg', '675.00', '0.00', '675.00', '2017-01-26 17:56:36', 0),
(46, 54, 8, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-26 17:56:36', 0),
(47, 54, 8, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-26 17:56:36', 0),
(48, 54, 8, 'neft_content', '', '456.00', '0.00', '456.00', '2017-01-26 17:56:36', 0),
(49, 54, 8, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-26 17:56:36', 0),
(50, 54, 9, 'cash_payment', 'rtydrg', '675.00', '0.00', '675.00', '2017-01-26 17:57:02', 0),
(51, 54, 9, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-26 17:57:02', 0),
(52, 54, 9, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-26 17:57:02', 0),
(53, 54, 9, 'neft_content', '', '456.00', '0.00', '456.00', '2017-01-26 17:57:02', 0),
(54, 54, 9, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-26 17:57:02', 0),
(55, 54, 10, 'cash_payment', 'rtydrg', '675.00', '0.00', '675.00', '2017-01-26 17:57:18', 1),
(56, 54, 10, 'cash_payment', '2nd', '655.00', '0.00', '655.00', '2017-01-26 17:57:18', 1),
(57, 54, 10, 'card_payment', '', '765.00', '11.48', '776.48', '2017-01-26 17:57:19', 1),
(58, 54, 10, 'card_payment', '', '990.00', '14.85', '1004.85', '2017-01-26 17:57:19', 1),
(59, 54, 10, 'neft_content', '', '456.00', '0.00', '456.00', '2017-01-26 17:57:19', 1),
(60, 54, 10, 'cheque_content', '', '123.00', '0.00', '123.00', '2017-01-26 17:57:19', 1),
(61, 56, 11, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:08:48', 0),
(62, 56, 11, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:08:48', 0),
(63, 56, 11, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:08:48', 0),
(64, 56, 11, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:08:48', 0),
(65, 56, 12, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:09:00', 0),
(66, 56, 12, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:09:00', 0),
(67, 56, 12, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:09:00', 0),
(68, 56, 12, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:09:00', 0),
(69, 56, 13, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:21:02', 0),
(70, 56, 13, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:21:02', 0),
(71, 56, 13, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:21:03', 0),
(72, 56, 13, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:21:03', 0),
(73, 56, 14, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:21:12', 0),
(74, 56, 14, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:21:12', 0),
(75, 56, 14, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:21:12', 0),
(76, 56, 14, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:21:12', 0),
(77, 56, 15, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:26:56', 0),
(78, 56, 15, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:26:56', 0),
(79, 56, 15, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:26:56', 0),
(80, 56, 15, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:26:56', 0),
(81, 56, 16, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 10:59:31', 0),
(82, 56, 16, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 10:59:31', 0),
(83, 56, 16, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 10:59:32', 0),
(84, 56, 16, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 10:59:32', 0),
(85, 56, 17, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 11:01:55', 0),
(86, 56, 17, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 11:01:55', 0),
(87, 56, 17, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 11:01:55', 0),
(88, 56, 17, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 11:01:55', 0),
(89, 56, 18, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 11:04:25', 0),
(90, 56, 18, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 11:04:25', 0),
(91, 56, 18, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 11:04:25', 0),
(92, 56, 18, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 11:04:25', 0),
(93, 56, 19, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 11:46:23', 0),
(94, 56, 19, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 11:46:24', 0),
(95, 56, 19, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 11:46:24', 0),
(96, 56, 19, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 11:46:24', 0),
(97, 56, 19, 'card_payment', 'QWAS', '2313.00', '34.70', '2347.70', '2017-01-27 11:46:24', 0),
(98, 56, 20, 'cash_payment', 'qwerty', '121.00', '0.00', '121.00', '2017-01-27 12:04:33', 1),
(99, 56, 20, 'cash_payment', 'asdfghj', '324.00', '0.00', '324.00', '2017-01-27 12:04:33', 1),
(100, 56, 20, 'card_payment', 'qscgu', '532.00', '7.98', '539.98', '2017-01-27 12:04:33', 1),
(101, 56, 20, 'card_payment', 'azsxdc', '657.00', '9.86', '666.86', '2017-01-27 12:04:33', 1),
(102, 56, 20, 'card_payment', 'QWAS', '2313.00', '34.70', '2347.70', '2017-01-27 12:04:33', 1),
(103, 57, 22, 'cash_payment', 'cash payment 1', '2000.00', '0.00', '2000.00', '2017-02-02 17:36:11', 1),
(104, 55, 23, 'card_payment', 'ASD', '1200.00', '18.00', '1218.00', '2017-02-03 10:22:51', 0),
(105, 55, 24, 'card_payment', 'ASD', '1200.00', '18.00', '1218.00', '2017-02-03 10:24:16', 0),
(106, 55, 25, 'card_payment', 'ASD', '1200.00', '18.00', '1218.00', '2017-02-03 12:57:27', 0),
(107, 55, 26, 'card_payment', 'ASD', '1200.00', '18.00', '1218.00', '2017-02-03 12:57:32', 1),
(108, 58, 27, 'cash_payment', 'cash payment 1', '2000.00', '0.00', '2000.00', '2017-02-03 15:49:39', 1),
(109, 58, 27, 'card_payment', 'card', '1000.00', '15.00', '1015.00', '2017-02-03 15:49:39', 1),
(110, 36, 28, 'card_payment', '', '5850.00', '87.75', '5937.75', '2017-02-03 16:07:17', 1),
(111, 60, 29, 'cash_payment', '9/02/2017', '1000.00', '0.00', '1000.00', '2017-02-08 10:30:37', 0),
(112, 60, 29, 'card_payment', '9/02/2017', '200.00', '3.00', '203.00', '2017-02-08 10:30:37', 0),
(113, 60, 30, 'cash_payment', '9/02/2017', '880.00', '0.00', '880.00', '2017-02-08 10:33:21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_petty_cash`
--

CREATE TABLE `wp_petty_cash` (
  `id` int(11) NOT NULL,
  `cash_date` datetime NOT NULL,
  `cash_amount` decimal(9,2) NOT NULL,
  `cash_description` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_petty_cash`
--

INSERT INTO `wp_petty_cash` (`id`, `cash_date`, `cash_amount`, `cash_description`, `created_at`, `modified_at`, `active`) VALUES
(1, '2016-11-18 00:00:00', '16.00', 'rtetert', '2016-11-08 12:58:15', '2016-11-08 15:52:45', 1),
(2, '2016-11-09 00:00:00', '19.00', 'gfdgdfgdfg', '2016-11-08 13:06:36', '2016-11-15 17:36:07', 0),
(3, '2016-11-10 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:10', '0000-00-00 00:00:00', 1),
(4, '2016-11-04 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:18', '0000-00-00 00:00:00', 1),
(5, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:27', '0000-00-00 00:00:00', 1),
(6, '2016-11-09 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:35', '0000-00-00 00:00:00', 1),
(7, '2016-11-18 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:43', '0000-00-00 00:00:00', 1),
(8, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:46:52', '0000-00-00 00:00:00', 1),
(9, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:00', '0000-00-00 00:00:00', 1),
(10, '2016-11-12 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:08', '0000-00-00 00:00:00', 1),
(11, '2016-11-09 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:16', '0000-00-00 00:00:00', 1),
(12, '2016-11-14 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:26', '0000-00-00 00:00:00', 1),
(13, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:41', '0000-00-00 00:00:00', 1),
(14, '2016-11-10 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:49', '0000-00-00 00:00:00', 1),
(15, '2016-11-09 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:47:57', '0000-00-00 00:00:00', 1),
(16, '2016-11-09 00:00:00', '200.00', 'ksadfkljd', '2016-11-10 10:48:12', '2016-11-11 17:13:00', 1),
(17, '2016-11-09 00:00:00', '100.00', 'testname', '2016-11-10 10:48:20', '2016-11-11 17:13:11', 1),
(18, '2016-11-12 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:48:28', '0000-00-00 00:00:00', 1),
(19, '2016-11-09 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:48:37', '0000-00-00 00:00:00', 1),
(20, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:48:44', '0000-00-00 00:00:00', 1),
(21, '2016-11-11 00:00:00', '0.00', 'ksadfkljd', '2016-11-10 10:49:01', '0000-00-00 00:00:00', 1),
(22, '2016-11-16 00:00:00', '15000.00', 'lhsdkfn', '2016-11-16 11:44:24', '0000-00-00 00:00:00', 1),
(23, '2016-11-15 00:00:00', '30000.00', 'gdfgsdfg', '2016-11-16 11:44:41', '0000-00-00 00:00:00', 1),
(24, '2016-11-21 00:00:00', '100.00', 'dfdf', '2016-11-21 10:07:24', '0000-00-00 00:00:00', 1),
(25, '2017-01-25 00:00:00', '2314.00', 'ghyyu', '2017-01-25 18:13:18', '0000-00-00 00:00:00', 1),
(26, '2017-02-03 00:00:00', '1000.00', 'dfgfg', '2017-02-03 16:19:29', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(3, 12, '_wp_attached_file', '2016/10/profile-1.jpg'),
(4, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:500;s:4:"file";s:21:"2016/10/profile-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"profile-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"profile-1-300x208.jpg";s:5:"width";i:300;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(5, 14, '_edit_lock', '1478238327:1'),
(6, 14, '_edit_last', '1'),
(7, 14, '_wp_page_template', 'invoice-template.php'),
(8, 16, '_edit_last', '1'),
(9, 16, '_wp_page_template', 'default'),
(10, 16, '_edit_lock', '1478238343:1'),
(11, 18, '_edit_lock', '1478259372:1'),
(12, 18, '_edit_last', '1'),
(13, 18, '_wp_page_template', 'invoice-template.php');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-08-20 10:05:18', '2016-08-20 10:05:18', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2016-08-20 10:05:18', '2016-08-20 10:05:18', '', 0, 'http://192.168.0.150/src/?p=1', 0, 'post', '', 1),
(2, 1, '2016-08-20 10:05:18', '2016-08-20 10:05:18', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://192.168.0.150/src/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2016-08-20 10:05:18', '2016-08-20 10:05:18', '', 0, 'http://192.168.0.150/src/?page_id=2', 0, 'page', '', 0),
(12, 1, '2016-10-04 11:09:33', '2016-10-04 11:09:33', '', 'profile-1', '', 'inherit', 'open', 'closed', '', 'profile-1', '', '', '2016-10-04 11:09:33', '2016-10-04 11:09:33', '', 0, 'http://localhost/src/wp-content/uploads/2016/10/profile-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2016-11-04 05:41:32', '2016-11-04 05:41:32', '', 'Invoice', '', 'publish', 'closed', 'closed', '', 'invoice', '', '', '2016-11-04 05:41:38', '2016-11-04 05:41:38', '', 2, 'http://192.168.0.150/src/?page_id=14', 0, 'page', '', 0),
(15, 1, '2016-11-04 05:41:32', '2016-11-04 05:41:32', '', 'Invoice', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-11-04 05:41:32', '2016-11-04 05:41:32', '', 14, 'http://192.168.0.150/src/2016/11/04/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-11-04 05:47:57', '2016-11-04 05:47:57', '', 'google', '', 'publish', 'closed', 'closed', '', 'google', '', '', '2016-11-04 05:47:57', '2016-11-04 05:47:57', '', 0, 'http://192.168.0.150/src/?page_id=16', 0, 'page', '', 0),
(17, 1, '2016-11-04 05:47:57', '2016-11-04 05:47:57', '', 'google', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-11-04 05:47:57', '2016-11-04 05:47:57', '', 16, 'http://192.168.0.150/src/2016/11/04/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-11-04 05:48:15', '2016-11-04 05:48:15', '', 'Invoice', '', 'publish', 'closed', 'closed', '', 'invoice', '', '', '2016-11-04 05:49:59', '2016-11-04 05:49:59', '', 0, 'http://192.168.0.150/src/?page_id=18', 0, 'page', '', 0),
(19, 1, '2016-11-04 05:48:15', '2016-11-04 05:48:15', '', 'Invoice', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-11-04 05:48:15', '2016-11-04 05:48:15', '', 18, 'http://192.168.0.150/src/2016/11/04/18-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_sale`
--

CREATE TABLE `wp_sale` (
  `id` int(11) NOT NULL,
  `invoice_id` varchar(255) NOT NULL,
  `customer_id` bigint(11) NOT NULL,
  `order_shop` varchar(255) NOT NULL,
  `customer_type` varchar(255) NOT NULL,
  `sale_value` decimal(9,2) NOT NULL,
  `sale_dicount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `sale_discount_price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `sale_tax` decimal(9,2) NOT NULL DEFAULT '0.00',
  `sale_total` decimal(9,2) NOT NULL,
  `invoice_date` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `invoice_status` varchar(255) NOT NULL DEFAULT 'pending',
  `made_by` int(11) NOT NULL DEFAULT '0',
  `payment_done` int(2) NOT NULL DEFAULT '0',
  `last_update_by` int(11) NOT NULL DEFAULT '0',
  `active` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_sale`
--

INSERT INTO `wp_sale` (`id`, `invoice_id`, `customer_id`, `order_shop`, `customer_type`, `sale_value`, `sale_dicount`, `sale_discount_price`, `sale_tax`, `sale_total`, `invoice_date`, `created_at`, `modified_at`, `invoice_status`, `made_by`, `payment_done`, `last_update_by`, `active`) VALUES
(1, 'INV1', 1, 'rice_mandy', 'wholesale', '7500.00', '0.00', '0.00', '0.00', '7500.00', '2016-10-27 00:00:00', '2016-10-28 15:36:06', '2017-01-04 18:23:46', 'pending', 0, 0, 1, 1),
(2, 'INV2', 2, 'rice_center', 'wholesale', '7900.00', '0.00', '100.00', '0.00', '7800.00', '2016-10-28 00:00:00', '2016-10-28 15:37:50', '2016-11-21 14:02:42', 'delivered', 0, 0, 0, 1),
(3, 'INV3', 4, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-03 00:00:00', '2016-11-03 12:41:43', '2016-11-03 12:41:43', 'pending', 0, 0, 0, 1),
(4, 'INV4', 2, 'rice_center', 'wholesale', '700.00', '0.00', '0.00', '0.00', '700.00', '2016-11-03 00:00:00', '2016-11-03 12:43:32', '2016-11-04 14:28:40', 'pending', 0, 0, 0, 1),
(5, 'INV5', 2, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-04 00:00:00', '2016-11-04 12:57:04', '2016-11-21 14:07:55', 'process', 0, 0, 0, 1),
(6, 'INV6', 4, 'rice_center', 'retail', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-04 00:00:00', '2016-11-04 13:22:50', '2016-11-04 15:45:22', 'pending', 0, 0, 0, 1),
(7, 'INV7', 2, 'rice_center', 'wholesale', '5000.00', '0.00', '0.00', '0.00', '5000.00', '2016-11-04 00:00:00', '2016-11-04 13:56:50', '2016-11-04 16:57:23', 'pending', 0, 0, 0, 1),
(8, 'INV8', 4, 'rice_center', 'retail', '500.00', '0.00', '300.00', '0.00', '200.00', '2016-11-04 00:00:00', '2016-11-04 13:58:31', '2016-11-04 16:28:57', 'pending', 0, 0, 0, 1),
(9, 'INV9', 2, 'rice_center', 'wholesale', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-04 00:00:00', '2016-11-04 14:03:29', '2016-11-04 14:03:31', 'pending', 0, 0, 0, 1),
(10, 'INV10', 26, 'rice_center', 'retail', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-04 00:00:00', '2016-11-04 14:05:53', '2016-11-04 14:06:00', 'pending', 0, 0, 0, 1),
(11, 'INV11', 4, 'rice_center', 'retail', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-04 00:00:00', '2016-11-04 14:09:41', '2016-11-04 14:09:54', 'pending', 0, 0, 0, 1),
(12, 'INV12', 4, 'rice_mandy', 'retail', '750.00', '0.00', '0.00', '0.00', '750.00', '2016-11-04 00:00:00', '2016-11-04 15:38:27', '2016-11-04 15:38:47', 'pending', 0, 0, 0, 1),
(13, 'INV13', 3, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-10 00:00:00', '2016-11-10 10:29:40', '2016-11-10 10:29:40', 'pending', 0, 0, 0, 1),
(14, 'INV14', 1, 'rice_center', 'retail', '2500.00', '0.00', '0.00', '0.00', '2500.00', '2016-11-10 00:00:00', '2016-11-10 10:36:16', '2016-11-10 10:36:47', 'pending', 0, 0, 0, 1),
(15, 'INV15', 2, 'rice_center', 'wholesale', '1250.00', '0.00', '0.00', '0.00', '1250.00', '2016-11-10 00:00:00', '2016-11-10 10:37:41', '2016-11-10 10:37:58', 'pending', 0, 0, 0, 1),
(16, 'INV16', 14, 'rice_center', 'wholesale', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-10 00:00:00', '2016-11-10 10:38:23', '2016-11-10 10:38:47', 'pending', 0, 0, 0, 1),
(17, 'INV17', 18, 'rice_center', 'retail', '2500.00', '0.00', '0.00', '0.00', '2500.00', '2016-11-10 00:00:00', '2016-11-10 10:39:28', '2016-11-10 10:39:31', 'pending', 0, 0, 0, 1),
(18, 'INV18', 33, 'rice_center', 'retail', '1000.00', '0.00', '0.00', '0.00', '1000.00', '2016-11-10 00:00:00', '2016-11-10 10:39:38', '2016-11-10 10:39:46', 'pending', 0, 0, 0, 1),
(19, 'INV19', 33, 'rice_center', 'retail', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-10 00:00:00', '2016-11-10 10:40:06', '2016-11-10 10:40:14', 'pending', 0, 0, 0, 1),
(20, 'INV20', 4, 'rice_center', 'retail', '1250.00', '0.00', '0.00', '0.00', '1250.00', '2016-11-10 00:00:00', '2016-11-10 10:40:50', '2016-11-10 10:40:53', 'pending', 0, 0, 0, 1),
(21, 'INV21', 20, 'rice_center', 'retail', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-10 00:00:00', '2016-11-10 10:41:14', '2016-11-10 10:41:33', 'pending', 0, 0, 0, 1),
(22, 'INV22', 32, 'rice_center', 'retail', '4500.00', '0.00', '0.00', '0.00', '4500.00', '2016-11-10 00:00:00', '2016-11-10 10:42:16', '2016-11-10 10:42:41', 'pending', 0, 0, 0, 1),
(23, 'INV23', 1, 'rice_center', 'retail', '5850.00', '0.00', '0.00', '0.00', '5850.00', '2016-11-14 00:00:00', '2016-11-14 16:37:50', '2016-11-21 13:03:19', 'process', 1, 0, 1, 1),
(24, 'INV24', 1, 'rice_center', 'retail', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-15 00:00:00', '2016-11-15 15:18:28', '2016-11-21 13:15:06', 'process', 1, 0, 1, 1),
(25, 'INV25', 33, 'rice_center', 'retail', '9225.00', '0.00', '0.00', '0.00', '9225.00', '2016-11-16 00:00:00', '2016-11-16 11:43:03', '2016-11-21 14:00:23', 'pending', 1, 0, 1, 1),
(26, 'INV26', 1, 'rice_center', 'retail', '500.00', '0.00', '0.00', '0.00', '500.00', '2016-11-12 00:00:00', '2016-11-16 12:46:27', '2016-11-21 14:01:33', 'delivered', 1, 0, 1, 1),
(27, 'INV27', 1, 'rice_center', 'retail', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-18 00:00:00', '2016-11-18 19:53:19', '2016-11-21 13:18:58', 'delivered', 1, 0, 1, 1),
(28, 'INV28', 1, 'rice_center', 'retail', '1250.00', '0.00', '0.00', '0.00', '1250.00', '2016-11-18 00:00:00', '2016-11-18 20:54:23', '2016-11-21 14:02:28', 'process', 1, 0, 1, 1),
(29, 'INV29', 2, 'rice_center', 'wholesale', '1500.00', '0.00', '0.00', '0.00', '1500.00', '2016-11-19 00:00:00', '2016-11-19 15:26:12', '2016-11-19 15:26:21', 'pending', 1, 0, 1, 1),
(30, 'INV30', 1, 'rice_center', 'retail', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-11-19 00:00:00', '2016-11-19 15:45:44', '2016-11-23 14:43:01', 'process', 1, 0, 1, 1),
(31, 'INV31', 2, 'rice_center', 'wholesale', '2250.00', '0.00', '0.00', '0.00', '2250.00', '2016-11-21 00:00:00', '2016-11-21 14:25:04', '2016-11-24 15:05:32', 'process', 1, 0, 1, 1),
(32, 'INV32', 2, 'rice_center', 'wholesale', '3375.00', '0.00', '0.00', '0.00', '3375.00', '2016-11-23 00:00:00', '2016-11-23 11:36:28', '2016-11-23 11:36:33', 'pending', 1, 0, 1, 1),
(33, 'INV33', 2, 'rice_center', 'wholesale', '9750.00', '0.00', '0.00', '0.00', '9750.00', '2016-11-23 00:00:00', '2016-11-23 11:38:19', '2016-11-23 12:16:22', 'pending', 1, 0, 1, 1),
(34, 'INV34', 2, 'rice_center', 'wholesale', '2500.00', '0.00', '0.00', '0.00', '2500.00', '2016-11-24 00:00:00', '2016-11-24 15:09:48', '2016-11-24 17:08:22', 'pending', 1, 0, 1, 1),
(35, 'INV35', 2, 'rice_center', 'wholesale', '0.00', '0.00', '0.00', '0.00', '0.00', '2016-12-10 00:00:00', '2016-12-10 14:08:12', '2016-12-10 14:08:16', 'pending', 1, 0, 1, 1),
(36, 'INV36', 2, 'rice_center', 'retail', '5850.00', '0.00', '0.00', '0.00', '5850.00', '2016-12-19 00:00:00', '2016-12-19 10:23:02', '2017-02-03 16:07:45', 'delivered', 1, 1, 1, 1),
(37, 'INV37', 2, 'rice_center', 'wholesale', '111.25', '0.00', '0.00', '0.00', '111.25', '2017-01-04 00:00:00', '2017-01-04 10:30:29', '2017-01-04 10:30:30', 'pending', 1, 0, 1, 1),
(38, 'INV38', 1, 'rice_center', 'retail', '3000.00', '0.00', '0.00', '0.00', '3000.00', '2017-01-04 00:00:00', '2017-01-04 10:32:03', '2017-01-04 11:49:25', 'pending', 1, 0, 1, 1),
(39, 'INV39', 4, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-04 00:00:00', '2017-01-04 10:32:54', '2017-01-04 10:32:54', 'pending', 1, 0, 0, 1),
(40, 'INV40', 4, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-04 00:00:00', '2017-01-04 10:35:16', '2017-01-04 10:35:16', 'pending', 1, 0, 0, 1),
(41, 'INV41', 5, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-04 00:00:00', '2017-01-04 10:42:37', '2017-01-04 10:42:37', 'pending', 1, 0, 0, 1),
(42, 'INV42', 4, 'rice_center', 'retail', '206.25', '0.00', '0.00', '0.00', '206.25', '2017-01-09 00:00:00', '2017-01-09 15:01:07', '2017-01-09 15:02:55', 'pending', 1, 0, 1, 1),
(43, 'INV43', 2, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 11:57:22', '2017-01-20 11:57:22', 'pending', 1, 0, 0, 1),
(44, 'INV44', 5, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 12:11:22', '2017-01-20 12:11:22', 'pending', 1, 0, 0, 1),
(45, 'INV45', 5, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 12:21:17', '2017-01-20 12:21:17', 'pending', 1, 0, 0, 1),
(46, 'INV46', 1, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 12:31:25', '2017-01-20 12:31:25', 'pending', 1, 0, 0, 1),
(47, 'INV47', 1, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 12:37:22', '2017-01-20 12:37:22', 'pending', 1, 0, 0, 1),
(48, 'INV48', 1, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 17:49:45', '2017-01-20 17:49:45', 'pending', 1, 0, 0, 1),
(49, 'INV49', 1, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-01-20 00:00:00', '2017-01-20 18:02:45', '2017-01-20 18:02:45', 'pending', 1, 0, 0, 1),
(50, 'INV50', 2, 'rice_center', 'retail', '3375.00', '0.00', '0.00', '0.00', '3375.00', '2017-01-21 00:00:00', '2017-01-21 10:49:03', '2017-01-26 10:18:05', 'pending', 1, 0, 1, 1),
(51, 'INV51', 1, 'rice_center', 'retail', '5000.00', '0.00', '100.00', '0.00', '4900.00', '2017-01-23 00:00:00', '2017-01-23 12:32:15', '2017-01-23 15:26:37', 'pending', 1, 0, 1, 1),
(52, 'INV52', 2, 'rice_center', 'wholesale', '3375.00', '0.00', '0.00', '0.00', '3375.00', '2017-01-25 00:00:00', '2017-01-25 12:16:56', '2017-01-25 18:12:45', 'pending', 1, 0, 1, 1),
(53, 'INV53', 4, 'rice_center', 'retail', '1000.00', '0.00', '0.00', '0.00', '1000.00', '2017-01-25 00:00:00', '2017-01-25 12:18:14', '2017-01-25 12:20:00', 'pending', 1, 0, 1, 1),
(54, 'INV54', 6, 'rice_center', 'retail', '16200.00', '0.00', '0.00', '0.00', '16200.00', '2017-01-25 00:00:00', '2017-01-25 14:48:11', '2017-01-26 17:57:01', 'pending', 1, 0, 1, 1),
(55, 'INV55', 6, 'rice_center', 'retail', '1200.00', '0.00', '0.00', '0.00', '1200.00', '2017-01-26 00:00:00', '2017-01-26 16:52:02', '2017-02-03 11:32:52', 'pending', 1, 1, 1, 1),
(56, 'INV56', 1, 'rice_center', 'retail', '6350.00', '0.00', '0.00', '0.00', '6350.00', '2017-01-27 00:00:00', '2017-01-27 10:08:45', '2017-02-03 10:47:56', 'process', 1, 0, 1, 1),
(57, 'INV57', 2, 'rice_center', 'wholesale', '2000.00', '0.00', '0.00', '0.00', '2000.00', '2017-02-02 00:00:00', '2017-02-02 17:36:10', '2017-02-02 17:36:11', 'pending', 1, 0, 1, 1),
(58, 'INV58', 2, 'rice_center', 'wholesale', '4650.00', '0.00', '0.00', '0.00', '4650.00', '2017-02-03 00:00:00', '2017-02-03 15:45:32', '2017-02-03 15:49:39', 'pending', 1, 0, 1, 1),
(59, 'INV59', 2, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-02-07 00:00:00', '2017-02-07 18:33:51', '2017-02-07 18:33:51', 'pending', 1, 0, 0, 1),
(60, 'INV60', 37, 'rice_center', 'retail', '880.00', '0.00', '0.00', '0.00', '880.00', '2017-02-08 00:00:00', '2017-02-08 10:01:04', '2017-02-08 10:33:21', 'delivered', 1, 1, 1, 1),
(61, 'INV61', 3, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-02-21 00:00:00', '2017-02-21 12:54:12', '2017-02-21 12:54:12', 'pending', 1, 0, 0, 1),
(62, 'INV62', 1, 'rice_center', 'retail', '4500.00', '0.00', '0.00', '0.00', '4500.00', '2017-03-02 00:00:00', '2017-03-02 11:41:28', '2017-03-02 11:41:35', 'pending', 1, 0, 1, 1),
(63, 'INV63', 1, 'rice_center', '', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-03-04 00:00:00', '2017-03-04 10:43:12', '2017-03-04 10:43:12', 'pending', 1, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_sale_detail`
--

CREATE TABLE `wp_sale_detail` (
  `id` bigint(20) NOT NULL,
  `sale_id` bigint(11) NOT NULL,
  `lot_id` bigint(11) NOT NULL,
  `lot_parent_id` bigint(11) NOT NULL,
  `sale_type` varchar(200) NOT NULL,
  `sale_weight` decimal(9,2) NOT NULL,
  `unit_price` decimal(9,2) NOT NULL,
  `sale_value` decimal(9,2) NOT NULL,
  `sale_tax` decimal(9,2) NOT NULL DEFAULT '0.00',
  `sale_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bill_type` varchar(255) NOT NULL,
  `bill_from` varchar(255) NOT NULL,
  `lot_type` varchar(255) NOT NULL,
  `item_status` varchar(255) NOT NULL DEFAULT 'open',
  `made_by` int(11) NOT NULL DEFAULT '0',
  `price_orig_hidden` decimal(9,2) NOT NULL DEFAULT '0.00',
  `brand_display` int(2) NOT NULL DEFAULT '1',
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_sale_detail`
--

INSERT INTO `wp_sale_detail` (`id`, `sale_id`, `lot_id`, `lot_parent_id`, `sale_type`, `sale_weight`, `unit_price`, `sale_value`, `sale_tax`, `sale_update`, `bill_type`, `bill_from`, `lot_type`, `item_status`, `made_by`, `price_orig_hidden`, `brand_display`, `active`) VALUES
(4, 2, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2016-11-02 16:57:54', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(12, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:00:20', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(13, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:00:20', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(14, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:00:20', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(15, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:00:42', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(16, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:00:42', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(17, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:00:42', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(18, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:01:06', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(19, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:01:06', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(20, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:01:06', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(21, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:01:23', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(22, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:01:23', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(23, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:01:23', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(24, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2017-01-04 18:23:46', 'duplicate', '', '-', 'return', 1, '0.00', 1, 0),
(25, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:04:12', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(26, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:04:12', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(27, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2016-11-02 15:04:28', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(28, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 15:04:28', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(29, 1, 3, 2, 'wholesale', '400.00', '43.00', '17200.00', '0.00', '2017-01-04 18:23:46', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(30, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 16:40:36', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(31, 1, 7, 7, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-02 16:44:42', 'duplicate', '', '-', 'open', 0, '0.00', 1, 0),
(32, 1, 2, 2, '-', '75.00', '78.00', '5850.00', '0.00', '2016-11-02 16:45:12', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(33, 1, 3, 2, 'wholesale', '75.00', '43.00', '3225.00', '0.00', '2017-01-04 18:23:46', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(34, 1, 2, 2, '-', '75.00', '78.00', '5850.00', '0.00', '2017-01-04 18:23:46', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(35, 2, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2016-11-02 16:57:54', 'original', '', 'dummy', 'open', 0, '0.00', 1, 1),
(36, 2, 2, 2, 'wholesale', '75.00', '38.00', '2850.00', '0.00', '2016-11-02 16:57:54', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(37, 2, 4, 4, 'wholesale', '5.00', '45.00', '225.00', '0.00', '2016-11-02 16:57:54', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(38, 2, 5, 5, 'wholesale', '50.00', '29.00', '1450.00', '0.00', '2016-11-02 16:57:54', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(39, 0, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-03 16:33:59', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(40, 4, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-03 12:43:46', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(41, 4, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-03 12:44:01', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(42, 4, 3, 2, 'wholesale', '75.00', '43.00', '3225.00', '0.00', '2016-11-03 12:44:01', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(43, 4, 2, 2, 'retail', '75.00', '80.00', '6000.00', '0.00', '2016-11-03 12:44:27', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(44, 4, 3, 2, 'wholesale', '75.00', '43.00', '3225.00', '0.00', '2016-11-03 12:44:27', 'original', '', 'dummy', 'return', 0, '0.00', 1, 0),
(45, 4, 2, 2, 'retail', '75.00', '80.00', '6000.00', '0.00', '2016-11-03 12:47:29', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(46, 4, 2, 2, 'retail', '75.00', '80.00', '6000.00', '0.00', '2016-11-03 12:47:47', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(47, 4, 10, 10, 'wholesale', '15.00', '19.30', '289.50', '0.00', '2016-11-03 12:47:47', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(48, 4, 10, 10, 'wholesale', '15.00', '19.30', '289.50', '0.00', '2016-11-04 14:28:07', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(49, 8, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-04 14:31:29', 'original', '', 'real', 'return', 0, '0.00', 1, 0),
(50, 11, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:09:54', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(51, 4, 10, 10, 'retail', '15.00', '20.00', '300.00', '0.00', '2016-11-04 14:28:40', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(52, 4, 10, 10, 'retail', '15.00', '20.00', '300.00', '0.00', '2016-11-04 14:28:40', 'original', '', 'dummy', 'open', 0, '0.00', 1, 1),
(53, 4, 9, 9, 'wholesale', '50.00', '8.00', '400.00', '0.00', '2016-11-04 14:28:40', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(54, 8, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-04 14:31:29', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(55, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:31:45', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(56, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:33:29', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(57, 8, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-04 14:33:29', 'original', '', 'real', 'open', 0, '0.00', 1, 0),
(58, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:33:53', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(59, 8, 2, 2, 'wholesale', '75.00', '38.00', '2850.00', '0.00', '2016-11-04 14:33:53', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(60, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:38:06', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(61, 8, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-04 14:38:06', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(62, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:39:41', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(63, 8, 2, 2, 'retail', '7500.00', '78.00', '58500.00', '0.00', '2016-11-04 14:39:41', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(64, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 14:39:53', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(65, 8, 2, 2, 'retail', '7500.00', '78.00', '585000.00', '0.00', '2016-11-04 14:39:53', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(66, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 16:28:48', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(67, 8, 2, 2, 'retail', '750.00', '78.00', '58500.00', '0.00', '2016-11-04 16:28:48', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(68, 12, 2, 2, '-', '75.00', '10.00', '750.00', '0.00', '2016-11-04 15:38:47', 'duplicate', '', '-', 'open', 0, '0.00', 1, 1),
(69, 6, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-04 15:45:22', 'original', '', 'real', 'return', 0, '0.00', 1, 0),
(70, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 16:28:57', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(71, 8, 2, 2, '-', '750.00', '78.00', '58500.00', '0.00', '2016-11-04 16:28:57', 'duplicate', '', '-', 'return', 0, '0.00', 1, 0),
(72, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 16:53:39', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(73, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 16:53:49', 'original', '', 'dummy', 'open', 0, '0.00', 1, 0),
(74, 8, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-04 16:53:49', 'original', '', 'dummy', 'open', 0, '0.00', 1, 1),
(75, 7, 6, 5, 'retail', '50.00', '100.00', '5000.00', '0.00', '2016-11-04 16:57:23', 'original', '', 'dummy', 'open', 0, '0.00', 1, 1),
(76, 14, 1, 1, 'retail', '50.00', '50.00', '2500.00', '0.00', '2016-11-10 10:36:47', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(77, 15, 13, 13, 'retail', '5.00', '250.00', '1250.00', '0.00', '2016-11-10 10:37:58', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(78, 16, 12, 12, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-10 10:38:47', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(79, 17, 22, 22, 'retail', '5.00', '500.00', '2500.00', '0.00', '2016-11-10 10:39:31', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(80, 18, 20, 20, 'retail', '5.00', '200.00', '1000.00', '0.00', '2016-11-10 10:39:46', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(81, 19, 21, 21, 'retail', '5.00', '100.00', '500.00', '0.00', '2016-11-10 10:40:14', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(82, 20, 13, 13, 'retail', '5.00', '250.00', '1250.00', '0.00', '2016-11-10 10:40:53', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(83, 21, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-10 10:41:34', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(84, 22, 14, 14, 'retail', '5.00', '900.00', '4500.00', '0.00', '2016-11-10 10:42:41', 'original', '', 'real', 'open', 0, '0.00', 1, 1),
(85, 23, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-14 16:45:11', 'original', '', 'real', 'return', 1, '0.00', 1, 0),
(86, 23, 1, 1, 'retail', '50.00', '50.00', '2500.00', '0.00', '2016-11-14 16:41:31', 'original', '', 'real', 'open', 3, '0.00', 1, 0),
(87, 23, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-14 16:41:31', 'original', '', 'real', 'open', 3, '0.00', 1, 0),
(88, 23, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2016-11-14 16:41:31', 'original', '', 'real', 'open', 3, '0.00', 1, 0),
(89, 23, 1, 1, 'retail', '50.00', '50.00', '2500.00', '0.00', '2016-11-14 16:45:11', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(90, 23, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-14 16:45:11', 'original', '', 'dummy', 'open', 3, '0.00', 1, 0),
(91, 23, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2016-11-14 16:45:11', 'original', '', 'dummy', 'open', 3, '0.00', 1, 0),
(92, 23, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-14 18:42:26', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(93, 23, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2016-11-14 18:42:26', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(94, 23, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-19 12:30:11', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(95, 24, 32, 32, 'retail', '5.00', '100.00', '500.00', '0.00', '2016-11-19 15:21:07', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(96, 24, 30, 30, 'retail', '5.00', '100.00', '500.00', '0.00', '2016-11-19 15:21:07', 'original', '', 'real', 'return', 1, '0.00', 1, 0),
(97, 25, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2016-11-16 11:43:16', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(98, 25, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-16 11:43:16', 'original', '', 'real', 'open', 1, '0.00', 1, 1),
(99, 26, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-16 12:47:34', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(100, 26, 1, 1, 'retail', '50.00', '50.00', '2500.00', '0.00', '2016-11-16 12:47:34', 'original', '', 'real', 'return', 1, '0.00', 1, 0),
(101, 26, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2016-11-16 12:47:34', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(102, 28, 13, 13, 'retail', '5.00', '250.00', '1250.00', '0.00', '2016-11-19 11:31:09', 'original', '', 'real', 'open', 1, '0.00', 1, 1),
(103, 23, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2016-11-19 12:30:11', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(104, 24, 32, 32, 'retail', '5.00', '100.00', '500.00', '0.00', '2016-11-19 15:21:07', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(105, 29, 18, 18, 'retail', '5.00', '300.00', '1500.00', '0.00', '2016-12-19 10:35:01', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(106, 31, 14, 14, 'retail', '5.00', '900.00', '4500.00', '0.00', '2016-11-21 17:42:37', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(107, 31, 14, 14, 'retail', '1.00', '900.00', '900.00', '0.00', '2016-11-21 17:42:57', 'original', '', 'dummy', 'return', 1, '0.00', 1, 0),
(108, 31, 2, 2, 'retail', '1.00', '50.00', '50.00', '0.00', '2016-11-21 17:43:37', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(109, 31, 2, 2, 'retail', '5.00', '50.00', '250.00', '0.00', '2016-11-21 17:44:04', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(110, 31, 2, 2, 'retail', '2500.00', '78.00', '195000.00', '0.00', '2016-11-21 17:44:20', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(111, 31, 2, 2, 'retail', '250.00', '78.00', '19500.00', '0.00', '2016-11-21 17:44:34', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(112, 31, 2, 2, 'retail', '25.00', '78.00', '19500.00', '0.00', '2016-11-21 17:44:52', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(113, 31, 2, 2, 'retail', '25.00', '40.00', '1000.00', '0.00', '2016-11-24 15:05:32', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(114, 32, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2016-11-23 11:36:33', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(115, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:05:45', 'original', '', 'real', 'open', 1, '50.00', 1, 0),
(116, 33, 2, 2, 'wholesale', '75.00', '38.00', '2850.00', '0.00', '2016-11-23 12:05:45', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(117, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:07:54', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(118, 33, 43, 43, 'wholesale', '50.00', '44.00', '2200.00', '0.00', '2016-11-23 12:07:54', 'original', '', 'real', 'open', 1, '50.00', 1, 0),
(119, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:10:39', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(120, 33, 43, 43, 'wholesale', '50.00', '44.00', '2200.00', '0.00', '2016-11-23 12:10:39', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(121, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:15:49', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(122, 33, 43, 43, 'wholesale', '50.00', '44.00', '2200.00', '0.00', '2016-11-23 12:15:49', 'original', '', 'dummy', 'open', 1, '0.00', 1, 0),
(123, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(124, 33, 43, 43, 'wholesale', '50.00', '44.00', '2200.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(125, 33, 2, 2, 'wholesale', '75.00', '38.00', '2850.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(126, 33, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 1),
(127, 33, 43, 43, 'wholesale', '50.00', '44.00', '2200.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 1),
(128, 33, 2, 2, 'wholesale', '75.00', '38.00', '2850.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'real', 'open', 1, '0.00', 1, 1),
(129, 33, 44, 43, 'wholesale', '50.00', '49.00', '2450.00', '0.00', '2016-11-23 12:16:22', 'original', '', 'dummy', 'open', 1, '50.00', 1, 1),
(130, 30, 3, 2, '-', '75.00', '0.00', '0.00', '0.00', '2016-11-23 14:43:01', 'duplicate', '', '-', 'open', 1, '0.00', 1, 1),
(131, 31, 43, 43, 'retail', '50.00', '45.00', '2250.00', '0.00', '2016-11-24 15:05:32', 'original', '', 'real', 'open', 1, '50.00', 1, 1),
(132, 34, 9, 9, '-', '50.00', '0.00', '0.00', '0.00', '2016-11-24 15:19:17', 'duplicate', '', '-', 'open', 1, '0.00', 0, 0),
(133, 34, 43, 43, '-', '50.00', '0.00', '0.00', '0.00', '2016-11-24 15:24:03', 'duplicate', '', '-', 'open', 1, '50.00', 0, 0),
(134, 34, 43, 43, '-', '50.00', '0.00', '0.00', '0.00', '2016-11-24 17:08:22', 'duplicate', '', '-', 'open', 1, '50.00', 1, 0),
(135, 34, 43, 43, '-', '50.00', '50.00', '2500.00', '0.00', '2016-11-24 17:08:22', 'duplicate', '', '-', 'open', 1, '50.00', 1, 1),
(136, 29, 18, 18, 'retail', '5.00', '300.00', '1500.00', '0.00', '2016-12-19 10:35:01', 'original', '', 'real', 'open', 1, '300.00', 1, 1),
(137, 37, 11, 10, 'retail', '5.00', '22.25', '111.25', '0.00', '2017-01-04 10:30:30', 'original', '', 'dummy', 'open', 1, '0.00', 1, 1),
(138, 38, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:17:16', 'original', '', 'real', 'open', 1, '0.00', 1, 0),
(139, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:18:11', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 1, 0),
(140, 38, 3, 2, '-', '75.00', '100.00', '7500.00', '0.00', '2017-01-04 11:18:11', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(141, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:35:08', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 1, 0),
(142, 38, 3, 2, '-', '75.00', '100.00', '7500.00', '0.00', '2017-01-04 11:35:08', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(143, 38, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:35:08', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(144, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:36:20', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 0, 0),
(145, 38, 3, 2, '-', '75.00', '100.00', '7500.00', '0.00', '2017-01-04 11:36:20', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(146, 38, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:36:20', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(147, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:41:08', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 0, 0),
(148, 38, 3, 2, '-', '75.00', '45.00', '3375.00', '0.00', '2017-01-04 11:41:08', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(149, 38, 24, 24, 'retail', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:41:08', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(150, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:49:25', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 0, 0),
(151, 38, 3, 2, '-', '75.00', '45.00', '3375.00', '0.00', '2017-01-04 11:49:25', 'original', 'rice_center', 'dummy', 'return', 1, '0.00', 1, 0),
(152, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:49:25', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(153, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:49:25', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 0, 1),
(154, 38, 24, 24, '-', '5.00', '300.00', '1500.00', '0.00', '2017-01-04 11:49:25', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 1),
(155, 1, 1, 1, 'retail', '150.00', '50.00', '7500.00', '0.00', '2017-01-04 18:23:46', 'original', 'rice_mandy', 'real', 'open', 1, '0.00', 0, 1),
(156, 42, 13, 13, '-', '5.00', '9.00', '45.00', '0.00', '2017-01-09 15:02:55', 'duplicate', 'out_stock', '-', 'open', 1, '10.00', 1, 1),
(157, 42, 16, 16, '-', '5.00', '10.00', '50.00', '0.00', '2017-01-09 15:02:56', 'duplicate', 'health_store', '-', 'open', 1, '0.00', 1, 1),
(158, 42, 11, 10, 'retail', '5.00', '22.25', '111.25', '0.00', '2017-01-09 15:02:56', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 1),
(159, 51, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-23 15:04:52', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(160, 51, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-23 15:22:40', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(161, 51, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-23 15:23:04', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(162, 51, 9, 9, 'retail', '500.00', '10.00', '5000.00', '0.00', '2017-01-23 15:23:04', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(163, 51, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-23 15:23:43', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(164, 51, 9, 9, '-', '500.00', '10.00', '5000.00', '0.00', '2017-01-23 15:23:43', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(165, 51, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-23 15:26:37', 'original', 'rice_center', 'dummy', 'return', 1, '0.00', 1, 0),
(166, 51, 9, 9, '-', '500.00', '10.00', '5000.00', '0.00', '2017-01-23 15:26:37', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(167, 51, 9, 9, '-', '500.00', '10.00', '5000.00', '0.00', '2017-01-23 15:26:37', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 1),
(168, 53, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2017-01-25 12:19:40', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(169, 53, 9, 9, 'retail', '50.00', '10.00', '500.00', '0.00', '2017-01-25 12:20:00', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(170, 53, 9, 9, 'retail', '100.00', '10.00', '1000.00', '0.00', '2017-01-25 12:20:00', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(171, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 14:53:47', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(172, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 14:57:06', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(173, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 14:57:38', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(174, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 18:01:45', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(175, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 18:11:02', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(176, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-25 18:12:00', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(177, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:55:19', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(178, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:55:19', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(179, 52, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-25 18:12:45', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 0, 1),
(180, 50, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-26 10:18:05', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 0, 1),
(181, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:55:31', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(182, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:55:31', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(183, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:56:35', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(184, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:56:35', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(185, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:01', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(186, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:01', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(187, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(188, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(189, 54, 14, 14, 'retail', '5.00', '900.00', '4500.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(190, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(191, 54, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(192, 54, 14, 14, 'retail', '5.00', '900.00', '4500.00', '0.00', '2017-01-26 17:57:18', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(193, 56, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-27 10:09:00', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(194, 56, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-27 10:21:02', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 1, 0),
(195, 56, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-27 10:21:12', 'original', 'rice_center', 'dummy', 'open', 1, '0.00', 0, 0),
(196, 56, 3, 2, 'retail', '75.00', '45.00', '3375.00', '0.00', '2017-01-27 10:26:56', 'original', 'rice_center', 'dummy', 'return', 1, '0.00', 1, 0),
(197, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 10:59:31', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(198, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 11:01:55', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(199, 56, 9, 9, '-', '50.00', '0.00', '0.00', '0.00', '2017-01-27 11:01:55', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(200, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 11:04:25', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(201, 56, 9, 9, '-', '50.00', '10.00', '500.00', '0.00', '2017-01-27 11:04:25', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(202, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 11:46:23', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(203, 56, 9, 9, '-', '50.00', '10.00', '500.00', '0.00', '2017-01-27 11:46:23', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(204, 56, 24, 24, '-', '5.00', '20.00', '100.00', '0.00', '2017-01-27 11:46:23', 'duplicate', 'health_store', '-', 'return', 1, '0.00', 1, 0),
(205, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 12:04:32', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 0),
(206, 56, 9, 9, '-', '50.00', '10.00', '500.00', '0.00', '2017-01-27 12:04:32', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 1, 0),
(207, 56, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-01-27 12:04:32', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(208, 56, 9, 9, '-', '50.00', '10.00', '500.00', '0.00', '2017-01-27 12:04:32', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 0, 1),
(209, 55, 2, 2, 'retail', '3375.00', '78.00', '263250.00', '0.00', '2017-02-03 10:22:51', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 0),
(210, 57, 16, 16, '-', '10.00', '200.00', '2000.00', '0.00', '2017-02-02 17:36:11', 'duplicate', 'health_store', '-', 'open', 1, '200.00', 1, 1),
(211, 55, 2, 2, 'retail', '30.00', '40.00', '1200.00', '0.00', '2017-02-03 10:24:16', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 0),
(212, 55, 2, 2, 'retail', '30.00', '40.00', '1200.00', '0.00', '2017-02-03 12:57:27', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 0),
(213, 55, 2, 2, 'retail', '30.00', '40.00', '1200.00', '0.00', '2017-02-03 12:57:31', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 0),
(214, 55, 2, 2, 'retail', '30.00', '40.00', '1200.00', '0.00', '2017-02-03 12:57:31', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 1),
(215, 58, 2, 2, 'retail', '20.00', '45.00', '900.00', '0.00', '2017-02-03 15:49:39', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1),
(216, 58, 2, 2, '-', '75.00', '50.00', '3750.00', '0.00', '2017-02-03 15:49:39', 'duplicate', 'out_stock', '-', 'open', 1, '0.00', 0, 1),
(217, 36, 2, 2, 'retail', '75.00', '78.00', '5850.00', '0.00', '2017-02-03 16:07:17', 'original', 'rice_center', 'real', 'open', 1, '0.00', 0, 1),
(218, 60, 45, 45, 'wholesale', '11.00', '80.00', '880.00', '0.00', '2017-02-08 10:33:21', 'original', 'rice_center', 'real', 'open', 1, '2000.00', 1, 0),
(219, 60, 46, 45, 'wholesale', '11.00', '70.00', '770.00', '0.00', '2017-02-08 10:33:21', 'original', 'rice_center', 'dummy', 'return', 1, '2000.00', 1, 0),
(220, 60, 45, 45, 'wholesale', '11.00', '80.00', '880.00', '0.00', '2017-02-08 10:33:21', 'original', 'rice_center', 'real', 'open', 1, '2000.00', 1, 1),
(221, 62, 14, 14, 'retail', '5.00', '900.00', '4500.00', '0.00', '2017-03-02 11:41:35', 'original', 'rice_center', 'real', 'open', 1, '0.00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_stock`
--

CREATE TABLE `wp_stock` (
  `id` int(11) NOT NULL,
  `lot_id` bigint(20) NOT NULL,
  `bags_count` int(11) NOT NULL,
  `bag_weight` int(11) NOT NULL,
  `total_weight` decimal(9,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_stock`
--

INSERT INTO `wp_stock` (`id`, `lot_id`, `bags_count`, `bag_weight`, `total_weight`, `created_at`, `modified_at`, `active`) VALUES
(1, 1, 2, 50, '100.00', '2016-10-18 13:35:38', '0000-00-00 00:00:00', 1),
(2, 2, 2, 75, '150.00', '2016-10-18 13:35:47', '0000-00-00 00:00:00', 1),
(3, 2, 5, 75, '375.00', '2016-10-18 16:22:36', '0000-00-00 00:00:00', 1),
(4, 5, 50, 5, '250.00', '2016-10-19 17:13:07', '0000-00-00 00:00:00', 1),
(5, 4, 50, 5, '250.00', '2016-10-19 17:13:20', '0000-00-00 00:00:00', 1),
(6, 4, 4, 5, '20.00', '2016-10-25 13:08:07', '2016-11-15 17:22:39', 0),
(7, 10, 100, 5, '500.00', '2016-11-03 11:59:50', '0000-00-00 00:00:00', 1),
(8, 13, 5, 5, '25.00', '2016-11-10 09:51:49', '0000-00-00 00:00:00', 1),
(9, 19, 10, 5, '50.00', '2016-11-10 09:52:01', '0000-00-00 00:00:00', 1),
(10, 21, 12, 5, '60.00', '2016-11-10 09:52:12', '0000-00-00 00:00:00', 1),
(11, 23, 5, 5, '25.00', '2016-11-10 09:52:25', '0000-00-00 00:00:00', 1),
(12, 26, 3, 10, '30.00', '2016-11-10 09:52:51', '0000-00-00 00:00:00', 1),
(13, 26, 8, 10, '80.00', '2016-11-10 09:53:04', '0000-00-00 00:00:00', 1),
(14, 14, 5, 5, '25.00', '2016-11-10 09:53:49', '0000-00-00 00:00:00', 1),
(15, 19, 5, 5, '25.00', '2016-11-10 09:53:58', '0000-00-00 00:00:00', 1),
(16, 16, 8, 5, '40.00', '2016-11-10 09:54:10', '0000-00-00 00:00:00', 1),
(17, 15, 5, 5, '25.00', '2016-11-10 09:54:21', '0000-00-00 00:00:00', 1),
(18, 18, 6, 5, '30.00', '2016-11-10 09:54:36', '0000-00-00 00:00:00', 1),
(19, 20, 7, 5, '35.00', '2016-11-10 09:54:51', '0000-00-00 00:00:00', 1),
(20, 25, 6, 5, '30.00', '2016-11-10 09:55:04', '2016-11-15 17:22:59', 0),
(21, 10, 6, 5, '30.00', '2016-11-10 09:55:19', '0000-00-00 00:00:00', 1),
(22, 27, 10, 5, '50.00', '2016-11-10 09:55:38', '2016-11-11 16:52:37', 1),
(23, 2, 50, 75, '3750.00', '2017-01-10 17:42:53', '0000-00-00 00:00:00', 1),
(24, 9, 10, 50, '500.00', '2017-01-25 18:18:29', '0000-00-00 00:00:00', 1),
(25, 45, 100, 75, '7500.00', '2017-02-08 10:13:25', '0000-00-00 00:00:00', 1),
(26, 1, 100, 50, '5000.00', '2017-04-19 11:41:05', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '0'),
(14, 1, 'session_tokens', 'a:1:{s:64:"66d895e84c3472a08a08ce3eecf60ee986a86b8aebb674d1c05d14a286e3cbf2";a:4:{s:10:"expiration";i:1504752720;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36";s:5:"login";i:1504579920;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '20'),
(16, 2, 'nickname', 'Sales1'),
(17, 2, 'first_name', 'Sales'),
(18, 2, 'last_name', '1'),
(19, 2, 'description', ''),
(20, 2, 'rich_editing', 'true'),
(21, 2, 'comment_shortcuts', 'false'),
(22, 2, 'admin_color', 'fresh'),
(23, 2, 'use_ssl', '0'),
(24, 2, 'show_admin_bar_front', 'true'),
(25, 2, 'wp_capabilities', 'a:1:{s:10:"new_seegan";b:1;}'),
(26, 2, 'wp_user_level', '0'),
(27, 2, 'dismissed_wp_pointers', ''),
(28, 2, 'session_tokens', 'a:1:{s:64:"18f1bed853c969213e479ba43ba4e55457e142a72c94a3e7128b80ff293b003d";a:4:{s:10:"expiration";i:1478435799;s:2:"ip";s:13:"192.168.0.150";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";s:5:"login";i:1478262999;}}'),
(29, 1, 'wp_user-settings', 'mfold=o&libraryContent=browse'),
(30, 1, 'wp_user-settings-time', '1504579921'),
(31, 3, 'nickname', 'seegan'),
(32, 3, 'first_name', ''),
(33, 3, 'last_name', ''),
(34, 3, 'description', ''),
(35, 3, 'rich_editing', 'true'),
(36, 3, 'comment_shortcuts', 'false'),
(37, 3, 'admin_color', 'fresh'),
(38, 3, 'use_ssl', '0'),
(39, 3, 'show_admin_bar_front', 'true'),
(40, 3, 'wp_capabilities', 'a:1:{s:5:"sales";b:1;}'),
(41, 3, 'wp_user_level', '0'),
(42, 3, 'dismissed_wp_pointers', ''),
(43, 3, 'session_tokens', 'a:1:{s:64:"87d7c986f8b44ab8bd427b5ec1cd8992e8317a3e7751af533b91ed6ce0d4df99";a:4:{s:10:"expiration";i:1479294576;s:2:"ip";s:13:"192.168.0.125";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36";s:5:"login";i:1479121776;}}'),
(44, 2, 'mobile', '9952380502'),
(45, 3, 'mobile', '1234567'),
(46, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(47, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(48, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:48:"my_sales_tatistics_widget,my_stock_status_widget";s:4:"side";s:55:"my_sales_delivery_status_widget,lot_status_chart_widget";s:7:"column3";s:22:"customer_status_widget";s:7:"column4";s:0:"";}'),
(49, 4, 'nickname', 'evan'),
(50, 4, 'first_name', ''),
(51, 4, 'last_name', ''),
(52, 4, 'description', ''),
(53, 4, 'rich_editing', 'true'),
(54, 4, 'comment_shortcuts', 'false'),
(55, 4, 'admin_color', 'fresh'),
(56, 4, 'use_ssl', '0'),
(57, 4, 'show_admin_bar_front', 'true'),
(58, 4, 'wp_capabilities', 'a:1:{s:10:"hr_manager";b:1;}'),
(59, 4, 'wp_user_level', '0'),
(60, 4, 'dismissed_wp_pointers', ''),
(61, 4, 'mobile', '099384733'),
(62, 4, 'session_tokens', 'a:1:{s:64:"9015edcd2e94694702626b967f2110496fe6b8f0833bdafff1800718a9c25967";a:4:{s:10:"expiration";i:1486700796;s:2:"ip";s:13:"192.168.0.150";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";s:5:"login";i:1486527996;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B3wKW1S4nWJ4yAIYtWRBc5ohdRuMof.', 'admin', 'src@gmail.com', '', '2016-08-20 10:05:17', '', 0, 'admin'),
(2, 'Sales1', '$P$B5u4Tqt3bZtE8Si6fCyxDmu3ZhBRoy1', 'sales1', 'Sales1@gmail.com', '', '2016-08-20 10:11:07', '1471687869:$P$BNWsx90p9U5HA8P1cpSEtmfmbUSnCh1', 0, 'Sales 1'),
(3, 'seegan', '$P$B8RA3l2tdX50FW0kzigCV9Rp57gJil/', 'seegan', 'testsee@gmail.com', '', '2016-09-07 10:04:32', '', 0, 'seegan'),
(4, 'evan', '$P$Bbd2mR3cKTCV5mBLT35R8qoe/iXN7L/', 'evan', '', '', '2017-02-08 04:25:58', '', 0, 'evan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_customers`
--
ALTER TABLE `wp_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_employees`
--
ALTER TABLE `wp_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_employee_attendance`
--
ALTER TABLE `wp_employee_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_employee_salary`
--
ALTER TABLE `wp_employee_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_employee_salary_data`
--
ALTER TABLE `wp_employee_salary_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_income_list`
--
ALTER TABLE `wp_income_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_lots`
--
ALTER TABLE `wp_lots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_lots_detail`
--
ALTER TABLE `wp_lots_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_payment_history`
--
ALTER TABLE `wp_payment_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_payment_installment`
--
ALTER TABLE `wp_payment_installment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_petty_cash`
--
ALTER TABLE `wp_petty_cash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_sale`
--
ALTER TABLE `wp_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_sale_detail`
--
ALTER TABLE `wp_sale_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_stock`
--
ALTER TABLE `wp_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_customers`
--
ALTER TABLE `wp_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `wp_employees`
--
ALTER TABLE `wp_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `wp_employee_attendance`
--
ALTER TABLE `wp_employee_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `wp_employee_salary`
--
ALTER TABLE `wp_employee_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `wp_employee_salary_data`
--
ALTER TABLE `wp_employee_salary_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_income_list`
--
ALTER TABLE `wp_income_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_lots`
--
ALTER TABLE `wp_lots`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `wp_lots_detail`
--
ALTER TABLE `wp_lots_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;
--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2381;
--
-- AUTO_INCREMENT for table `wp_payment_history`
--
ALTER TABLE `wp_payment_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `wp_payment_installment`
--
ALTER TABLE `wp_payment_installment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `wp_petty_cash`
--
ALTER TABLE `wp_petty_cash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `wp_sale`
--
ALTER TABLE `wp_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `wp_sale_detail`
--
ALTER TABLE `wp_sale_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
--
-- AUTO_INCREMENT for table `wp_stock`
--
ALTER TABLE `wp_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
