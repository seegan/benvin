
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">	<head>
	



<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#nav li ul").hide();
	$("#nav li ul").hover(
		function() {
		},
		function() {
			$(this).fadeOut('slow');
		}
	);
	$("#nav li").click(
		function() {
		$("#nav li").children("ul").fadeOut('slow');
		$(this).children("ul").show();
		
		}
	);
});
</script>
	<script>
		var foo = {};
		foo.columns=5;
	</script>

	<script src="soroban/abacus.js" type="text/javascript"></script>
	<script src="soroban/soroban.js" type="text/javascript"></script>

	<style type="text/css">
		.number-board {
			width:46px;
			text-align: center;
			padding: 0;
			font-size: 50px;
		}
		.bead {
			cursor: pointer;
		}
	</style>
</head>

<body>

<div id="middle">
	<div id="calculator">
		<div><script type="text/javascript">xtragenius.htmldraw(foo.columns)</script></div>
	</div>
</div>


</body>
</html>

<?php



function friendRule( $level = 'small' ) {

	if( $level == 'small' ) {
		$a = getRandomNumbers(1,5, array(5));
	}  
	if( $level == 'negative' ) {
		$a = getRandomNumbers(1,9, array(5));
	}
	if( $level == 'all' ) {
		$a = getRandomNumbers(1,9, array(5));
	}

	//$a = 8;

	$posiblities_b = array();
	$posiblities_c = array();

	if($a < 5) {
		//negative posiblities for small numbers ( 1 to 3 )
		if($level == 'negative' || $level == 'all') {
			$up_bead_bal = (($a + 4) - 5 );
			$posiblities_c[] = -5;
			for ($i = $up_bead_bal; $i > 0 ; $i--) { 
				$posiblities_c[] = -1 * abs($i);
				$posiblities_c[] = -1 * abs($i+5);
			}
		}

		if($level == 'small' || $level == 'all') {
			//Positive posiblities for small numbers ( 1 to 3 )
			$down_bead_bal = ( 9 - ($a + 4) );
			for ($i = 1; $i <= $down_bead_bal ; $i++) { 
				$posiblities_c[] = abs($i);
			}
		}

		$posiblities_b[] = 4;
	}


	if($a > 5) {
		$posiblities_b[] = -5;
		for ($i = ($a-1); $i > 5 ; $i--) { 
			$posiblities_b[] = -1 * abs($i);
		}

		$posiblities_c[] = 4;
	}

	$b = getArrayRandomNumber($posiblities_b);
	$c = getArrayRandomNumber($posiblities_c);
	$rule = array('a' => $a, 'b' => $b, 'c' => $c);
	return $rule;
}
	








function getRandomNumbers($from = 1 , $to = 9, $exclude = array()) {
	do {
		$n = rand($from, $to);
	} while(in_array($n, $exclude)) ;
	return $n;
}

function getArrayRandomNumber($array_data = array()) {
	$rand = $array_data[array_rand($array_data,1)];
	return $rand;
}




//Xtragenius Logic
/*	$a = rand(1, 4);
	$b = 4;
	if($b == 4) {
		$e = $a + 4;
	} else {
		$e = $a + $b;
	}

	if($e == 5) {
		$c = $e-3;
	}
	if($e == 6) {
		$c = $e-7;
	}
	if($e == 7) {
		$c = $e-5;
	}
	if($e == 8) {
		$c = $e-11;
	}

	$d = $a + $b + $c;


	var_dump($a);
	var_dump($b);
	var_dump($c);
	var_dump($d);
	var_dump($e)*/
?>

<style type="text/css">
	.rule_container {

	}
	.top_bar {
		background: #4d4d4d;
		color: #fff;
	}
	.rule_number, .top_bar {
		width: 50px;
		height: 20px;
		text-align: center;
	}
	.left_bar {
		background: #4d4d4d;		
		width: 50px;
		height: 84px;
		text-align: center;
		color: #fff;
	}	
	.rule_number {
		border-bottom: 1px solid #000;
	}
	.left_float {
		float: left;
		border: 1px solid #000;
	}
	.clear {
		clear: both;
	}
</style>
<div>


	<div> Small Friend Rule +4 = +5 -1 ( Positive Numbers )</div>
	<div class="friend_rule">
		<div style="margin-bottom: 11px;">
			<div class="left_float">
				<div class="top_bar">.</div>
			</div>		
			<div class="left_float">
				<div class="top_bar">1</div>
			</div>
			<div class="left_float">
				<div class="top_bar">2</div>
			</div>
			<div class="left_float">
				<div class="top_bar">3</div>
			</div>
			<div class="left_float">
				<div class="top_bar">4</div>
			</div>
			<div class="left_float">
				<div class="top_bar">5</div>
			</div>
			<div class="left_float">
				<div class="top_bar">6</div>
			</div>
			<div class="left_float">
				<div class="top_bar">7</div>
			</div>
			<div class="left_float">
				<div class="top_bar">8</div>
			</div>
			<div class="left_float">
				<div class="top_bar">9</div>
			</div>
			<div class="left_float">
				<div class="top_bar">10</div>
			</div>
			<div class="clear"></div>
		</div>

		<div>
			<div class="left_float">
				<div class="left_bar">
					<div class="left_label" style="padding-top: 32px;">A</div>
				</div>
			</div>		
			<?php 
				for ($i=0; $i < 10 ; $i++) { 
					$data = friendRule('small');
			?>		
				<div class="rule_container left_float">
					<div class="rule_number"><?php echo $data['a'] ?></div>
					<div class="rule_number"><?php echo $data['b'] ?></div>
					<div class="rule_number"><?php echo $data['c'] ?></div>
					<div class="rule_number"></div>
				</div>
			<?php
				}
			?>
		</div>

		<div class="clear"></div>
	</div>




	<br><br>
	<div> Small Friend Rule +4 = +5 -1 ( Negative Numbers )</div>
	<div class="friend_rule">
		<div style="margin-bottom: 11px;">
			<div class="left_float">
				<div class="top_bar">.</div>
			</div>		
			<div class="left_float">
				<div class="top_bar">1</div>
			</div>
			<div class="left_float">
				<div class="top_bar">2</div>
			</div>
			<div class="left_float">
				<div class="top_bar">3</div>
			</div>
			<div class="left_float">
				<div class="top_bar">4</div>
			</div>
			<div class="left_float">
				<div class="top_bar">5</div>
			</div>
			<div class="left_float">
				<div class="top_bar">6</div>
			</div>
			<div class="left_float">
				<div class="top_bar">7</div>
			</div>
			<div class="left_float">
				<div class="top_bar">8</div>
			</div>
			<div class="left_float">
				<div class="top_bar">9</div>
			</div>
			<div class="left_float">
				<div class="top_bar">10</div>
			</div>
			<div class="clear"></div>
		</div>

		<div>
			<div class="left_float">
				<div class="left_bar">
					<div class="left_label" style="padding-top: 32px;">B</div>
				</div>
			</div>		
			<?php 
				for ($i=0; $i < 10 ; $i++) { 
					$data = friendRule('negative');
			?>		
				<div class="rule_container left_float">
					<div class="rule_number"><?php echo $data['a'] ?></div>
					<div class="rule_number"><?php echo $data['b'] ?></div>
					<div class="rule_number"><?php echo $data['c'] ?></div>
					<div class="rule_number"></div>
				</div>
			<?php
				}
			?>
		</div>

		<div class="clear"></div>
	</div>


	<br><br>

	<div> Small Friend Rule +4 = +5 -1 ( Mixed Numbers )</div>
	<div class="friend_rule">
		<div style="margin-bottom: 11px;">
			<div class="left_float">
				<div class="top_bar">.</div>
			</div>		
			<div class="left_float">
				<div class="top_bar">1</div>
			</div>
			<div class="left_float">
				<div class="top_bar">2</div>
			</div>
			<div class="left_float">
				<div class="top_bar">3</div>
			</div>
			<div class="left_float">
				<div class="top_bar">4</div>
			</div>
			<div class="left_float">
				<div class="top_bar">5</div>
			</div>
			<div class="left_float">
				<div class="top_bar">6</div>
			</div>
			<div class="left_float">
				<div class="top_bar">7</div>
			</div>
			<div class="left_float">
				<div class="top_bar">8</div>
			</div>
			<div class="left_float">
				<div class="top_bar">9</div>
			</div>
			<div class="left_float">
				<div class="top_bar">10</div>
			</div>
			<div class="clear"></div>
		</div>

		<div>
			<div class="left_float">
				<div class="left_bar">
					<div class="left_label" style="padding-top: 32px;">D</div>
				</div>
			</div>		
			<?php 
				for ($i=0; $i < 10 ; $i++) { 
					$data = friendRule('all');
			?>		
				<div class="rule_container left_float">
					<div class="rule_number"><?php echo $data['a'] ?></div>
					<div class="rule_number"><?php echo $data['b'] ?></div>
					<div class="rule_number"><?php echo $data['c'] ?></div>
					<div class="rule_number"></div>
				</div>
			<?php
				}
			?>
		</div>

		<div class="clear"></div>
	</div>	

</div>