
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">	<head>
	



<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#nav li ul").hide();
	$("#nav li ul").hover(
		function() {
		},
		function() {
			$(this).fadeOut('slow');
		}
	);
	$("#nav li").click(
		function() {
		$("#nav li").children("ul").fadeOut('slow');
		$(this).children("ul").show();
		
		}
	);
});
</script>
	<script>
		var foo = {};
		foo.columns=5;
	</script>

	<script src="soroban/abacus.js" type="text/javascript"></script>
	<script src="soroban/soroban.js" type="text/javascript"></script>

	<style type="text/css">
		.number-board {
			width:46px;
			text-align: center;
			padding: 0;
			font-size: 50px;
		}
	</style>
</head>

<body>

<div id="middle">
	<div id="calculator">
		<div><script type="text/javascript">mysoroban.htmldraw(foo.columns)</script></div>
	</div>
</div>


</body>
</html>

<?php
	$a = rand(1, 4);
	$b = 4;
	if($b == 4) {
		$e = $a + 4;
	} else {
		$e = $a + $b;
	}

	if($e == 5) {
		$c = $e-3;
	}
	if($e == 6) {
		$c = $e-7;
	}
	if($e == 7) {
		$c = $e-5;
	}
	if($e == 8) {
		$c = $e-11;
	}

	$d = $a + $b + $c;


	var_dump($a);
	var_dump($b);
	var_dump($c);
	var_dump($d);
	var_dump($e)
?>