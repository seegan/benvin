<?php
 if(isset($_POST['action']) && $_POST['action'] == 'attendance_list_filter_dividual') {
		$cpage = 1;
		$ppage = $_POST['per_page'];
		$attendance_date_form = ($_POST['attendance_date_form'] != '') ? $_POST['attendance_date_form'] : '';
		$emp_id = ($_POST['emp_id'] != '') ? $_POST['emp_id'] : '';
		$attendance_date_to = ($_POST['attendance_date_to'] != '') ? $_POST['attendance_date_to'] : '';
		$attendance_status = $_POST['attendance_status'];
	} else {
		$cpage 					= isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
		$ppage 					= isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
		$attendance_date_form 	= isset( $_GET['attendance_date_form'] ) ? $_GET['attendance_date_form']  : '';
		$emp_id 		= isset( $_GET['emp_id'] ) ? $_GET['emp_id']  : '';
		$attendance_date_to 	= isset( $_GET['attendance_date_to'] ) ? $_GET['attendance_date_to']  : '';
		$attendance_status 		= isset( $_GET['attendance_status'] ) ? $_GET['attendance_status']  : '-';
	}

    $con = false;
    $condition = '';
	$condition .= " AND tab.emp_id = '".$emp_id."'";

    if($attendance_status != '-' ) {
   		if($con == false) {
    		$condition .= " AND tab.emp_attendance = '".$attendance_status."' ";
    	} else {
    		$condition .= " AND tab.emp_attendance = '".$attendance_status."' ";
    	}
    	$con = true;
    }


     if($attendance_date_form != '' && $attendance_date_to == '') {
        if($con == false) {
            $condition .= " AND DATE(tab.attendance_date) >= '".$attendance_date_form."' ";
        } else {
            $condition .= " AND DATE(tab.attendance_date) >= '".$attendance_date_form."' ";
        }
        $con = true;
    }
    if($attendance_date_form == '' && $attendance_date_to != '') {
        if($con == false) {
            $condition .= " AND DATE(tab.attendance_date) <= '".$attendance_date_to."' ";
        } else {
            $condition .= " AND DATE(tab.attendance_date) <= '".$attendance_date_to."' ";
        }
        $con = true;
    }
    if($attendance_date_form != '' && $attendance_date_to != '') {
   		if($con == false) {
    		$condition .= " AND ( DATE(tab.attendance_date) >= '".$attendance_date_form."' AND DATE(tab.attendance_date) <= '".$attendance_date_to."') ";
    	} else {
    		$condition .= " AND ( DATE(tab.attendance_date) >= '".$attendance_date_form."' AND DATE(tab.attendance_date) <= '".$attendance_date_to."') ";
    	}
    	$con = true;
    }
    /*End Updated for filter 11/10/16*/
	$result_args = array(
		'orderby_field' => 'id',
		'page' => $cpage ,
		'order_by' => 'ASC',
		'items_per_page' => $ppage ,
		'condition' => $condition,
	);


	// $result_args = array(
	// 	'orderby_field' => 'id',
	// 	'page' => isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1 ,
	// 	'order_by' => 'ASC',
	// 	'items_per_page' => isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20 ,
	// 	'condition' => 'AND ea.emp_id='.$_GET['emp_id'].'  ',
	// );

	$employee_attendance = employee_attendance_detail_pagination($result_args);

?>
<?php if(isset($employee_attendance['s_result']->working_hours_total)) { ?>
    <div class="module table-simple" style="width:400px;margin: 0 auto;margin-bottom:20px;">
        <table class="display">
            <thead>
                <tr>
                	
                	<th>Actual Working Hours</th>
                    <th>Total Working Hours</th>                 
                   <!--  <th>Extra Working Hours</th>       -->           
                              
                                
                </tr>
            </thead>
            <tbody>
                <tr>
        			<td><?php echo $actual_time = $employee_attendance['days_time']->time; ?>
					</td>
                    <td><?php echo $working_time = $employee_attendance['s_result']->working_hours_total; ?></td>         
                                      
                </tr>
            </tbody>
        </table>
    </div>
<?php } ?>
	<table class="display">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Date</th>
				<th>Attendance</th>
				<th>Working Hours</th>
			</tr>
		</thead>
		<tbody>
		<?php
			if( count($employee_attendance['result'])>0 ) {
				$start_count = $employee_attendance['start_count'];
				foreach ($employee_attendance['result'] as $attendance_value) {
					$start_count++;
		?>
			<tr id="employee-data-<?php echo $attendance_value->id; ?>">
				<td><?php echo $start_count; ?></td>
				<td><?php echo date('Y-m-d', strtotime($attendance_value->attendance_date) ); ?></td>
				<td><?php $i = 0;
				if ($attendance_value->attendance == 'Present') {
					$i++;
				}
				echo $attendance_value->attendance; 
				?></td>
				<td><?php echo $attendance_value->final_hours; ?></td>
				
				<!-- <td class="center">
					<span>
						<a class="action-icons c-edit salary_edit" title="Edit" data-roll="12" data-id="">Edit</a>
					</span>
				</td> -->
			</tr>
		<?php
				}
			}

		?>
		</tbody>
	</table>

	<?php echo $employee_attendance['pagination']; ?>