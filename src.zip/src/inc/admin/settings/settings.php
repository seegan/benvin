<?php
	global $wpdb;
	$courier_table = $wpdb->prefix.'courier_price_detail';
	if(isset($_POST['update_courier'])) {
		$wpdb->update($courier_table, array('active' => 0), array('active'=>1));

		if (count($_POST['courier'])) {
			foreach ($_POST['courier'] as $value) {
				$wpdb->insert($courier_table, array('name' => $value['courier_name'], 'price' => $value['courier_price'], 'note' => $value['courier_note'] ));
			}
		}
	}

	$courier_list = getCourierList();
?>
	<h2>
		Courier Settings
	</h2>
	<form action="" method="POST">
		<div class="courier-repeater">
		  	<div data-repeater-list="courier" class="div-table">

			    <div class="div-table-row">
				    <div class="div-table-head">S.No</div>
				    <div class="div-table-head">Courier Name</div>
				    <div class="div-table-head">Notes</div>
				    <div class="div-table-head">Price Per Piece</div>
				    <div class="div-table-head">Option</div>
				</div>
				<?php
					if($courier_list) {
						foreach ($courier_list as $value) {
				?>
		    	<div data-repeater-item class="repeterin div-table-row">
					<div class="div-table-col rowno">1</div>
				    <div class="div-table-col">
				    	<input type="text" name="courier_name" class="courier_name" autocomplete="off" value=<?php echo $value->name; ?>>
				    </div>
				    <div class="div-table-col">
				    	<textarea name="courier_note"><?php echo $value->note; ?></textarea>
				    </div>
				    <div class="div-table-col">
				    	<input type="text" name="courier_price" class="courier_price" autocomplete="off" value="<?php echo $value->price; ?>">
				    </div>
				    <div class="div-table-col">
				    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
				    	<input type="hidden" value="Delete"/>
				    </div>
		        </div>
				<?php
						}
					} else {
				?>
			    	<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col rowno">1</div>
					    <div class="div-table-col">
					    	<input type="text" name="courier_name" class="courier_name" autocomplete="off">
					    </div>
					    <div class="div-table-col">
					    	<textarea name="courier_note"></textarea>
					    </div>
					    <div class="div-table-col">
					    	<input type="text" name="courier_price" class="courier_price" autocomplete="off">
					    </div>
					    <div class="div-table-col">
					    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
					    	<input type="hidden" value="Delete"/>
					    </div>
			        </div>
				<?php
					}
				?>
		    </div>
			<ul class="icons-labeled">
				<li><a href="javascript:void(0);" id="add_new_price_range2" data-repeater-create><span class="icon-block-color add-c"></span>Add Courier</a></li>
			</ul>
		</div>
		<div class="button_sub">
			<button type="submit" name="update_courier" id="btn_submit" class="submit-button">Update Courier</button>
		</div>
	</form>




<script type="text/javascript">
    jQuery('.courier-repeater').repeater({
        defaultValues: {
        },
        show: function () {
          var count = 1;
          jQuery('.courier-repeater .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.courier-repeater .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {

        }
    });
</script>