<?php
	$customer = false;
	if( isset($_POST['key']) && isset($_POST['action']) && isset($_POST['id']) && $_POST['key'] == 'edit_popup_content' && $_POST['action'] == 'edit_customer_create_form_popup' ) {
		$customer = get_customer($_POST['id']);
		$sub_customer = get_sub_customers($_POST['id']);
	}

	$immediate_payment = '';
	$credit_payment = '';	
	if($customer->payment_type == 'immediate') {
		$immediate_payment = 'checked';
	}
	if($customer->payment_type == 'credit') {
		$credit_payment = 'checked';
	}

?>
<div class="form-grid">
	<form method="post" name="edit_customer" id="edit_customer" class="popup_form" onsubmit="return false;">
		<div class="form_detail">
			<label>Retailer Name
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="customer_name" name="customer_name" autocomplete="off" value="<?php echo ($customer) ? $customer->name : ''; ?>">
		</div>
		<div class="form_detail">
			<label style="width: 115px;">Retailer Mobile
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="customer_mobile" name="customer_mobile" pattern="[0-9]*" autocomplete="off" value="<?php echo ($customer) ? $customer->mobile : ''; ?>">
		</div>
		<div class="form_detail" style="width: 95%;">
			<label>Retailer Address</label>
			<textarea id="customer_address" name="customer_address"><?php echo ($customer) ? $customer->address : ''; ?></textarea>
		</div>
		<div class="form_detail">
			<label>Type</label>
			<select name="customer_type" id="customer_type" class="customer_type">
				<option value="Retail" <?php echo ($customer && $customer->type == 'Retail') ? 'selected' : ''; ?> >R</option>
				<option value="Wholesale" <?php echo ($customer && $customer->type == 'Wholesale') ? 'selected' : ''; ?>>W</option>
				<option value="Bulk" <?php echo ($customer && $customer->type == 'Bulk') ? 'selected' : ''; ?>>Bulk</option>
			</select>
		</div>
		<div class="form_detail">
			<label>Payment Method</label>
			<div style="margin-top:10px;">
				<input type="radio" name="payment_type" value="immediate" <?php echo $immediate_payment; ?>>Immediate <br>
				<input type="radio" name="payment_type" value="credit" <?php echo $credit_payment; ?>>Credit 
			</div>
		</div>
		<div style="margin-left: 35%;">
			<B> ADD CUSTOMER</B>
		</div>
		<div>
			<div class="form_detail">

				<label style="width: 115px;">Customer Name
					<abbr class="require" title="Required Field">*</abbr>
				</label>
				<input type="text" id="sub_customer_name" name="sub_customer_name"  class="sub_customer_name" autocomplete="off" value="">
				<label style="width: 115px;">Customer Mobile
					<abbr class="require" title="Required Field">*</abbr>
				</label>
				<input type="text" id="sub_customer_mobile" name="sub_customer_mobile" class="sub_customer_mobile" autocomplete="off" value="">
				
			</div>
			<div class="form_detail">
				<label style="width: 115px;">Address
					<abbr class="require" title="Required Field">*</abbr>
				</label>
				<textarea id="sub_customer_addr" name="sub_customer_addr" class="sub_customer_addr"  autocomplete="off" style="width: 50%;" value=""></textarea>
				<input type="hidden" name="sub_customer_randid" class="sub_customer_randid" value=""> 
				<span class="cross_mark" style="display:none;">X</span>
				<button class="add-button" style="float: right;">Add</button>
				<button class="update-button" style="float: right;display:none">Update</button>
			</div>
			<div style="clear:both;"></div>
		</div>

		<div class="form_detail_full ">
			<div class="customer_tab table-simple">
				<table>
					<thead>
						<tr>
							<th>Sno</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Address</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody class="customer_add_list" id="customer_add_list">
						<?php 
							if($sub_customer) {
							
								$i = 1;
								foreach ($sub_customer as $c_value) {
									echo '<tr data-randid='.getToken().' class="customer_table">
											<td class="td_id">'.$i.'</td><input type="hidden" value="'.$c_value->id.'" name="customer_detail['.$i.'][id]" class="sub_id" />
											<td class="td_name">' .$c_value->name. '</td><input type="hidden" value = "'.$c_value->name. '" name="customer_detail['.$i.'][name]" class="sub_cus" />
											<td class="td_mobile">'.$c_value->mobile.' </td><input type="hidden" value="'.$c_value->mobile. '" name="customer_detail['.$i.'][mobile]" class="sub_mob"/>
											<td class="td_addr">'.$c_value->address. '</td><input type="hidden" value="'.$c_value->address.'" name = "customer_detail['.$i.'][address]" class="sub_addr" />
											<td><span class="sub_edit">Edit</span> | <span class="sub_delete">Delete</span></td>
										</tr>';
									$i++;
								}
								
							}
						?>
					</tbody>

				</table>
			</div>
		</div>
		<div class="button_sub">
			<input type="hidden" name="customer_id" id="customer_id" value="<?php echo $_POST['id']; ?>">
			<input type="hidden" name="roll_id" id="roll_id" value="<?php echo $_POST['roll_id']; ?>">
			<button type="submit" name="edit_customer_list" id="btn_submit" class="submit-button">Submit</button>
		</div>
	</form>
</div>