<style type="text/css">

</style>
<div class="form-grid">
	<form method="post" name="add_lot" id="add_lot" class="popup_form" onsubmit="return false;">
		<div class="form_detail">
			<label>Enter Lot
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="lot_number" name="lot_number" autocomplete="off">
		</div>
		<div class="form_detail">
			<label style="width: 115px;">Product Name 
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" id="brand_name" name="brand_name" autocomplete="off">
		</div>
		<div class="form_detail">
			<label>Product Type
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="text" name="product_name" id="product_name">
		</div>
		<div class="form_detail" style="display:none;">
			<label style="width: 115px;">Pieces
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<input type="hidden" name="weight" value="1">
		</div>

		<div class="form_detail">
			<label>
				Stock Alert (Pieces)
			</label>
			<div class="slab">
				<input type="text" name="stock_alert" class="stock_alert" autocomplete="off" value="1">

				<input type="text" name="product_name1" id="product_name1" style="display:none;">
				<input type="hidden" name="slab_system" id="slab_system" value="1">
			</div>
		</div>

		<div class="form_detail">
			<label>
				Basic Price (Rs)
			</label>
			<div class="slab">
				<input type="text" name="basic_price" class="basic_price" autocomplete="off" value="">
			</div>
		</div>
		<div class="form_detail">
			<label>
				CGST (%)
			</label>
			<div class="slab">
				<input type="text" name="cgst" class="cgst" autocomplete="off" value="0">
			</div>
		</div>
		<div class="form_detail">
			<span style="margin-top: 10px;margin-right: 25px;">
				<input type="radio" name="gst" value="sgst" checked> SGST &nbsp;&nbsp;
				<input type="radio" name="gst" value="igst"> IGST
			</span>
			<span class="slab" style="margin-top: 10px;margin-right: 25px;">
				<input type="text" name="gst_value" class="gst_value" autocomplete="off" value="0">
			</span>
		</div>
		<div class="form_detail">
			<label>
				HSN Code
			</label>
			<div class="slab">
				<input type="text" name="hsn" class="hsn" autocomplete="off" value="">
			</div>
		</div>

		<div class="form_detail" style="display:none;">
			<label>Consider Bag weight?
				<abbr class="require" title="Required Field">*</abbr>
			</label>
			<div style="float:right;margin-top: 10px;margin-right: 25px;" class="bagweight">
				<input type="radio" name="bag_weight" class="bag_weight" value="1" checked> Yes &nbsp;&nbsp;
				<input type="radio" name="bag_weight" class="bag_weight" value="0"> No
			</div>

		</div>

		<div style="clear:both;"></div>
		<div class="table-simple price_range" style="width: 97%;">
			<h3>Retail Sale Price Range</h3>


				<div class="retail-repeater group_retail"  style="display:block;">
				  	<div data-repeater-list="group_retail" class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">S.No</div>
						    <div class="div-table-head">From Pieces</div>
						    <div class="div-table-head">To Pieces</div>
						    <div class="div-table-head">Price</div>
						    <div class="div-table-head">Option</div>
						</div>

				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

				    </div>
				    	<ul class="icons-labeled">
							<li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add Price Range Retail Sale</a></li>
						</ul>
				</div>



				<div class="group_retail_no_slab" style="display:none;">
				  	<div class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">From Pieces</div>
						    <div class="div-table-head">To Pieces</div>
						    <div class="div-table-head">Price</div>
						</div>

				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_retail_no_slab" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_retail_no_slab" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_retail_no_slab" class="price" autocomplete="off">
						    </div>
				        </div>

				    </div>
				</div>


			<h3>Wholesale Price Range</h3>

				<div class="retail-wholesale group_wholesale"  style="display:block;">
				  	<div data-repeater-list="group_wholesale" class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">S.No</div>
						    <div class="div-table-head">From Pieces</div>
						    <div class="div-table-head">To Pieces</div>
						    <div class="div-table-head">Price</div>
						    <div class="div-table-head">Option</div>
						</div>

				    	<div data-repeater-item class="repeterin div-table-row">
							<div class="div-table-col rowno">1</div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price" class="price" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
						    	<input type="hidden" value="Delete"/>
						    </div>
				        </div>

				    </div>
						<ul class="icons-labeled">
							<li><a href="javascript:void(0);" id="add_new_price_range2" data-repeater-create><span class="icon-block-color add-c"></span>Add Price Range Wholesale</a></li>
						</ul>
				</div>

		
				<div class="wholesale_no_slab" style="display:none;">
				  	<div class="div-table">

					    <div class="div-table-row">
						    <div class="div-table-head">From Pieces</div>
						    <div class="div-table-head">To Pieces</div>
						    <div class="div-table-head">Price</div>
						</div>

				    	<div data-repeater-item class="repeterin div-table-row">
						    <div class="div-table-col">
						    	<input type="text" name="weight_from_wholesale_no_slab" class="weight_from" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="weight_to_wholesale_no_slab" class="weight_to" autocomplete="off">
						    </div>
						    <div class="div-table-col">
						    	<input type="text" name="price_wholesale_no_slab" class="price" autocomplete="off">
						    </div>
				        </div>

				    </div>
				</div>

		</div>


			<div style="clear:both;"></div>


			<div class="dummy_slot_number" style="display:block; margin-top:20px;">
				<div class="form_detail">
					<label>Dummy Lot Number
						<abbr class="require" title="Required Field">*</abbr>
					</label>
					<input type="text" id="dummy_slot_number" name="dummy_slot_number" autocomplete="off">
				</div>

				<div class="form_detail">
					<label>Slab System ?
						<abbr class="require" title="Required Field">*</abbr>
					</label>
					<div style="float:right;margin-top: 10px;margin-right: 25px;" class="slab">
						<input type="radio" name="dummy_slab_system" class="dummy_slab_system" value="1" checked> Yes &nbsp;&nbsp;
						<input type="radio" name="dummy_slab_system" class="dummy_slab_system" value="0"> No
					</div>
				</div>

				<div style="clear:both;"></div>

				<div class="table-simple price_range" style="width: 97%;">
					<h3>Retail Sale Price Range</h3>


					<div class="retail-repeater-dummy group_retail_dummy">
					  	<div data-repeater-list="group_dummy_retail" class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">S.No</div>
							    <div class="div-table-head">From Pieces</div>
							    <div class="div-table-head">To Pieces</div>
							    <div class="div-table-head">Price</div>
							    <div class="div-table-head">Option</div>
							</div>

					    	<div data-repeater-item class="repeterin div-table-row">
								<div class="div-table-col rowno">1</div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="price" class="price" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
							    	<input type="hidden" value="Delete"/>
							    </div>
					        </div>

					    </div>
					    	<ul class="icons-labeled">
								<li><a data-repeater-create href="javascript:void(0);" id="add_new_price_range"><span class="icon-block-color add-c"></span>Add Price Range Retail Sale</a></li>
							</ul>
					</div>

					<div class="retail_no_slab_dummy" style="display:none;">
					  	<div class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">From Pieces</div>
							    <div class="div-table-head">To Pieces</div>
							    <div class="div-table-head">Price</div>
							</div>

					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_retail_no_slab" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_retail_no_slab" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_retail_no_slab" class="price" autocomplete="off">
							    </div>
					        </div>

					    </div>
					</div>

					<h3>Wholesale Price Range</h3>
					<div class="retail-wholesale-dummy group_wholesale_dummy">
					  	<div data-repeater-list="group_dummy_wholesale" class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">S.No</div>
							    <div class="div-table-head">From Pieces</div>
							    <div class="div-table-head">To Pieces</div>
							    <div class="div-table-head">Price</div>
							    <div class="div-table-head">Option</div>
							</div>

					    	<div data-repeater-item class="repeterin div-table-row">
								<div class="div-table-col rowno">1</div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_from" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="weight_to" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="price" class="price" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<a href="#" data-repeater-delete style="font-size: 16px; font-weight: bold; color: #ff0000;" class="remove_price_range" data-id="2">x</a>
							    	<input type="hidden" value="Delete"/>
							    </div>
					        </div>

					    </div>
							<ul class="icons-labeled">
								<li><a href="javascript:void(0);" id="add_new_price_range2" data-repeater-create><span class="icon-block-color add-c"></span>Add Price Range Wholesale</a></li>
							</ul>
					</div>


					<div class="wholesale_no_slab_dummy" style="display:none;">
					  	<div class="div-table">

						    <div class="div-table-row">
							    <div class="div-table-head">From Pieces</div>
							    <div class="div-table-head">To Pieces</div>
							    <div class="div-table-head">Price</div>
							</div>

					    	<div data-repeater-item class="repeterin div-table-row">
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_from_wholesale_no_slab" class="weight_from" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_to_wholesale_no_slab" class="weight_to" autocomplete="off">
							    </div>
							    <div class="div-table-col">
							    	<input type="text" name="bag_weight_price_wholesale_no_slab" class="price" autocomplete="off">
							    </div>
					        </div>

					    </div>
					</div>



				</div>
			</div>



		<div class="button_sub">
			<button type="submit" name="new_customer_list" id="btn_submit" class="submit-button">Submit</button>
		</div>
	</form>



</div>


<script type="text/javascript">


    jQuery('.retail-repeater').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                javascriptQuery('.retail-repeater .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
            }
        },
        ready: function (setIndexes) {

        }
    });

    jQuery('.retail-wholesale').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-wholesale .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-wholesale .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {
        }
    });







    /*second set*/

    jQuery('.retail-repeater-dummy').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-repeater-dummy .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-repeater-dummy .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {

        }
    });

    jQuery('.retail-wholesale-dummy').repeater({
        defaultValues: {
            'textarea-input': 'foo',
            'text-input': 'bar',
            'select-input': 'B',
            'checkbox-input': ['A', 'B'],
            'radio-input': 'B'
        },
        show: function () {
          var count = 1;
          jQuery('.retail-wholesale-dummy .repeterin').each(function(){
            jQuery(this).find('.rowno').text(count);
            count++;
          })
          jQuery(this).slideDown();
        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);
                var count = 1;
                jQuery('.retail-wholesale-dummy .repeterin').each(function(){ 
                  jQuery(this).find('.rowno').text(count);
                  count++;
                })
                
            }
        },
        ready: function (setIndexes) {
        }
    });




    jQuery('.price').on('change', function(){
    	if( jQuery('[name="basic_price"]').val() == '' ) {

    		jQuery('[name="basic_price"]').val(jQuery(this).val());
    		//jQuery('[name="basic_price"]').val( jQuery('[name="price_retail_no_slab"]').val() )
    	}
    });



</script>