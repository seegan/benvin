<?php
function customer_list_pagination($args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'customers';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} WHERE active = 1 and retailer_id = '0' ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);


    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'customer_list_filter') {
        $ppage = $_POST['per_page'];
        $customer_name = $_POST['customer_name'];
        $customer_mobile = $_POST['customer_mobile'];
        $customer_type = $_POST['customer_type'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $customer_name = isset( $_GET['customer_name'] ) ? $_GET['customer_name']  : '';
        $customer_mobile = isset( $_GET['customer_mobile'] ) ? $_GET['customer_mobile']  : '';
        $customer_type = isset( $_GET['customer_type'] ) ? $_GET['customer_type']  : '';
    }

    $page_arg = [];
    if($customer_name != '') {
        $page_arg['customer_name'] = $customer_name;
    }
    if($customer_mobile != '') {
        $page_arg['customer_mobile'] = $customer_mobile;
    }
    if($customer_type != '-') {
        $page_arg['customer_type'] = $customer_type;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];

    /*End Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=customer')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}


function employee_list_pagination($args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'employees';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ( SELECT *, CONCAT('EMP', id) as employee_id FROM ${table} ) as e  WHERE e.active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']     = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);

    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'employee_list_filter') {
        $ppage = $_POST['per_page'];
        $emp_no = $_POST['emp_no'];
        $emp_name = $_POST['emp_name'];
        $emp_mobile = $_POST['emp_mobile'];
        $emp_salary = $_POST['emp_salary'];
        $join_from = $_POST['join_from'];
        $join_to = $_POST['join_to'];
        $emp_status = $_POST['emp_status'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $emp_no = isset( $_GET['emp_no'] ) ? $_GET['emp_no']  : '';
        $emp_name = isset( $_GET['emp_name'] ) ? $_GET['emp_name']  : '';
        $emp_mobile = isset( $_GET['emp_mobile'] ) ? $_GET['emp_mobile']  : '';
        $emp_salary = isset( $_GET['emp_salary'] ) ? $_GET['emp_salary']  : '';
        $join_from = isset( $_GET['join_from'] ) ? $_GET['join_from']  : '';
        $join_to = $_POST['join_to'];
        $emp_status = $_POST['emp_status'];
    }

    $page_arg = [];
    if($emp_no != '') {
        $page_arg['emp_no'] = $emp_no;
    }
    if($emp_name != '') {
        $page_arg['emp_name'] = $emp_name;
    }
    if($emp_mobile != '') {
        $page_arg['emp_mobile'] = $emp_mobile;
    }
    if($emp_salary != '') {
        $page_arg['emp_salary'] = $emp_salary;
    }
    if($join_from != '') {
        $page_arg['join_from'] = $join_from;
    }
    if($join_to != '') {
        $page_arg['join_to'] = $join_to;
    }

    if($emp_status != '-') {
        $page_arg['customer_type'] = $emp_status;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];

    /*End Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));
        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=employee_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}
function employee_attendance_list_pagination($args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'employees';
    $attendance_table = $wpdb->prefix.'employee_attendance';
    $customPagHTML      = "";
    $attendance_date = $args['attendance_date'];

    $query = " SELECT ADDTIME(work_time,next_work_time) as final_timing, fftab.* from 
(SELECT TIMEDIFF(empout,empin) as work_time,TIMEDIFF(empnextout,empnextin) as next_work_time, ff.* from ( SELECT f.*, (CASE WHEN f.attendance_today IS Null THEN 0 ELSE f.attendance_today END) as att from ( SELECT e.*, CONCAT('EMP', id) as employee_id, ( SELECT ea.emp_attendance FROM ${attendance_table} ea WHERE ea.emp_id = e.id AND DATE(ea.attendance_date) = '${attendance_date}' AND active = 1 LIMIT 1 ) AS attendance_today , ( SELECT ea.emp_outtime FROM ${attendance_table} ea WHERE ea.emp_id = e.id AND DATE(ea.attendance_date) = '${attendance_date}' AND active = 1 LIMIT 1 ) AS empout, ( SELECT ea.emp_nextouttime FROM ${attendance_table} ea WHERE ea.emp_id = e.id AND DATE(ea.attendance_date) = '${attendance_date}' AND active = 1 LIMIT 1 ) AS empnextout, ( SELECT ea.emp_nextintime FROM ${attendance_table} ea WHERE ea.emp_id = e.id AND DATE(ea.attendance_date) = '${attendance_date}' AND active = 1 LIMIT 1 ) AS empnextin, ( SELECT ea.emp_intime FROM ${attendance_table} ea WHERE ea.emp_id = e.id AND DATE(ea.attendance_date) = '${attendance_date}' AND active = 1 LIMIT 1 ) AS empin FROM ${table} AS e WHERE DATE(e.emp_joining) <= '${attendance_date}' ) as f )as ff ) as fftab WHERE fftab.active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";


    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);


    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'attendance_list_filter') {
        $ppage = $_POST['per_page'];
        $emp_no = $_POST['emp_no'];
        $emp_name = $_POST['emp_name'];
        $attendance_date = ($_POST['attendance_date'] != '') ? $_POST['attendance_date'] : date("Y-m-d", time());
        $attendance_status = $_POST['attendance_status'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $emp_no = isset( $_GET['emp_no'] ) ? $_GET['emp_no']  : '';
        $emp_name = isset( $_GET['emp_name'] ) ? $_GET['emp_name']  : '';
        $attendance_date = isset( $_GET['attendance_date'] ) ? $_GET['attendance_date']  : date("Y-m-d", time());
        $attendance_status = isset( $_GET['attendance_status'] ) ? $_GET['attendance_status']  : '-';
    }

    $page_arg = [];
    if($emp_no != '') {
        $page_arg['emp_no'] = $emp_no;
    }
    if($emp_name != '') {
        $page_arg['emp_name'] = $emp_name;
    }
    if($emp_mobile != '') {
        $page_arg['attendance_date'] = $attendance_date;
    }
    if($emp_status != '-') {
        $page_arg['attendance_status'] = $attendance_status;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];

    /*End Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));
        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=attendance_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}


function lot_list_pagination( $args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'lots';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} WHERE active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);



    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'lot_list_filter') {
        $ppage = $_POST['per_page'];
        $lot_number = $_POST['lot_number'];
        $search_brand = $_POST['search_brand'];
        $search_product = $_POST['search_product'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $lot_number = isset( $_GET['lot_number'] ) ? $_GET['lot_number']  : '';
        $search_brand = isset( $_GET['search_brand'] ) ? $_GET['search_brand']  : '';
        $search_product = isset( $_GET['search_product'] ) ? $_GET['search_product']  : '';
    }

    $page_arg = [];
    if($lot_number != '') {
        $page_arg['lot_number'] = $lot_number;
    }
    if($search_brand != '') {
        $page_arg['search_brand'] = $search_brand;
    }
    if($search_product != '') {
        $page_arg['search_product'] = $search_product;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];

    /*End Updated for filter 11/10/16*/

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=stock')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}


function stock_list_pagination( $args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'stock';
    $lot_table =  $wpdb->prefix.'lots';
    $customPagHTML      = "";
    $query              = "SELECT s.*, l.lot_number, l.brand_name, l.product_name FROM ${table} as s JOIN ${lot_table} as l ON s.lot_id = l.id  WHERE s.active = 1 AND l.active = 1 AND l.lot_type = 'original' ${args['condition']}";

    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);

    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'stock_list_filter') {
        $ppage = $_POST['per_page'];
        $lot_number = $_POST['lot_number'];
        $search_brand = $_POST['search_brand'];
        $search_product = $_POST['search_product'];
        $search_vendor = $_POST['search_vendor'];
        $search_from = $_POST['search_from'];
        $search_to = $_POST['search_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $lot_number = isset( $_GET['lot_number'] ) ? $_GET['lot_number']  : '';
        $search_brand = isset( $_GET['search_brand'] ) ? $_GET['search_brand']  : '';
        $search_product = isset( $_GET['search_product'] ) ? $_GET['search_product']  : '';
        $search_vendor = isset( $_GET['search_vendor'] ) ? $_GET['search_vendor']  : '';
        $search_from = isset( $_GET['search_from'] ) ? $_GET['search_from']  : '';
        $search_to = isset( $_GET['search_to'] ) ? $_GET['search_to']  : '';        
    }

    $page_arg = [];
    if($lot_number != '') {
        $page_arg['lot_number'] = $lot_number;
    }
    if($search_brand != '') {
        $page_arg['search_brand'] = $search_brand;
    }
    if($search_product != '') {
        $page_arg['search_product'] = $search_product;
    }
    if($search_vendor != '') {
        $page_arg['search_vendor'] = $search_vendor;
    }
    if($search_from != '') {
        $page_arg['search_from'] = $search_from;
    }
    if($search_to != '') {
        $page_arg['search_to'] = $search_to;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];

    /*End Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg, admin_url('admin.php?page=list_stocks')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}





function billing_list_pagination( $args ) {

    global $wpdb;
    $sale_table =  $wpdb->prefix.'sale';
    $customers_table =  $wpdb->prefix.'customers';
    $customPagHTML      = "";
    $query = "SELECT s.*, c.name, c.type, c.mobile FROM ${sale_table} as s LEFT JOIN ${customers_table} as c ON s.customer_id = c.id WHERE s.active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";

    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']     = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );
    $totalPage          = ceil($total / $args['items_per_page']);


    /*Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'bill_list_filter') {
        $ppage = $_POST['per_page'];
        $invoice_no = $_POST['invoice_no'];
        $customer_name = $_POST['customer_name'];
        $bill_total = $_POST['bill_total'];
        
        $customer_type = $_POST['customer_type'];
        $current_user = $_POST['current_user'];
        $delivery = $_POST['delivery'];
        $payment_done = $_POST['payment_done'];

        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $invoice_no = isset( $_GET['invoice_no'] ) ? $_GET['invoice_no']  : '';
        $customer_name = isset( $_GET['customer_name'] ) ? $_GET['customer_name']  : '';
        $current_user = isset( $_GET['current_user'] ) ? $_GET['current_user']  : '-';
        $bill_total = isset( $_GET['bill_total'] ) ? $_GET['bill_total']  : '';
        
        $customer_type = isset( $_GET['customer_type'] ) ? $_GET['customer_type']  : '-';
        $delivery = isset( $_GET['delivery'] ) ? $_GET['delivery']  : '-';
        $payment_done = isset( $_GET['payment_done'] ) ? $_GET['payment_done']  : '-';

        $date_from = isset( $_GET['date_from'] ) ? $_GET['date_from']  : '';
        $date_to = isset( $_GET['date_to'] ) ? $_GET['date_to']  : '';
    }

    $page_arg = [];
    if($invoice_no != '') {
        $page_arg['invoice_no'] = $invoice_no;
    }
    if($customer_name != '') {
        $page_arg['customer_name'] = $customer_name;
    }
    if($current_user != '-') {
        $page_arg['current_user'] = $current_user;
    }
    if($bill_total != '') {
        $page_arg['bill_total'] = $bill_total;
    }
    if($customer_type != '-') {
        $page_arg['customer_type'] = $customer_type;
    }
    if($delivery != '-') {
        $page_arg['delivery'] = $delivery;
    }
    if($payment_done != '-') {
        $page_arg['payment_done'] = $payment_done;
    }
    if($date_from != '') {
        $page_arg['date_from'] = $date_from;
    }
    if($date_to != '') {
        $page_arg['date_to'] = $date_to;
    }    
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];



    /*End Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=sales_others')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}



function employee_salary_list_pagination( $args ) {

    global $wpdb;
    $employee_table =  $wpdb->prefix.'employees';
    $salary_table =  $wpdb->prefix.'employee_salary';
    $customPagHTML      = "";
    $query = "SELECT f.* from ( SELECT es.*, CONCAT('EMP', es.emp_id) as employee_no, e.emp_name, e.emp_mobile, e.emp_current_status from ${salary_table} es join (SELECT max(s1.id) as latest_sal FROM ${salary_table} s1 GROUP BY s1.emp_id) as l ON es.id = l.latest_sal 
    join ${employee_table} e on e.id = es.emp_id ) as f WHERE f.active = 1 ${args['condition']}";

    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";


    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );
    $totalPage         = ceil($total / $args['items_per_page']);


    /*Updated for filter 11/10/16*/
    if(isset($_POST['action']) && $_POST['action'] == 'salary_list_filter') {
        $ppage = $_POST['per_page'];
        $emp_no = $_POST['emp_no'];
        $emp_name = $_POST['emp_name'];
        $emp_mobile = $_POST['emp_mobile'];

        $employee_status = $_POST['attendance_status'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $emp_no = isset( $_GET['emp_no'] ) ? $_GET['emp_no']  : '';
        $emp_name = isset( $_GET['emp_name'] ) ? $_GET['emp_name']  : '';
        $emp_mobile = isset( $_GET['emp_mobile'] ) ? $_GET['emp_mobile']  : '';
        $employee_status = isset( $_GET['attendance_status'] ) ? $_GET['attendance_status']  : '-';
    }

    $page_arg = [];
    if($emp_no != '') {
        $page_arg['emp_no'] = $emp_no;
    }
    if($emp_name != '') {
        $page_arg['emp_name'] = $emp_name;
    }
    if($search_product != '') {
        $page_arg['search_product'] = $search_product;
    }
    if($emp_mobile != '') {
        $page_arg['emp_mobile'] = $emp_mobile;
    }
    if($employee_status != '-') {
        $page_arg['employee_status'] = $employee_status;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=salary_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}




function petty_cash_list_pagination( $args ) {

    global $wpdb;
    $income_table        = $wpdb->prefix.'income_list';
    $table               =  $wpdb->prefix.'petty_cash';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} WHERE active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";

    $status_query       = "SELECT  SUM(cash_amount) as debit FROM (${query}) AS combined_table";
    $data['s_result']   = $wpdb->get_row( $status_query );

    $debit_query        ="SELECT SUM(cash_amount) as credit FROM (SELECT * FROM ${income_table} as income WHERE active = 1 ) AS combined_table";
    $data['d_result']   = $wpdb->get_row( $debit_query);


    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']     = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage          = ceil($total / $args['items_per_page']);


    /*END Updated for filter 11/10/16*/
    if(isset($_POST['action']) && $_POST['action'] == 'petty_cash_list_filter') {
        $ppage = $_POST['per_page'];
        $entry_amount = $_POST['entry_amount'];
        $entry_description = $_POST['entry_description'];
        $entry_date_from = $_POST['entry_date_from'];
        $entry_date_to = $_POST['entry_date_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $entry_amount = isset( $_GET['entry_amount'] ) ? $_GET['entry_amount']  : '';
        $entry_description = isset( $_GET['entry_description'] ) ? $_GET['entry_description']  : '';
        $entry_date_from = isset( $_GET['entry_date_from'] ) ? $_GET['entry_date_from']  : '';
        $entry_date_to = isset( $_GET['entry_date_to'] ) ? $_GET['entry_date_to']  : '';
    }

    $page_arg = [];
    if($entry_amount != '') {
        $page_arg['entry_amount'] = $entry_amount;
    }
    if($entry_description != '') {
        $page_arg['entry_description'] = $entry_description;
    }
    if($entry_date_from != '') {
        $page_arg['entry_date_from'] = $entry_date_from;
    }
    if($entry_date_to != '') {
        $page_arg['entry_date_to'] = $entry_date_to;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=petty_cash')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}

function purchase_list_pagination( $args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'purchase_table';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} WHERE active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);


    /*END Updated for filter 11/10/16*/
    if(isset($_POST['action']) && $_POST['action'] == 'purchase_list_filter') {
        $ppage = $_POST['per_page'];
        $purchase_entry_amount = $_POST['purchase_entry_amount'];
        $purchase_entry_cheque = $_POST['purchase_entry_cheque'];
        $purchase_entry_date_from = $_POST['purchase_entry_date_from'];
        $purchase_entry_date_to = $_POST['purchase_entry_date_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $purchase_entry_amount = isset( $_GET['purchase_entry_amount'] ) ? $_GET['purchase_entry_amount']  : '';
        $purchase_entry_cheque = isset( $_GET['purchase_entry_cheque'] ) ? $_GET['purchase_entry_cheque']  : '';
        $purchase_entry_date_from = isset( $_GET['purchase_entry_date_from'] ) ? $_GET['purchase_entry_date_from']  : '';
        $purchase_entry_date_to = isset( $_GET['purchase_entry_date_to'] ) ? $_GET['purchase_entry_date_to']  : '';
    }

    $page_arg = [];
    if($purchase_entry_amount != '') {
        $page_arg['purchase_entry_amount'] = $purchase_entry_amount;
    }
    if($purchase_entry_cheque != '') {
        $page_arg['purchase_entry_cheque'] = $purchase_entry_cheque;
    }
    if($purchase_entry_date_from != '') {
        $page_arg['purchase_entry_date_from'] = $purchase_entry_date_from;
    }
    if($purchase_entry_date_to != '') {
        $page_arg['purchase_entry_date_to'] = $purchase_entry_date_to;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/


    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=purchase')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}

function income_list_pagination( $args ) {

    global $wpdb;
    $table =  $wpdb->prefix.'income_list';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} as income WHERE active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";


    $status_query        = "SELECT   SUM(cash_amount)  as credit FROM (${query}) AS combined_table";
    $data['s_result']    = $wpdb->get_row( $status_query );


    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']     = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage          = ceil($total / $args['items_per_page']);


    /*END Updated for filter 11/10/16*/
    if(isset($_POST['action']) && $_POST['action'] == 'income_list_filter') {
        $ppage = $_POST['per_page'];
        $entry_amount = $_POST['entry_amount'];
        $entry_description = $_POST['entry_description'];
        $entry_date_from = $_POST['entry_date_from'];
        $entry_date_to = $_POST['entry_date_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $entry_amount = isset( $_GET['entry_amount'] ) ? $_GET['entry_amount']  : '';
        $entry_description = isset( $_GET['entry_description'] ) ? $_GET['entry_description']  : '';
        $entry_date_from = isset( $_GET['entry_date_from'] ) ? $_GET['entry_date_from']  : '';
        $entry_date_to = isset( $_GET['entry_date_to'] ) ? $_GET['entry_date_to']  : '';
    }

    $page_arg = [];
    if($entry_amount != '') {
        $page_arg['entry_amount'] = $entry_amount;
    }
    if($entry_description != '') {
        $page_arg['entry_description'] = $entry_description;
    }
    if($entry_date_from != '') {
        $page_arg['entry_date_from'] = $entry_date_from;
    }
    if($entry_date_to != '') {
        $page_arg['entry_date_to'] = $entry_date_to;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=income_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}



function employee_salary_detail_pagination( $args ) {

    global $wpdb;
    $employee_table =  $wpdb->prefix.'employees';
    $employee_salary =  $wpdb->prefix.'employee_salary';
    $customPagHTML      = "";
    
    $query              = "SELECT es.*, e.emp_name, e.emp_mobile, CONCAT('EMP', es.emp_id) as empp_id FROM ${employee_salary} es JOIN ${employee_table} e ON es.emp_id = e.id WHERE es.active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";

    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( array('cpage' => '%#%', 'ppage' => $args['items_per_page'] ) , admin_url('admin.php?page=salary_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}




function employee_attendance_detail_pagination( $args ) {

    global $wpdb;
    $employee_table =  $wpdb->prefix.'employees';
    $employee_attendance =  $wpdb->prefix.'employee_attendance';
    $customPagHTML      = "";
    
    $query              = "SELECT ADDTIME(working_hours,next_working_hours) AS final_hours,tab.* FROM (
        SELECT TIMEDIFF(ea.emp_outtime,ea.emp_intime) as working_hours,TIMEDIFF(ea.emp_nextouttime,ea.emp_nextintime) as next_working_hours, ea.*, e.emp_name, e.emp_mobile, CONCAT('EMP', e.id) as empp_id,
        CASE 
        WHEN ea.emp_attendance = 1
        THEN 'Present'
        ELSE 'Absent' END as attendance
        FROM ${employee_attendance} ea JOIN ${employee_table} e ON ea.emp_id = e.id ) as tab WHERE tab.active = 1 ${args['condition']}";
    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";

    $status_query        = "SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `final_hours` ) ) ) as working_hours_total FROM (${query}) AS combined_table";
    $data['s_result']    = $wpdb->get_row( $status_query );

    $count_query        = "SELECT  count(CASE WHEN emp_attendance = 1 THEN 1 end) as count_present FROM (${query}) AS combined_table";
    $data['count_presentas']    = $wpdb->get_row( $count_query );

    $days_query        = "SELECT  SEC_TO_TIME( TIME_TO_SEC( '09:00:00' ) * count_present) as time FROM (${count_query}) AS combined_table";
    $data['days_time']    = $wpdb->get_row( $days_query );

//     $date_diff        = "SELECT   TIMEDIFF(count_present ,time) as diff_date FROM (${days_query}) AS combined_table";
//     $data['diff_date_query']    = $wpdb->get_row( $date_diff );
// var_dump($date_diff);


    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));
        
        $pagination = paginate_links( array(
                'base' => add_query_arg( array('cpage' => '%#%', 'ppage' => $args['items_per_page'] ) , admin_url('admin.php?page=salary_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}


function stock_detail_list_pagination( $args ) {

    global $wpdb;
    $lots_table = $wpdb->prefix. 'lots';
    $sale_detail = $wpdb->prefix.'sale_detail';
    $stock_detail = $wpdb->prefix.'stock';
    $customPagHTML      = "";
    $query              = "SELECT * FROM (SELECT lot.*, (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  as sale_tot, (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) stock_tot,
    
    ( (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) - (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  ) as bal_stock
    FROM 
    (
        SELECT l.id, l.lot_number, l.brand_name, l.product_name,  
        (CASE 
            WHEN l.parent_id = 0 
            THEN l.id
            ELSE l.parent_id
         END ) as parent_id
        FROM ${lots_table} l WHERE l.active = 1
    ) 
    lot LEFT JOIN 
    (
        SELECT s.lot_parent_id as sale_lot_id, SUM(s.sale_weight) as sale_total FROM ${sale_detail} s WHERE s.active = 1 AND s.bill_type = 'original' AND s.item_status = 'open' GROUP BY s.lot_parent_id
    ) 
    sale ON lot.parent_id = sale.sale_lot_id LEFT JOIN 
    (
        SELECT s1.lot_id as stock_lot_id, SUM(s1.total_weight) as stock_total FROM ${stock_detail} s1 WHERE s1.active = 1 GROUP BY s1.lot_id    
    ) 
    stock ON lot.parent_id = stock.stock_lot_id ) as lo  WHERE lo.id = lo.parent_id ${args['condition']}";


    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";
    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);


    /*END Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'stock_report_list') {
        $ppage = $_POST['per_page'];
        $lot_number = $_POST['lot_number'];
        $search_brand = $_POST['search_brand'];
        $search_product = $_POST['search_product'];
        $stock_total = $_POST['stock_total'];
        $sale_total = $_POST['sale_total'];
        $stock_bal = $_POST['stock_bal'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $lot_number = isset( $_GET['lot_number'] ) ? $_GET['lot_number']  : '';
        $search_brand = isset( $_GET['search_brand'] ) ? $_GET['search_brand']  : '';
        $search_product = isset( $_GET['search_product'] ) ? $_GET['search_product']  : '';
        $stock_total = isset( $_GET['stock_total'] ) ? $_GET['stock_total']  : '';
        $sale_total = isset( $_GET['sale_total'] ) ? $_GET['sale_total']  : '';
        $stock_bal = isset( $_GET['stock_bal'] ) ? $_GET['stock_bal']  : '';
    }


    $page_arg = [];
    if($lot_number != '') {
        $page_arg['lot_number'] = $lot_number;
    }
    if($search_brand != '') {
        $page_arg['search_brand'] = $search_brand;
    }
    if($search_product != '') {
        $page_arg['search_product'] = $search_product;
    }
    if($stock_total != '') {
        $page_arg['stock_total'] = $stock_total;
    }
    if($sale_total != '') {
        $page_arg['sale_total'] = $sale_total;
    }
    if($stock_bal != '') {
        $page_arg['stock_bal'] = $stock_bal;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=report_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;
}





function sale_detail_list_pagination($args) {

    global $wpdb;
    $lots_table = $wpdb->prefix. 'lots';
    $sale_table = $wpdb->prefix.'sale';
    $sale_detail = $wpdb->prefix.'sale_detail';
    $customPagHTML      = "";


/*SELECT sale.*, l.lot_number, l.brand_name, l.product_name
FROM
(    SELECT 
    s.id as sale_id, s.invoice_id, s.customer_id, s.order_shop, s.customer_type, s.invoice_date, s.invoice_status, s.active as invoice_active, 
    sd.id as sale_detail_id, sd.lot_id, sd.lot_parent_id, sd.sale_type, sd.sale_weight, sd.unit_price, sd.sale_value, sd.sale_tax, sd.bill_type, sd.lot_type, sd.item_status, sd.made_by, sd.active as sale_detail_active 
    FROM wp_sale_detail as sd 
    JOIN wp_sale as s 
    ON s.id = sd.sale_id 
    WHERE ( sd.active = 1 OR sd.item_status = 'return' )
) as sale LEFT JOIN wp_lots l ON l.id = sale.lot_parent_id WHERE 1 = 1
*/

    $query = "SELECT sale.*, l.lot_number, l.brand_name, l.product_name, SUM(sale.sale_weight) as tot_weight, SUM(sale.sale_value) as tot_sale_value, COUNT(1) as tot_item
FROM
(    SELECT 
    s.id as sale_id, s.order_shop, s.customer_type, s.invoice_date, s.invoice_status, s.active as invoice_active, 
    sd.id as sale_detail_id, sd.lot_id, sd.lot_parent_id, sd.sale_type, sd.sale_weight, sd.unit_price, sd.sale_value, sd.sale_tax, sd.bill_type, sd.bill_from, sd.lot_type, sd.item_status, sd.made_by, sd.active as sale_detail_active 
    FROM ${sale_detail} as sd 
    JOIN ${sale_table} as s 
    ON s.id = sd.sale_id 
    WHERE ( sd.active = 1 OR sd.item_status = 'return' )
) as sale LEFT JOIN ${lots_table} l ON l.id = sale.lot_parent_id 
WHERE 1 = 1 ${args['condition']} GROUP BY item_status, bill_type, lot_parent_id ";



/*    $query ="SELECT sale.*, l.lot_number, l.brand_name, l.product_name
FROM
(    SELECT 
    s.id as sale_id, s.invoice_id, s.customer_id, s.order_shop, s.customer_type, s.invoice_date, s.invoice_status, s.active as invoice_active, 
    sd.id as sale_detail_id, sd.lot_id, sd.lot_parent_id, sd.sale_type, sd.sale_weight, sd.unit_price, sd.sale_value, sd.sale_tax, sd.bill_type, sd.lot_type, sd.item_status, sd.made_by, sd.active as sale_detail_active 
    FROM ${sale_detail} as sd 
    JOIN ${sale_table} as s 
    ON s.id = sd.sale_id 
    WHERE ( sd.active = 1 OR sd.item_status = 'return' )
) as sale LEFT JOIN ${lots_table} l ON l.id = sale.lot_parent_id WHERE 1 = 1 ${args['condition']}";*/

    $total_query        = "SELECT COUNT(1) FROM (${query}) AS combined_table";

    $status_query        = "SELECT SUM(tot_weight) as weight_s, SUM(tot_sale_value) as sale_s FROM (${query}) AS combined_table";
    $data['s_result']         = $wpdb->get_row( $status_query );

    $total              = $wpdb->get_var( $total_query );
    $page               = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : abs( (int) $args['page'] );
    $offset             = ( $page * $args['items_per_page'] ) - $args['items_per_page'] ;

    $data['result']         = $wpdb->get_results( $query . "ORDER BY ${args['orderby_field']} ${args['order_by']} LIMIT ${offset}, ${args['items_per_page']}" );

    $totalPage         = ceil($total / $args['items_per_page']);


    /*END Updated for filter 11/10/16*/

    if(isset($_POST['action']) && $_POST['action'] == 'stock_sale_filter_list') {
        $ppage = $_POST['per_page'];
        $lot_number = $_POST['lot_number'];
        $search_brand = $_POST['search_brand'];
        $search_product = $_POST['search_product'];
        $item_status = $_POST['item_status'];
        $bill_type = $_POST['bill_type'];

        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $lot_number = isset( $_GET['lot_number'] ) ? $_GET['lot_number']  : '';
        $search_brand = isset( $_GET['search_brand'] ) ? $_GET['search_brand']  : '';
        $search_product = isset( $_GET['search_product'] ) ? $_GET['search_product']  : '';
        $item_status = isset( $_GET['item_status'] ) ? $_GET['item_status']  : '-';
        $bill_type = isset( $_GET['bill_type'] ) ? $_GET['bill_type']  : '-';

        $date_from = isset( $_GET['date_from'] ) ? $_GET['date_from']  : '';
        $date_to = isset( $_GET['date_to'] ) ? $_GET['date_to']  : '';
    }


    $page_arg = [];
    if($lot_number != '') {
        $page_arg['lot_number'] = $lot_number;
    }
    if($search_brand != '') {
        $page_arg['search_brand'] = $search_brand;
    }
    if($search_product != '') {
        $page_arg['search_product'] = $search_product;
    }
    if($date_from != '') {
        $page_arg['date_from'] = $date_from;
    }
    if($date_to != '') {
        $page_arg['date_to'] = $date_to;
    }
    if($item_status != '-') {
        $page_arg['item_status'] = $item_status;
    }
    if($bill_type != '-') {
        $page_arg['bill_type'] = $bill_type;
    }
    $page_arg['cpage'] = '%#%';
    $page_arg['ppage'] = $args['items_per_page'];
    /*END Updated for filter 11/10/16*/

    if($totalPage > 1){
        $data['start_count'] = ($ppage * ($page-1));

        $pagination = paginate_links( array(
                'base' => add_query_arg( $page_arg , admin_url('admin.php?page=sale_report_list')),
                'format' => '',
                'type' => 'array',
                'prev_text' => __('prev'),
                'next_text' => __('next'),
                'total' => $totalPage,
                'current' => $page
                )
            );
        if ( ! empty( $pagination ) ) : 
            $customPagHTML .= '<ul class="paginate pag3 clearfix"><li class="single">Page '.$page.' of '.$totalPage.'</li>';
            foreach ($pagination as $key => $page_link ) {
                if( strpos( $page_link, 'current' ) !== false ) {
                    $customPagHTML .=  '<li class="current">'.$page_link.'</li>';
                } else {
                    $customPagHTML .=  '<li>'.$page_link.'</li>';
                }
            }
            $customPagHTML .=  '</ul>';
        endif;
    }

    $data['pagination'] = $customPagHTML;
    return $data;

}











function getStatusCount() {

    global $wpdb;
    $lots_table = $wpdb->prefix. 'lots';
    $sale_detail = $wpdb->prefix.'sale_detail';
    $stock_table = $wpdb->prefix.'stock';
    $customers_table = $wpdb->prefix.'customers';
    $employees_table = $wpdb->prefix.'employees';


    $customPagHTML      = "";

    $count_query = "SELECT avl.avail_stock, unavl.unavail_stock, cus.tot_customers, emp.tot_employees FROM ( SELECT count(1) as     avail_stock FROM ( SELECT * FROM (SELECT lot.*, (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  as sale_tot, ( CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) stock_tot,
    
        ( (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) - (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  ) as bal_stock
        FROM 
        (
            SELECT l.id, l.lot_number, l.brand_name, l.product_name,  
            (CASE 
                WHEN l.parent_id = 0 
                THEN l.id
                ELSE l.parent_id
             END ) as parent_id
            FROM ${lots_table} l WHERE l.active = 1
        ) 
        lot LEFT JOIN 
        (
            SELECT s.lot_parent_id as sale_lot_id, SUM(s.sale_weight) as sale_total FROM ${sale_detail} s WHERE s.active = 1 AND s.bill_type = 'original' AND s.item_status = 'open' GROUP BY s.lot_parent_id
        ) 
        sale ON lot.parent_id = sale.sale_lot_id LEFT JOIN 
        (
            SELECT s1.lot_id as stock_lot_id, SUM(s1.total_weight) as stock_total FROM ${stock_table} s1 WHERE s1.active = 1 GROUP BY s1.lot_id    
        ) 
        stock ON lot.parent_id = stock.stock_lot_id ) as lo  WHERE lo.id = lo.parent_id ) as avail_stock 

        WHERE avail_stock.bal_stock > 0
    ) as avl 

    JOIN

    ( SELECT count(1) as unavail_stock FROM ( SELECT * FROM (SELECT lot.*, (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  as sale_tot, (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) stock_tot,
        
        ( (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) - (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  ) as bal_stock
        FROM 
        (
            SELECT l.id, l.lot_number, l.brand_name, l.product_name,  
            (CASE 
                WHEN l.parent_id = 0 
                THEN l.id
                ELSE l.parent_id
             END ) as parent_id
            FROM ${lots_table} l WHERE l.active = 1
        ) 
        lot LEFT JOIN 
        (
            SELECT s.lot_parent_id as sale_lot_id, SUM(s.sale_weight) as sale_total FROM ${sale_detail} s WHERE s.active = 1 AND s.bill_type = 'original' AND s.item_status = 'open' GROUP BY s.lot_parent_id
        ) 
        sale ON lot.parent_id = sale.sale_lot_id LEFT JOIN 
        (
            SELECT s1.lot_id as stock_lot_id, SUM(s1.total_weight) as stock_total FROM ${stock_table} s1 WHERE s1.active = 1 GROUP BY s1.lot_id    
        ) 
        stock ON lot.parent_id = stock.stock_lot_id ) as lo  WHERE lo.id = lo.parent_id ) as avail_stock 

        WHERE avail_stock.bal_stock <= 0
    ) as unavl 

    ON 1 = 1
    JOIN
    ( SELECT count(1) as tot_customers FROM ${customers_table} c WHERE c.active = 1 ) cus

    ON 1 = 1
    JOIN
    ( SELECT count(1) as tot_employees FROM ${employees_table} e WHERE e.active = 1 AND e.emp_current_status = 1 ) as emp";

    $data['result']         = $wpdb->get_row( $count_query );

    return $data;
}

?>