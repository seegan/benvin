<style>
.stock_ck_avail_box{
    left: 100px;
    right:0px;
}
.lot_search .select2-container {
    width: 123px;
}

.select2-container {
    z-index: 9998;
}
.stock_ck_avail_box{
    width: 50%;
    height: 480px;
}
</style>   
<div class="form-grid">
    <form method="post" name="new_billing" id="new_billing" class="leftLabel" onsubmit="return false;">
        <div class="stock_ck_avail_box">
            
            <div style="padding: 15px;">
                <h2 style="margin-top:5px;">Check Stock Availability</h2>
                <div style="width: 100%; border-bottom: 1px solid #ccc; padding: 5px 0px 15px 0px;" class="lot_search">
                    <b>Filter :</b>&nbsp;
                    <select name="search_lotn" id="search_lotn" class="search_lotn">
                        <option value="-">Lot Name</option>
                    </select>&nbsp;&nbsp;
                    <select name="search_brandn" id="search_brandn" class="search_brandn">
                        <option value="-">Product Name</option>
                    </select>&nbsp;&nbsp;
                    <select name="search_stockn" id="search_stockn" class="search_stockn">
                        <option value="-">Stock Name</option>
                    </select>
                    <!-- <input type="text" name="search_lot_rate" id="search_lot_rate" autocomplete="off" placeholder="Enter Rate"> -->&nbsp;&nbsp;
                    <input name="search_avail_stock" type="button" value="Search" class="submit-button search_avail_stock">
                    <img alt="Loader" src="<?php echo get_template_directory_uri(); ?>/inc/images/ajax-loader.gif" id="search_loader" style="display: none;">
                </div>
            </div>
            <div class="load_stock_available" style="overflow-y: scroll; padding: 10px; height: 250px;">
                <div class="module table-simple">
                    <table class="display">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Lot Name</th>
                                <th>Product </th>
                                <th>Detail</th>
                                <th>Stock Balance(Ps)</th>
                            </tr>
                        </thead>
                        <tbody class="stock_search_filter">
                            <tr>
                                <td colspan="5">Search Details Search</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
</div>
