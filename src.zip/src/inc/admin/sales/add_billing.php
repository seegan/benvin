<style type="text/css">
	.popup_form .form_detail {
	    width: 46%;
	    float: left;
	    margin: 0 10px 10px;
	}
	.form_detail label {
	    width: 115px;
	    float: left;
	    margin: 10px;
	    font-size: 12px;
	    font-weight: bold;
	}
	.form-grid .form_detail input[type="text"] {
	    width: 50%;
	    margin: 5px 0px;
	    float: left;
	    border-radius: 0;
	}
	.form-grid .form_detail textarea {
	    width: 70%;
	    border-radius: 0;
	}
	.button_sub {
	    width: 10%;
	    padding-left: 140px;
	}
</style>






	<?php 
    if( isset($_GET['action']) && $_GET['action'] == 'update' && ( isset($_GET['inv_id']) || isset($_GET['bill_no']) ) ) {
    	$bill_no = isset($_GET['bill_no']) ? $_GET['bill_no'] : $_GET['inv_id'];
    ?>
		<div style="width: 100%;">
			<ul class="icons-labeled">
				<li>
					<a href="<?php echo menu_page_url( 'sales_others', 0 ); ?>" ><span class="icon-block-color coins-c"></span>View Billing</a>
				</li>
				<li>
					<a href="<?php echo menu_page_url( 'new_billing', 0 ).'&bill_no='.$bill_no.'&action=invoice'; ?>" ><span class="icon-block-color invoice-c"></span>View Invoice</a>
				</li>
			</ul>
		</div>
		<div class="widget-top">
			<h4>New Billing</h4>
		</div>
		<!-- <div class="widget-content module table-simple list_customers"> -->
		<div class="widget-content module table-simple add_billing">
    <?php
			include( get_template_directory().'/inc/admin/billing_template/update_billing.php' );
	?>
		</div>
	<?php
    } else if( isset($_GET['action']) && $_GET['action'] == 'invoice' && ( isset($_GET['inv_id']) || isset($_GET['bill_no']) ) ) {
    	$bill_no = isset($_GET['bill_no']) ? $_GET['bill_no'] : $_GET['inv_id'];
    ?>
		<div style="width: 100%;">
			<ul class="icons-labeled" style="width:290px;float:left;">
				<li>
					<a href="<?php echo menu_page_url( 'sales_others', 0 ); ?>" ><span class="icon-block-color coins-c"></span>View Billing</a>
				</li>
				<li>
					<a href="<?php echo menu_page_url( 'new_billing', 0 ); ?>" ><span class="icon-block-color add-c"></span>Add New Billing</a>
				</li>
			</ul>
			<ul class="icons-labeled" style="width: 520px;float:right;">
				<li>
					<a href="<?php echo menu_page_url( 'new_billing', 0 ).'&bill_no='.$bill_no.'&action=update'; ?>" ><span class="icon-block-color updatebill-c"></span>Update Bill</a>
				</li>
				<li>
					<a class="print_bill" data-inv-id="<?php echo $bill_no; ?>" style="cursor: pointer;"><span class="icon-block-black print-c"></span>Print</a>
				</li>
				<li>
					<a href="<?php echo site_url('/download/?invoice_id='.$bill_no); ?>"><span class="icon-block-color pdf-c"></span>Download PDF</a>
				</li>
				<li>
					<a onclick="window.open('https://web.whatsapp.com/', 'whatapp_window', 'width=700,height=700').focus()" ><span class="icon-block-color whatsapp-c"></span></a>
				</li>
				<li>
					<a onclick="window.open('https://web.telegram.org/', 'telegram_window', 'width=700,height=700').focus()" ><span class="icon-block-color telegram-c"></span></a>
				</li>
				<li>
					<a onclick="window.open('https://www.gmail.com/', 'gmail_window', 'width=700,height=700').focus()" ><span class="icon-block-color gmail-c"></span></a>
				</li>
			</ul>
			<div style="clear:both;"></div>
		</div>
		<div class="widget-top">
			<h4>New Billing</h4>
		</div>
		<!-- <div class="widget-content module table-simple list_customers"> -->
		<div class="widget-content module table-simple add_billing">
    <?php
    		include( get_template_directory().'/inc/admin/billing_template/billing_invoice.php' ); 
	?>
		</div>
	<?php
    } else {
    ?>

		<div style="width: 100%;">
			<ul class="icons-labeled">
				<li>
					<a href="<?php echo menu_page_url( 'sales_others', 0 ); ?>" ><span class="icon-block-color coins-c"></span>View Billing</a>
				</li>
				<li>
					<a href="javascript:void(0);" id="my-button" class="popup-add-customer"><span class="icon-block-color add-c"></span>Add New Customer</a>
				</li>
			</ul>
		</div>
		<div class="widget-top">
			<h4>New Billing</h4>
		</div>
		<!-- <div class="widget-content module table-simple list_customers"> -->
		<div class="widget-content module table-simple add_billing">

    <?php
    		include( get_template_directory().'/inc/admin/billing_template/add_billing.php' ); 
    ?>
    	</div>
    <?php
    }
	
?>
