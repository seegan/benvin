<style type="text/css">
	.popup_form .form_detail {
	    width: 46%;
	    float: left;
	    margin: 0 10px 10px;
	}
	.form_detail label {
	    width: 115px;
	    float: left;
	    margin: 10px;
	    font-size: 12px;
	    font-weight: bold;
	}
	.form-grid .form_detail input[type="text"] {
	    width: 50%;
	    margin: 5px 0px;
	    float: left;
	    border-radius: 0;
	}
	.form-grid .form_detail textarea {
	    width: 70%;
	    border-radius: 0;
	}
	.button_sub {
	    width: 10%;
	    padding-left: 140px;
	}
</style>

<?php
 	/*Updated for filter 11/10/16*/
	if(isset($_POST['action']) && $_POST['action'] == 'income_list_filter') {
		$ppage = $_POST['per_page'];
		$entry_amount = $_POST['entry_amount'];
		$entry_description = $_POST['entry_description'];
		$entry_date_from = $_POST['entry_date_from'];
		$entry_date_to = $_POST['entry_date_to'];
	} else {
		$ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
		$entry_amount = isset( $_GET['entry_amount'] ) ? $_GET['entry_amount']  : '';
		$entry_description = isset( $_GET['entry_description'] ) ? $_GET['entry_description']  : '';
		$entry_date_from = isset( $_GET['entry_date_from'] ) ? $_GET['entry_date_from']  : '';
		$entry_date_to = isset( $_GET['entry_date_to'] ) ? $_GET['entry_date_to']  : '';
	}
	/*End Updated for filter 11/10/16*/
?>

<div style="width: 100%;">
	<ul class="icons-labeled">
		<li><a href="javascript:void(0);" id="my-button" class="popup-add-income"><span class="icon-block-color add-c"></span>Add Income</a></li>
	</ul>
</div>
<div class="widget-top">
	<h4>New Billing</h4>
</div>


<div class="search_bar income_filter">
	<label>Page :</label>
	<select name="per_page" id="per_page">
		<option value="5" <?php echo ($ppage == 5) ? 'selected' : ''; ?>>5</option>
		<option value="10" <?php echo ($ppage == 10) ? 'selected' : ''; ?>>10</option>
		<option value="15" <?php echo ($ppage == 15) ? 'selected' : ''; ?>>15</option>

		<option value="20" <?php echo ($ppage == 20) ? 'selected' : ''; ?>>20</option>
		<option value="50" <?php echo ($ppage == 50) ? 'selected' : ''; ?>>50</option>
		<option value="100" <?php echo ($ppage == 100) ? 'selected' : ''; ?>>100</option>
	</select>
	<input type="text" name="entry_amount" id="entry_amount" autocomplete="off" placeholder="Search by Amount" value="<?php echo $entry_amount; ?>">
	<input type="text" name="entry_description" id="entry_description" autocomplete="off" placeholder="Search by Description" value="<?php echo $entry_description; ?>">
	<input type="text" name="entry_date_from" id="entry_date_from" autocomplete="off" placeholder="Date From" value="<?php echo $entry_date_from; ?>">
	<input type="text" name="entry_date_to" id="entry_date_to" autocomplete="off" placeholder="Date To" value="<?php echo $entry_date_to; ?>">
</div>
<div class="widget-content module table-simple list_customers">

<?php 
	include( get_template_directory().'/inc/admin/list_template/list_income.php' ); 
?>
</div>