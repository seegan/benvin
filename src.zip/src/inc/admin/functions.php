<?php

function hide_update_notice()
{
    remove_action( 'admin_notices', 'update_nag', 3 );
}
add_action( 'admin_head', 'hide_update_notice', 1 );


function my_footer_shh() {
	remove_filter( 'update_footer', 'core_update_footer' ); 

// 	remove_submenu_page( 'index.php', 'update-core.php' );
// 	remove_menu_page( 'jetpack' );                    //Jetpack* 
// 	remove_menu_page( 'edit.php' );                   //Posts
// 	remove_menu_page( 'upload.php' );                 //Media
// 	remove_menu_page( 'edit.php?post_type=page' );    //Pages
// 	remove_menu_page( 'admin.php?page=lps_option' );    //Pages
// 	remove_menu_page( 'edit-comments.php' );          //Comments
// 	remove_menu_page( 'themes.php' );                 //Appearance
// 	remove_menu_page( 'plugins.php' );                //Plugins
// /*	remove_menu_page( 'users.php' );                  //Users*/
	remove_menu_page( 'tools.php' );                  //Tools
	//remove_menu_page( 'options-general.php' );        //Settings
}
add_action( 'admin_menu', 'my_footer_shh' );

/*$wp_roles = new WP_Roles();
$wp_roles->remove_role("sales_manager");*/

function load_custom_wp_admin_style() {
	wp_enqueue_style( 'jultra-colors', get_template_directory_uri() . '/inc/css/ultra-colors.css' );
	wp_enqueue_style( 'jultra-admin', get_template_directory_uri() . '/inc/css/ultra-admin.css' );

	wp_enqueue_style( 'jquery-ui', get_template_directory_uri() . '/inc/css/jquery-ui.css' );
	wp_enqueue_style( 'admin-style', get_template_directory_uri() . '/inc/css/admin-css.css' );

	wp_enqueue_script( 'shortcut_script',  get_template_directory_uri() . '/inc/js/shortcut.js', array('jquery'), false, false );
	wp_enqueue_script( 'bpopup', get_template_directory_uri() . '/inc/js/jquery.bpopup.min.js', array('jquery'), false, false );
	wp_enqueue_script( 'custom', get_template_directory_uri() . '/inc/js/script.js', array('jquery'), false, false );
	wp_enqueue_script( 'jquery-ui-js', get_template_directory_uri() . '/inc/js/jquery-ui.js', array('jquery'), false, false );

	wp_localize_script( 'custom', 'home_page', array( 'url' => home_url( '/' ), 'new_billing' => admin_url('admin.php?page=new_billing'), 'billing_list' => admin_url('admin.php?page=sales_others') ));

	wp_enqueue_script( 'jquery-canvas-js', get_template_directory_uri() . '/inc/js/jquery.canvasjs.min.js', array('jquery'), false, false );

}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );







// Admin footer modification
function remove_footer_admin() 
{
	$count_data = getStatusCount();
	$avail_stock = isset($count_data['result']->avail_stock) ? $count_data['result']->avail_stock : 0;
	$unavail_stock = isset($count_data['result']->unavail_stock) ? $count_data['result']->unavail_stock : 0;
	$tot_customers = isset($count_data['result']->tot_customers) ? $count_data['result']->tot_customers : 0;
	$tot_employees = isset($count_data['result']->tot_employees) ? $count_data['result']->tot_employees : 0;

?>
<div class="conform-box1" style="display:none;">Chose the action!</div>
<span id="footer-thankyou">
	<div id="footer-wrap" class="">
		<div id="footer">
			<div class="footer-container">
				<div class="footer-nav">
					<ul>
						<li>
							<a href="<?php echo admin_url('admin.php?page=employee_list')?>">
								<span class="footer-button new-user"></span>Users
								<span class="zero-count"><?php echo $tot_employees; ?></span>
							</a>
						</li>
						<li>
							<a href="<?php echo admin_url('admin.php?page=customer')?>">
								<span class="footer-button new-task"></span> Customer
								<span class="user-counter"><?php echo $tot_customers; ?></span>
							</a>
						</li>
						<li>
							<a href="<?php echo admin_url('admin.php?page=report_list')?>">
								<span class="footer-button new-order"></span>Available Stocks 
								<span class="ticket-counter"><?php echo $avail_stock; ?></span>
							</a>
						</li>
						<li>
							<a href="<?php echo admin_url('admin.php?page=report_list')?>">
								<span class="footer-button open-tickets"></span>Unavailable Stocks 
								<span class="task-counter"><?php echo $unavail_stock; ?></span>
							</a>
						</li>
					</ul>
				</div>
			<div class="copyright">
			© 2016 Billing Admin Panel. All rights reserved.
			</div>
			</div>
		<div id="goTop" style="display: none;" class="">
		<a href="#" class="tip-top">Top</a>
		</div>
		</div>
	</div>
</span>
<?php
}
add_filter('admin_footer_text', 'remove_footer_admin');


add_action('admin_footer', 'src_admin_confirm_box');
function src_admin_confirm_box() {
?>
<button id="my-button">POP IT UP</button>
	<div id="src_info_box" style="display:none;">
		<div class="src-container">
			<div class="src_info_headder">
				<h4 id="popup-title"></h4>
				<div class="src-close">
					<a href="javascript:void(0);" class="simplemodal-close exit-modal">x</a>
				</div>
			</div>
			<div id="popup-content" style="padding:10px;">
				
			</div>
			<button id="my-button1" style="display:none;"></button>
		</div>
	</div>

	<div id="src_info_box_alert" style="display:none;">
		<div class="src-container_alert">
			<div class="src_info_headder_alert">
				<h4 id="popup-title_alert">dfdfgdg</h4>
				<div class="src-close_alert">
					<a href="javascript:void(0);" class="simplemodal-close exit-modal">x</a>
				</div>
			</div>
			<div id="popup-content_alert" style="padding:20px;">
				<div class="err_message" style="display:none;">
					Enter the mandatory fields!!
				</div>
				<div class="succ_message" style="display:none;">
					Enter the mandatory fields!!
				</div>
			</div>

			<div class="buttons">
				<span class="icon-wrap-lb" id="pop_cancel" style="display: none;">
					<a href="#" class="no simplemodal-close" title="Icon Title">
						<span class="icon-block-color cross-c"></span>Cancel
					</a>
				</span>
				<span class="icon-wrap-lb">
					<a href="javascript:void(0)" class="yes" title="Ok">
						<span class="icon-block-color accept-c"></span>
					</a>
				</span>
			</div>
		</div>
	</div>

	<div id="src_info_box_s" style="display:none;">
		<div class="src-container-s">
			<div class="src_info_headder">
				<h4 id="popup-title-s"></h4>
				<div class="src-close-s">
					<a href="javascript:void(0);" class="simplemodal-close exit-modal">x</a>
				</div>
			</div>
			<div id="popup-content-s" style="padding:10px;">
				
			</div>
		</div>
	</div>

<script>
	jQuery('#my-button, .my-button').bind('click', function(e) {
	    e.preventDefault();
	    jQuery('#src_info_box').bPopup({
	        follow: [true, true], //x, y
	        position: ["auto", 60] //x, y
	    });
	}, function() {
		setTimeout(function() {
		  jQuery('#src_info_box').bPopup({
		      follow: [true, true], //x, y
		      position: ["auto", 60] //x, y

		  }).reposition();
		}, 200);
	});

	jQuery('.d-status span').live('click', function(e) {
	    e.preventDefault();
	    jQuery('#src_info_box_s').bPopup();
	}, function() {
		setTimeout(function() {
		    jQuery('#src_info_box_s').bPopup().reposition();
		}, 200);
	});

	jQuery('#my-button1').bind('click', function(e) {
	    e.preventDefault();
	    jQuery('#src_info_box_alert').bPopup();
	}); 
	

	jQuery('.src-close').bind('click', function(e) {
	    jQuery('#src_info_box').bPopup().close();
	});
	jQuery('.src-close_alert, .src-container_alert .buttons').bind('click', function(e) {
	    jQuery('#src_info_box_alert').bPopup().close();
	});
	jQuery('.src-close-s').bind('click', function(e) {
	    jQuery('#src_info_box_s').bPopup().close();
	});

</script>
<?php
	echo $html;
}
	// Alternative solution for loading scripts only in plugin page
	if( (is_admin() ) && (isset($_GET['page'])) /*&& ( $_GET['page'] == 'admin_users' )*/ )   { 
	    // Register scripts and styles
	    add_action('admin_init', 'wp_script_init');
	}  

  	function wp_script_init() {

	  	wp_enqueue_style( 'src-select2', get_template_directory_uri() . '/inc/js/select2/dist/css/select2.min.css' );  
	  	wp_enqueue_style( 'src-chosen-css', get_template_directory_uri() . '/inc/css/chosen.css' ); 

	    wp_enqueue_script( 'src-chosen', get_template_directory_uri() . '/inc/js/chosen.jquery.js', array('jquery'), false, false );
	    wp_enqueue_script( 'src-ajax-chosen', get_template_directory_uri() . '/inc/js/ajax-chosen.js', array('jquery'), false, false );

	    wp_enqueue_script( 'src-select2', get_template_directory_uri() . '/inc/js/select2/dist/js/select2.full.min.js', array('jquery'), false, false );


		wp_enqueue_script( 'repeater_script',  get_template_directory_uri() . '/inc/js/jquery.repeater.js', array('jquery'), false, false );

		wp_enqueue_script( 'ajax_customer_script',  get_template_directory_uri() . '/inc/js/ajax-customer-script.js', array('jquery'), false, false );
		wp_enqueue_script( 'ajax_lots_script',  get_template_directory_uri() . '/inc/js/ajax-lots-script.js', array('jquery'), false, false );
		wp_enqueue_script( 'ajax_stocks_script',  get_template_directory_uri() . '/inc/js/ajax-stocks-script.js', array('jquery'), false, false );


		if( isset($_GET['page']) && isset($_GET['action']) && $_GET['page'] == 'new_billing' && $_GET['action'] == 'update' ) {
			wp_enqueue_script( 'ajax_sale_logic',  get_template_directory_uri() . '/inc/js/ajax-sale-logic-script-update.js', array('jquery'), false, false );
			wp_enqueue_script( 'ajax_billing_script',  get_template_directory_uri() . '/inc/js/ajax-billing-script-update.js', array('jquery'), false, false );
		} else {
			wp_enqueue_script( 'ajax_sale_logic',  get_template_directory_uri() . '/inc/js/ajax-sale-logic-script.js', array('jquery'), false, false );
			wp_enqueue_script( 'ajax_billing_script',  get_template_directory_uri() . '/inc/js/ajax-billing-script.js', array('jquery'), false, false );
		}
		wp_enqueue_script( 'ajax_sale_extra_script',  get_template_directory_uri() . '/inc/js/ajax-sale-extra.js', array('jquery'), false, false );


		wp_enqueue_script( 'ajax_employee_script',  get_template_directory_uri() . '/inc/js/ajax-employee-script.js', array('jquery'), false, false );

		wp_enqueue_script( 'ajax_report_script',  get_template_directory_uri() . '/inc/js/ajax-report.js', array('jquery'), false, false );
	

		wp_enqueue_script( 'ajax_custom_script',  get_template_directory_uri() . '/inc/js/ajax-scripts.js', array('jquery'), false, false );
		wp_localize_script( 'ajax_custom_script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));


	}


function get_customers( $args = array() ) {
	global $wpdb;

	$customer_table = $wpdb->prefix. 'customers';
	$query = "SELECT * FROM {$customer_table}";
	$data['customers'] = $wpdb->get_results( $query );

	return $data;
}

function get_customer($customer_id = 0) {
	global $wpdb;

	$customer_table = $wpdb->prefix. 'customers';
	$query = "SELECT * FROM {$customer_table} WHERE id=".$customer_id;

	return $wpdb->get_row( $query );
}

function get_sub_customers($customer_id = 0){
	global $wpdb;

	$customer_table = $wpdb->prefix. 'customers';
	$query = "SELECT * FROM {$customer_table} WHERE active=1 and retailer_id=".$customer_id;

	return $wpdb->get_results( $query );

}


function getCourierList() {
	global $wpdb;

	$courier_table = $wpdb->prefix. 'courier_price_detail';
	$query = "SELECT * FROM {$courier_table} WHERE active=1";

	return $wpdb->get_results( $query );
}





function get_customer_create_form_popup(){
	include('ajax/get_customer_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_customer_create_form_popup', 'get_customer_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_customer_create_form_popup', 'get_customer_create_form_popup' );


function edit_customer_create_form_popup(){
	include('ajax/edit_customer_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_customer_create_form_popup', 'edit_customer_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_customer_create_form_popup', 'edit_customer_create_form_popup' );






function post_customer_create_popup() 

{
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$customer_table = $wpdb->prefix. 'customers';
	$wpdb->insert($customer_table, array(
	    'name' => esc_attr($params['customer_name']),
	    'mobile' => esc_attr($params['customer_mobile']),
	    'address' => esc_attr($params['customer_address']),
	    'type' => esc_attr($params['customer_type']),
	    'payment_type' => esc_attr($params['payment_type']),
	    'created_at' => date( 'Y-m-d H:i:s', current_time( 'timestamp' ) )
	));
	$id = $wpdb->insert_id;

	foreach ($params['customer_detail'] as $d_value) {
		$lot_detail = array(
				'retailer_id' 	=> $id,
				'name' 			=> esc_attr($d_value['name']),
			    'mobile' 		=> esc_attr($d_value['mobile']),
			    'address' 		=> esc_attr($d_value['address']),
			    'created_at' 	=> date( 'Y-m-d H:i:s', current_time( 'timestamp' ))
			);
		$wpdb->insert($customer_table, $lot_detail);
	}


	if($id) {
		include( get_template_directory().'/inc/admin/list_template/list_customers.php' );
		die();
	} else {
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}
add_action( 'wp_ajax_post_customer_create_popup', 'post_customer_create_popup' );
add_action( 'wp_ajax_nopriv_post_customer_create_popup', 'post_customer_create_popup' );

function post_customer_edit_popup(){
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$customer_table = $wpdb->prefix. 'customers';




	if ( $wpdb->update($customer_table, array(
	    'name' => esc_attr($params['customer_name']),
	    'mobile' => esc_attr($params['customer_mobile']),
	    'address' => esc_attr($params['customer_address']),
	    'type' => esc_attr($params['customer_type']),
	    'payment_type' => esc_attr($params['payment_type'])
	), array( 'id' => $params['customer_id'] ) ) ) {
		$data['roll_id'] = ( isset($params['roll_id']) && $params['roll_id'] != '') ? $params['roll_id'] : '';
		$data['success'] = 1;
		$data['id'] = $params['customer_id'];

		$content = '';
		$content .= "<td>".$params['roll_id']."</td>";
		$content .= "<td>".$params['customer_name']."</td>";
		$content .= "<td>".$params['customer_mobile']."</td>";
		$content .= "<td>".$params['customer_address']."</td>";
		$content .= "<td>".$params['customer_type']."</td>";
		$content .= "<td>".$params['payment_type']."</td>";
		$content .= "<td class='center'>";
		$content .= "<span><a class='action-icons c-edit customer_edit' title='Edit' data-roll='".$params['roll_id']."' data-id='".$params['customer_id']."'>Edit</a></span>";
		$content .= "<span><a class='action-icons c-delete user_delete' href='#' title='delete' data-id='".$params['customer_id']."' data-roll='".$params['roll_id']."'>Delete</a>";
		$content .= "</span>";
		$content .= "</td>";

		$data['content'] = $content;
	}


	$wpdb->update($customer_table, array( 'active' => 0 ), array( 'retailer_id' => $params['customer_id']  ) );


	foreach ($params['customer_detail'] as $d_value) {
		$lot_detail = array(
				'retailer_id' 	=> $params['customer_id'],
				'name' 			=> esc_attr($d_value['name']),
			    'mobile' 		=> esc_attr($d_value['mobile']),
			    'address' 		=> esc_attr($d_value['address']),
			    'created_at' 	=> date( 'Y-m-d H:i:s', current_time( 'timestamp' ))
			);
		$wpdb->insert($customer_table, $lot_detail);
	}
	

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_post_customer_edit_popup', 'post_customer_edit_popup' );
add_action( 'wp_ajax_nopriv_post_customer_edit_popup', 'post_customer_edit_popup' );






function get_employee($employee_id = 0) {
	global $wpdb;

	$employee_table = $wpdb->prefix. 'employees';
	$query = "SELECT * FROM {$employee_table} WHERE id=".$employee_id;

	return $wpdb->get_row( $query );
}



function get_employee_create_form_popup(){
	include('ajax/get_employee_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_employee_create_form_popup', 'get_employee_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_employee_create_form_popup', 'get_employee_create_form_popup' );


function post_employee_create_popup() {
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

/*	echo "<pre>";
	var_dump($params); die();*/
	$employee_table = $wpdb->prefix. 'employees';
	$wpdb->insert($employee_table, array(
	    'emp_name' 			=> esc_attr($params['employee_name']),
	    'emp_mobile' 		=> esc_attr($params['employee_mobile']),
	    'emp_address' 		=> esc_attr($params['employee_address']),
	    'emp_salary' 		=> esc_attr($params['employee_salary']),
	   	'emp_joining' 		=> esc_attr($params['employee_joining']),
	   	'emp_nextpaydate' 	=> esc_attr($params['employee_joining']),
	    'emp_created_at' 	=> date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ),
	));
	if($wpdb->insert_id) {
		include( get_template_directory().'/inc/admin/list_template/list_employee.php' );
		die();
	} else {
		$data['sds'] = $wpdb->last_query;
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}
add_action( 'wp_ajax_post_employee_create_popup', 'post_employee_create_popup' );
add_action( 'wp_ajax_nopriv_post_employee_create_popup', 'post_employee_create_popup' );

function edit_employee_create_form_popup(){
	include('ajax/edit_employee_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_employee_create_form_popup', 'edit_employee_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_employee_create_form_popup', 'edit_employee_create_form_popup' );



function post_employee_edit_popup(){
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);


	$employee_table = $wpdb->prefix. 'employees';
	if ( $wpdb->update($employee_table, array(
	    'emp_name' => esc_attr($params['employee_name']),
	    'emp_mobile' => esc_attr($params['employee_mobile']),
	    'emp_address' => esc_attr($params['employee_address']),
	    'emp_salary' => esc_attr($params['employee_salary']),
	   	'emp_joining' => esc_attr($params['employee_joining']),
	    'emp_created_at' => date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ),
	   	'emp_current_status' => $params['employee_status'],
	), array( 'id' => $params['employee_id'] ) ) ) {
		$data['roll_id'] = ( isset($params['roll_id']) && $params['roll_id'] != '') ? $params['roll_id'] : '';
		$data['success'] = 1;
		$data['id'] = $params['employee_id'];
		$work_status = ($params['employee_status'] == 1) ? 'Working' : 'Releave';



		$content = '';
		$content .= "<td>".$params['roll_id']."</td>";
		$content .= "<td>".$params['employee_no']."</td>";
		$content .= "<td>".$params['employee_name']."</td>";
		$content .= "<td>".$params['employee_mobile']."</td>";
		$content .= "<td>".$params['employee_salary']."</td>";		
		$content .= "<td>".$params['employee_address']."</td>";
		$content .= "<td>".$params['employee_joining']."</td>";
		$content .= "<td>".$work_status."</td>";
		$content .= "<td class='center'>";
		$content .= "<span><a class='action-icons c-edit employee_edit' title='Edit' data-roll='".$params['roll_id']."' data-id='".$params['employee_id']."'>Edit</a></span>";
		$content .= "<span><a class='action-icons c-delete user_delete' href='#' title='delete' data-id='".$params['employee_id']."' data-roll='".$params['roll_id']."'>Delete</a>";
		$content .= "</span>";
		$content .= "</td>";

		$data['content'] = $content;
	}
	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_post_employee_edit_popup', 'post_employee_edit_popup' );
add_action( 'wp_ajax_nopriv_post_employee_edit_popup', 'post_employee_edit_popup' );











function get_lot_create_form_popup(){
	include('ajax/get_lot_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_lot_create_form_popup', 'get_lot_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_lot_create_form_popup', 'get_lot_create_form_popup' );


function edit_lot_create_form_popup(){
	include('ajax/edit_lot_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_lot_create_form_popup', 'edit_lot_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_lot_create_form_popup', 'edit_lot_create_form_popup' );



function get_lot($lot_id = 0) { 
	global $wpdb;


	$data['lot_original_id'] = false;
	$data['lot_number'] = false;
	$data['lot_data'] = false;
	$data['original_retail'] = false;
	$data['original_wholesale'] = false;
	$data['lot_dummy_id'] = false;
	$data['dummy_lot_data'] = false;
	$data['dummy_retail'] = false;
	$data['dummy_wholesale'] = false;



	$lot_table = $wpdb->prefix. 'lots';
	$lot_detail_table = $wpdb->prefix. 'lots_detail';

	$query = "SELECT * FROM {$lot_table} where id = ".$lot_id." AND active = 1";
	
	if ($lot_data = $wpdb->get_row( $wpdb->prepare( $query ) ) ) {
		$lot_id = $lot_data->id;
		$data['lot_original_id'] = $lot_id;

		$lot_original = $lot_data->lot_number;
		$data['lot_number'] = $lot_original;

		$data['lot_data'] = $lot_data;

		$query_original_retail = "SELECT * FROM {$lot_detail_table} where lot_id = ".$lot_id." AND sale_type = 'retail' AND active = 1";
		$data['original_retail'] = $wpdb->get_results( $wpdb->prepare( $query_original_retail ) );

		$query_original_wholesale = "SELECT * FROM {$lot_detail_table} where lot_id = ".$lot_id." AND sale_type = 'wholesale' AND active = 1";
		$data['original_wholesale'] = $wpdb->get_results( $wpdb->prepare( $query_original_wholesale ) );

		$query_dummy = "SELECT * FROM {$lot_table} where parent_id = '".$lot_id."' AND active = 1";

		if ($dummy_data = $wpdb->get_row( $wpdb->prepare( $query_dummy ) ) ) {
			$dummy_lot_id = $dummy_data->id;
			$data['lot_dummy_id'] = $dummy_lot_id;
			$data['dummy_lot_data'] = $dummy_data;

			$query_dummy_retail = "SELECT * FROM {$lot_detail_table} where lot_id = ".$dummy_lot_id." AND sale_type = 'retail' AND active = 1";
			$data['dummy_retail'] = $wpdb->get_results( $wpdb->prepare( $query_dummy_retail ) );


			$query_dummy_wholesale = "SELECT * FROM {$lot_detail_table} where lot_id = ".$dummy_lot_id." AND sale_type = 'wholesale' AND active = 1";
			$data['dummy_wholesale'] = $wpdb->get_results( $wpdb->prepare( $query_dummy_wholesale ) );
		}

	}

	return $data;

}



/* Lot Create */

function lot_create_submit_popup() {

	global $wpdb;
	$data['success'] = 0;
	$data['msg'] = 'Something Went Wrong!!';

	$params = array();
	parse_str($_POST['data'], $params);

	$stock_alert = $params['stock_alert'];
	$basic_price = $params['basic_price'];

	$lot_number = $params['lot_number'];
	$dummy_lot_number = $params['dummy_slot_number'];

	$brand_name = $params['brand_name'];
	$product_name = ($params['product_name'] == 'Others') ? $params['product_name1'] : $params['product_name'];
	$weight = $params['weight'];
	
	$slab_system_original = $params['slab_system'];
	$slab_system_dummy = $params['dummy_slab_system'];

	$bag_weight = $params['bag_weight'];
	$lots_table = $wpdb->prefix. 'lots';
	$cgst = $params['cgst'];
	$gst = $params['gst'];
	if($gst == 'sgst'){
		$sgst = $params['gst_value'];
		$igst = '0.00';

	}
	else {
		$igst = $params['gst_value'];
		$sgst = '0.00';
	}
	$hsn = $params['hsn'];

	$query = "SELECT * FROM {$lots_table} WHERE ( lot_number = '".$lot_number."' OR lot_number = '".$dummy_lot_number."' ) AND active = 1";

	$result_exist = $wpdb->get_row( $query );

	if(!$result_exist) {


		$lot_original = array(
				'lot_number' => $lot_number,
				'brand_name' => $brand_name,
				'product_name' => $product_name,
				'cgst' => $cgst,
				'sgst' => $sgst,
				'igst' => $igst,
				'hsn'   =>$hsn,
				'weight' => $weight,
				'bag_weight' => $bag_weight,
				'lot_type' => 'original',
				'slab_system' => $slab_system_original,
				'parent_id' => 0,
				'stock_alert' => $stock_alert,
				'basic_price' => $basic_price
			);
		$wpdb->insert($lots_table, $lot_original);
		$lot_id = $wpdb->insert_id;



		if($lot_id) {

			$lots_detail_table = $wpdb->prefix. 'lots_detail';

			//For Slab system yes (Retail Original lot)
			if($slab_system_original == 1 && isset( $params['group_retail']) && count($params['group_retail'])>0) {
				foreach ($params['group_retail'] as $ssor_value) {
					$lot_detail = array(
							'lot_id' => $lot_id,
							'lot_number' => $lot_number,
							'weight_from' => $ssor_value['weight_from'],
							'weight_to' => $ssor_value['weight_to'],
							'price' => $ssor_value['price'],
							'lot_type' => 'original',
							'sale_type' => 'retail'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}
			}

			//For Slab system no (Retail Original lot)
			if($slab_system_original == 0 && isset( $params['weight_from_retail_no_slab']) && isset( $params['weight_to_retail_no_slab']) && isset( $params['price_retail_no_slab']) && $params['weight_from_retail_no_slab'] != '' && $params['weight_to_retail_no_slab'] != '' && $params['price_retail_no_slab'] != '' ) {
				$lot_detail = array(
						'lot_id' => $lot_id,
						'lot_number' => $lot_number,
						'weight_from' => $params['weight_from_retail_no_slab'],
						'weight_to' => $params['weight_to_retail_no_slab'],
						'price' => $params['price_retail_no_slab'],
						'lot_type' => 'original',
						'sale_type' => 'retail'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}

			//For Slab system yes (Wholesale Original lot)
			if($slab_system_original == 1 && isset( $params['group_wholesale']) && count($params['group_wholesale'])>0) {
				foreach ($params['group_wholesale'] as $ssow_value) {
					$lot_detail = array(
							'lot_id' => $lot_id,
							'lot_number' => $lot_number,
							'weight_from' => $ssow_value['weight_from'],
							'weight_to' => $ssow_value['weight_to'],
							'price' => $ssow_value['price'],
							'lot_type' => 'original',
							'sale_type' => 'wholesale'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}
			}



			//For Slab system no (Wholesale Original lot)
			if($slab_system_original == 0 && isset( $params['weight_from_wholesale_no_slab']) && isset( $params['weight_to_wholesale_no_slab']) && isset( $params['price_wholesale_no_slab'])&& $params['weight_from_wholesale_no_slab'] != '' && $params['weight_to_wholesale_no_slab'] != '' && $params['price_wholesale_no_slab'] != '' ) {
				$lot_detail = array(
						'lot_id' => $lot_id,
						'lot_number' => $lot_number,
						'weight_from' => $params['weight_from_wholesale_no_slab'],
						'weight_to' => $params['weight_to_wholesale_no_slab'],
						'price' => $params['price_wholesale_no_slab'],
						'lot_type' => 'original',
						'sale_type' => 'wholesale'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}

			if($dummy_lot_number != '' && $params['bag_weight'] == 1 ) {

				$lot_dummy = array(
					'lot_number' => $dummy_lot_number,
					'brand_name' => $brand_name,
					'product_name' => $product_name,
					'cgst' => $cgst,
					'sgst' => $sgst,
					'igst' => $igst,
					'hsn'   =>$hsn,
					'weight' => $weight,
					'bag_weight' => $bag_weight,
					'lot_type' => 'dummy',
					'slab_system' => $slab_system_dummy,
					'parent_id' => $lot_id,
					'stock_alert' => $stock_alert,
					'basic_price' => $basic_price
				);
				$wpdb->insert($lots_table, $lot_dummy);
				$dummy_lot_id = $wpdb->insert_id;



				//For Slab system yes (Retail Dummy lot)
				if($slab_system_dummy == 1 && isset( $params['group_dummy_retail']) && count($params['group_dummy_retail'])>0) {
					foreach ($params['group_dummy_retail'] as $ssdr_value) {
						$lot_detail = array(
								'lot_id' => $dummy_lot_id,
								'lot_number' => $dummy_lot_number,
								'weight_from' => $ssdr_value['weight_from'],
								'weight_to' => $ssdr_value['weight_to'],
								'price' => $ssdr_value['price'],
								'lot_type' => 'dummy',
								'sale_type' => 'retail'
							);
						$wpdb->insert($lots_detail_table, $lot_detail);
					}
				}

				//For Slab system no (Retail Dummy lot)
				if($slab_system_dummy == 0 && isset( $params['bag_weight_from_retail_no_slab']) && isset( $params['bag_weight_to_retail_no_slab']) && isset( $params['bag_weight_price_retail_no_slab'])&& $params['bag_weight_from_retail_no_slab'] != '' && $params['bag_weight_to_retail_no_slab'] != '' && $params['bag_weight_price_retail_no_slab'] != '' ) {
					$lot_detail = array(
							'lot_id' => $dummy_lot_id,
							'lot_number' => $dummy_lot_number,
							'weight_from' => $params['bag_weight_from_retail_no_slab'],
							'weight_to' => $params['bag_weight_to_retail_no_slab'],
							'price' => $params['bag_weight_price_retail_no_slab'],
							'lot_type' => 'dummy',
							'sale_type' => 'retail'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}

				//For Slab system yes (Wholesale Dummy lot)
				if($slab_system_dummy == 1 && isset( $params['group_dummy_wholesale']) && count($params['group_dummy_wholesale'])>0) {
					foreach ($params['group_dummy_wholesale'] as $ssdw_value) {
						$lot_detail = array(
								'lot_id' => $dummy_lot_id,
								'lot_number' => $dummy_lot_number,
								'weight_from' => $ssdw_value['weight_from'],
								'weight_to' => $ssdw_value['weight_to'],
								'price' => $ssdw_value['price'],
								'lot_type' => 'dummy',
								'sale_type' => 'wholesale'
							);
						$wpdb->insert($lots_detail_table, $lot_detail);
					}
				}

				//For Slab system no (Wholesale Dummy lot)
				if($slab_system_dummy == 0 && isset( $params['bag_weight_from_wholesale_no_slab']) && isset( $params['bag_weight_to_wholesale_no_slab']) && isset( $params['bag_weight_price_wholesale_no_slab'])&& $params['bag_weight_from_wholesale_no_slab'] != '' && $params['bag_weight_to_wholesale_no_slab'] != '' && $params['bag_weight_price_wholesale_no_slab'] != '' ) { 

					$lot_detail = array(
							'lot_id' => $dummy_lot_id,
							'lot_number' => $dummy_lot_number,
							'weight_from' => $params['bag_weight_from_wholesale_no_slab'],
							'weight_to' => $params['bag_weight_to_wholesale_no_slab'],
							'price' => $params['bag_weight_price_wholesale_no_slab'],
							'lot_type' => 'dummy',
							'sale_type' => 'wholesale'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}

			}

		}


	} else {
		$data['msg'] = 'Lot Number Already Exist!';
	}


	if( isset($lot_id) && $lot_id ) {
		include( get_template_directory().'/inc/admin/list_template/list_lots.php' );
		die();
	} else {
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}
}
add_action( 'wp_ajax_lot_create_submit_popup', 'lot_create_submit_popup' );
add_action( 'wp_ajax_nopriv_lot_create_submit_popup', 'lot_create_submit_popup' );





function lot_update_submit_popup() {


	global $wpdb;
	$data['success'] = 0;
	$data['msg'] = 'Something Went Wrong!!';

	$params = array();
	parse_str($_POST['data'], $params);
	$stock_alert = $params['stock_alert'];
	$basic_price = $params['basic_price'];

	$lot_number = $params['lot_number'];
	$lot_id = $params['lot_id'];

	$dummy_lot_number = $params['dummy_slot_number'];
	$dummy_lot_id = $params['dummy_lot_id'];

	$brand_name = $params['brand_name'];
	$product_name = ($params['product_name'] == 'Others') ? $params['product_name1'] : $params['product_name'];
	$weight = $params['weight'];

	$slab_system_original = $params['slab_system'];
	$slab_system_dummy = $params['dummy_slab_system'];

	$bag_weight = $params['bag_weight'];


	$cgst = $params['cgst'];
	$gst = $params['gst'];
	if($gst == 'sgst'){
		$sgst = $params['gst_value'];
		$igst = '0.00';

	}
	else {
		$igst = $params['gst_value'];
		$sgst = '0.00';
	}
	$hsn = $params['hsn'];


	$lots_table = $wpdb->prefix. 'lots';
	$lots_detail_table = $wpdb->prefix. 'lots_detail';

	$query = "SELECT * FROM {$lots_table} WHERE id = ".$lot_id." AND lot_number = '".$lot_number."' AND active = 1";
	$result_exist = $wpdb->get_row( $query );
	$dummy_query = "SELECT * FROM {$lots_table} WHERE parent_id = '".$lot_id."' AND lot_type = 'dummy' AND active = 1";
	

	if( $dummy_exist = $wpdb->get_row( $dummy_query ) ) {

		$wpdb->update($lots_table, array( 'active' => 0 ), array( 'id' => $dummy_exist->id) );

		$wpdb->update($lots_detail_table, array( 'active' => 0 ), array( 'lot_id' => $dummy_exist->id) );
	}


	if($result_exist) {
		$wpdb->update($lots_detail_table, array( 'active' => 0 ), array( 'lot_id' => $lot_id) );

		$lot_original = array(
				'brand_name' => $brand_name,
				'product_name' => $product_name,
				'cgst' => $cgst,
				'sgst' => $sgst,
				'igst' => $igst,
				'hsn' => $hsn,
				'weight' => $weight,
				'bag_weight' => $bag_weight,
				'lot_type' => 'original',
				'slab_system' => $slab_system_original,
				'parent_id' => 0,
				'stock_alert' => $stock_alert,
				'basic_price' => $basic_price
			);
		$wpdb->update($lots_table, $lot_original, array( 'id' => $lot_id) );



		//For Slab system yes (Retail Original lot)
		if($slab_system_original == 1 && isset( $params['group_retail']) && count($params['group_retail'])>0) {
			foreach ($params['group_retail'] as $ssor_value) {
				$lot_detail = array(
						'lot_id' => $lot_id,
						'lot_number' => $lot_number,
						'weight_from' => $ssor_value['weight_from'],
						'weight_to' => $ssor_value['weight_to'],
						'price' => $ssor_value['price'],
						'lot_type' => 'original',
						'sale_type' => 'retail'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}
		}

		//For Slab system no (Retail Original lot)
		if($slab_system_original == 0 && isset( $params['weight_from_retail_no_slab']) && isset( $params['weight_to_retail_no_slab']) && isset( $params['price_retail_no_slab']) && $params['weight_from_retail_no_slab'] != '' && $params['weight_to_retail_no_slab'] != '' && $params['price_retail_no_slab'] != '' ) {
			$lot_detail = array(
					'lot_id' => $lot_id,
					'lot_number' => $lot_number,
					'weight_from' => $params['weight_from_retail_no_slab'],
					'weight_to' => $params['weight_to_retail_no_slab'],
					'price' => $params['price_retail_no_slab'],
					'lot_type' => 'original',
					'sale_type' => 'retail'
				);
			$wpdb->insert($lots_detail_table, $lot_detail);
		}

		//For Slab system yes (Wholesale Original lot)
		if($slab_system_original == 1 && isset( $params['group_wholesale']) && count($params['group_wholesale'])>0) {
			foreach ($params['group_wholesale'] as $ssow_value) {
				$lot_detail = array(
						'lot_id' => $lot_id,
						'lot_number' => $lot_number,
						'weight_from' => $ssow_value['weight_from'],
						'weight_to' => $ssow_value['weight_to'],
						'price' => $ssow_value['price'],
						'lot_type' => 'original',
						'sale_type' => 'wholesale'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}
		}



		//For Slab system no (Wholesale Original lot)
		if($slab_system_original == 0 && isset( $params['weight_from_wholesale_no_slab']) && isset( $params['weight_to_wholesale_no_slab']) && isset( $params['price_wholesale_no_slab'])&& $params['weight_from_wholesale_no_slab'] != '' && $params['weight_to_wholesale_no_slab'] != '' && $params['price_wholesale_no_slab'] != '' ) {
			$lot_detail = array(
					'lot_id' => $lot_id,
					'lot_number' => $lot_number,
					'weight_from' => $params['weight_from_wholesale_no_slab'],
					'weight_to' => $params['weight_to_wholesale_no_slab'],
					'price' => $params['price_wholesale_no_slab'],
					'lot_type' => 'original',
					'sale_type' => 'wholesale'
				);
			$wpdb->insert($lots_detail_table, $lot_detail);
		}


		if($dummy_lot_number != '' && $params['bag_weight'] == 1 ) {

			$lot_dummy = array(
					'lot_number' => $dummy_lot_number,
					'brand_name' => $brand_name,
					'product_name' => $product_name,
					'cgst' => $cgst,
					'sgst' => $sgst,
					'igst' => $igst,
					'hsn' => $hsn,
					'weight' => $weight,
					'bag_weight' => $bag_weight,
					'lot_type' => 'dummy',
					'slab_system' => $slab_system_dummy,
					'parent_id' => $lot_id,
					'stock_alert' => $stock_alert,
					'basic_price' => $basic_price,
					'active' => 1,
				);
			if($dummy_exist) {
				$wpdb->update($lots_table, $lot_dummy, array('id' => $dummy_exist->id ));
				$dummy_lot_id = $dummy_exist->id;
			} else {
				$wpdb->insert($lots_table, $lot_dummy);
				$dummy_lot_id = $wpdb->insert_id;
			}



			//For Slab system yes (Retail Dummy lot)
			if($slab_system_dummy == 1 && isset( $params['group_dummy_retail']) && count($params['group_dummy_retail'])>0) {
				foreach ($params['group_dummy_retail'] as $ssdr_value) {
					$lot_detail = array(
							'lot_id' => $dummy_lot_id,
							'lot_number' => $dummy_lot_number,
							'weight_from' => $ssdr_value['weight_from'],
							'weight_to' => $ssdr_value['weight_to'],
							'price' => $ssdr_value['price'],
							'lot_type' => 'dummy',
							'sale_type' => 'retail'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}
			}

			//For Slab system no (Retail Dummy lot)
			if($slab_system_dummy == 0 && isset( $params['bag_weight_from_retail_no_slab']) && isset( $params['bag_weight_to_retail_no_slab']) && isset( $params['bag_weight_price_retail_no_slab'])&& $params['bag_weight_from_retail_no_slab'] != '' && $params['bag_weight_to_retail_no_slab'] != '' && $params['bag_weight_price_retail_no_slab'] != '' ) {
				$lot_detail = array(
						'lot_id' => $dummy_lot_id,
						'lot_number' => $dummy_lot_number,
						'weight_from' => $params['bag_weight_from_retail_no_slab'],
						'weight_to' => $params['bag_weight_to_retail_no_slab'],
						'price' => $params['bag_weight_price_retail_no_slab'],
						'lot_type' => 'dummy',
						'sale_type' => 'retail'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}

			//For Slab system yes (Wholesale Dummy lot)
			if($slab_system_dummy == 1 && isset( $params['group_dummy_wholesale']) && count($params['group_dummy_wholesale'])>0) {
				foreach ($params['group_dummy_wholesale'] as $ssdw_value) {
					$lot_detail = array(
							'lot_id' => $dummy_lot_id,
							'lot_number' => $dummy_lot_number,
							'weight_from' => $ssdw_value['weight_from'],
							'weight_to' => $ssdw_value['weight_to'],
							'price' => $ssdw_value['price'],
							'lot_type' => 'dummy',
							'sale_type' => 'wholesale'
						);
					$wpdb->insert($lots_detail_table, $lot_detail);
				}
			}

			//For Slab system no (Wholesale Dummy lot)
			if($slab_system_dummy == 0 && isset( $params['bag_weight_from_wholesale_no_slab']) && isset( $params['bag_weight_to_wholesale_no_slab']) && isset( $params['bag_weight_price_wholesale_no_slab'])&& $params['bag_weight_from_wholesale_no_slab'] != '' && $params['bag_weight_to_wholesale_no_slab'] != '' && $params['bag_weight_price_wholesale_no_slab'] != '' ) { 

				$lot_detail = array(
						'lot_id' => $dummy_lot_id,
						'lot_number' => $dummy_lot_number,
						'weight_from' => $params['bag_weight_from_wholesale_no_slab'],
						'weight_to' => $params['bag_weight_to_wholesale_no_slab'],
						'price' => $params['bag_weight_price_wholesale_no_slab'],
						'lot_type' => 'dummy',
						'sale_type' => 'wholesale'
					);
				$wpdb->insert($lots_detail_table, $lot_detail);
			}

		}

		$data['success'] = 1;
		$data['msg'] = 'Lot Updated!';

	} else {
		$data['msg'] = 'Lot Number Not Exist to Edit!';
	}
	echo json_encode($data, JSON_PRETTY_PRINT);
	die();
}
add_action( 'wp_ajax_lot_update_submit_popup', 'lot_update_submit_popup' );
add_action( 'wp_ajax_nopriv_lot_update_submit_popup', 'lot_update_submit_popup' );








function get_stock_create_form_popup(){
	include('ajax/get_stock_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_stock_create_form_popup', 'get_stock_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_stock_create_form_popup', 'get_stock_create_form_popup' );


function edit_stock_create_form_popup(){
	include('ajax/edit_stock_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_stock_create_form_popup', 'edit_stock_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_stock_create_form_popup', 'edit_stock_create_form_popup' );


function get_lot_data() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$search_term = $_POST['search_key'];

	$query = "SELECT * FROM {$lots_table} WHERE ( lot_number like '%${search_term}%' OR brand_name like '%${search_term}%' ) AND lot_type = 'original' AND active = 1";
	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_lot_data', 'get_lot_data' );
add_action( 'wp_ajax_nopriv_get_lot_data', 'get_lot_data' );


function get_lot_data_billing() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$lots_sale_detail_table = $wpdb->prefix. 'sale_detail';
	$stock_table = $wpdb->prefix. 'stock';
	$search_term = $_POST['search_key'];

/*	$query ="
	    SELECT qwe.*, SUM(st.total_weight) as stock_bal from 
	    (    
	        SELECT *,
	        case WHEN l.parent_id  = 0 Then l.id ELSE l.parent_id  END as par_id
	        FROM ${lots_table} as l WHERE lot_number like '%${search_term}%' AND active = 1
	    ) as qwe JOIN ${stock_table} as st ON st.lot_id = qwe.par_id WHERE st.active=1 GROUP BY qwe.id
	    ";
*/

	$query = "

SELECT tt1.*, (tt1.stock_total - tt1.sale_total)as stock_bal  from 
(

select *,
( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) as par_id,
( SELECT  
 ( case WHEN SUM(total_weight)  Then SUM(total_weight) ELSE 0 END ) 
 from ${stock_table} s where s.active = 1 AND s.lot_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as stock_total, 
    
( SELECT 
 ( case WHEN SUM(sale_weight)  Then SUM(sale_weight) ELSE 0 END ) 
 from ${lots_sale_detail_table} sd where sd.active = 1 AND sd.bill_type = 'original' AND sd.lot_parent_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as sale_total
from ${lots_table} as l WHERE ( lot_number LIKE '%${search_term}%' OR brand_name LIKE '%${search_term}%' ) AND active = 1 

) as tt1";

	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_lot_data_billing', 'get_lot_data_billing' );
add_action( 'wp_ajax_nopriv_get_lot_data_billing', 'get_lot_data_billing' );


function stock_create_submit_popup() {
	global $wpdb;

	$data['success'] = 0;
	$data['msg'] = 'Something went wrong! Try again';


	if( isset( $_POST['lot_id'] ) && isset( $_POST['stock_count'] )  ) {
		$lot_id = $_POST['lot_id'];
		$count = $_POST['stock_count'];

		$lot_detail = get_lot( $lot_id );

		if( isset($lot_detail['lot_data']) && $lot_detail['lot_data'] ) {
			$bag_weight = $lot_detail['lot_data']->weight;

			$stock_table = $wpdb->prefix. 'stock';
			$stock_detail = array(
					'lot_id' => $lot_id,
					'bags_count' => $count,
					'bag_weight' => $bag_weight,
					'total_weight' => ($count * $bag_weight),
					'vendor_information' => $_POST['vendor_information'],
					'invoice' => $_POST['invoice_number'],
					'invoice_date' => $_POST['invoice_date'],
					'quantity' => $_POST['quantity'],
				);

			$wpdb->insert($stock_table, $stock_detail);

			if($stock_id = $wpdb->insert_id)  {

				include( get_template_directory().'/inc/admin/list_template/list_stocks.php' );
				die();
			}
		}
	}
	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_stock_create_submit_popup', 'stock_create_submit_popup' );
add_action( 'wp_ajax_nopriv_stock_create_submit_popup', 'stock_create_submit_popup' );


function get_stock_data_by_id($stock_id = 0) {
	global $wpdb;
	$stock_table = $wpdb->prefix. 'stock';
	$lot_table = $wpdb->prefix. 'lots';

	$query = "SELECT s.*, l.lot_number, l.brand_name, l.product_name FROM ${stock_table} as s JOIN ${lot_table} as l ON s.lot_id = l.id  WHERE s.active = 1 AND l.active = 1 AND l.lot_type = 'original' AND s.id = ".$stock_id;

	return $wpdb->get_row( $query, ARRAY_A );
	die();
}

function stock_update_submit_popup($stock_id = 0) {
	$data['success'] = 0;
	$data['msg'] = 'No changes happend!';

	if(isset($_POST['stock_id']) && isset($_POST['stock_count']) && $_POST['stock_id'] != '' && $_POST['stock_count'] != ''   ) {

		
		global $wpdb;
		$stock_table = $wpdb->prefix. 'stock';
		$lot_table = $wpdb->prefix. 'lots';
		$stock_id = $_POST['stock_id'];
		$stock_count = $_POST['stock_count'];
		$vendor_information = $_POST['vendor_information'];
		$invoice = $_POST['invoice_number'];
		$invoice_date = $_POST['invoice_date'];
		$quantity = $_POST['quantity'];

	
		$query = "SELECT s.*, l.lot_number, l.brand_name, l.product_name, l.weight FROM ${stock_table} as s JOIN ${lot_table} as l ON s.lot_id = l.id  WHERE s.active = 1 AND l.active = 1 AND l.lot_type = 'original' AND s.id = ".$stock_id;

		if( $stock_detail = $wpdb->get_row($query) ) {


			$sql = "UPDATE $stock_table SET bags_count = $stock_count , total_weight = ( $stock_detail->weight * $stock_count) ,vendor_information = '$vendor_information' , invoice = '$invoice', invoice_date = '$invoice_date' , quantity = '$quantity'  WHERE id = $stock_id";


			if( $wpdb->query($sql) ) {


				$stock_detail_final = $wpdb->get_row($query);

				$data['success'] = 1;
				$data['msg'] = 'Stock Updated';
				$data['id'] = $stock_id;



				$content .= '<td>'.$stock_detail_final->id.'</td>';
				$content .= '<td>'.$stock_detail->lot_number.'</td>';
				$content .= '<td>'.$stock_detail->brand_name.'</td>';
				$content .= '<td>'.$stock_detail->product_name.'</td>';
				$content .= '<td>'.$stock_detail_final->vendor_information.'</td>';
				$content .= '<td>'.$stock_detail_final->invoice_date.'</td>';
				$content .= '<td>'.$stock_detail_final->invoice.'</td>';
				$content .= '<td>'.$stock_detail_final->bags_count.'</td>';
				$content .= '<td>'.$stock_detail_final->modified_at.'</td>';
				$content .= '<td class="center">';
				$content .= '<span>';
				$content .= '<a class="action-icons c-edit stock_edit" title="Edit" data-roll="12" data-id="'.$stock_detail_final->id.'">Edit</a>';
				$content .= '</span>';
				$content .= '<span><a class="action-icons c-delete lot_delete" href="#" title="delete" data-id="'.$stock_detail_final->id.'" data-roll="1">Delete</a></span>';
				$content .= '</td>';
				$content .= '</tr>';




				$data['content'] = $content;

			}

		}
	}


	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_stock_update_submit_popup', 'stock_update_submit_popup' );
add_action( 'wp_ajax_nopriv_stock_update_submit_popup', 'stock_update_submit_popup' );



function get_price_weight_based() {

	$data['success'] = 0;
	$data['msg'] = 'No data!';

	if(isset($_POST['lot_id']) && isset($_POST['sale_type']) && isset($_POST['total_weight']) ) {
		$lot_id = $_POST['lot_id'];
		$sale_type = $_POST['sale_type'];
		$total_weight = $_POST['total_weight'];

		global $wpdb;
		$lot_table = $wpdb->prefix. 'lots_detail';


		$query = "
( select *
from     ${lot_table}
where    weight_to >= ${total_weight} 
    AND lot_id = ${lot_id} 
    AND sale_type = '${sale_type}'
    AND active = 1
order by weight_to asc
limit 1
)
union
(
select   *
from     ${lot_table}
where    weight_to < ${total_weight}
    AND lot_id = ${lot_id} 
    AND sale_type = '${sale_type}'
    AND active = 1
order by weight_to desc
limit 1
)
order by weight_to DESC, abs(weight_to - ${total_weight}) ASC
limit 1";


		$data['price_detail'] = $wpdb->get_row($query);
		$data['success'] = 1;

	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_price_weight_based', 'get_price_weight_based' );
add_action( 'wp_ajax_nopriv_get_price_weight_based', 'get_price_weight_based' );


function get_customer_name() {

	$data['success'] = 0;
	$data['msg'] = 'Something Went Wrong!';

	global $wpdb;
	$search = $_POST['search_key'];
	$table =  $wpdb->prefix.'customers';
    $customPagHTML      = "";
    $query              = "SELECT * FROM ${table} WHERE active = 1 AND retailer_id = 0 AND ( name LIKE '%${search}%' OR mobile LIKE '${search}%')";
	
	$data['result'] = $wpdb->get_results($query);
	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_customer_name', 'get_customer_name' );
add_action( 'wp_ajax_nopriv_get_customer_name', 'get_customer_name' );



function create_bill_invoice() {
	$current_user 		= wp_get_current_user();
	$current_nice_name 	= $current_user->user_nicename;

	$data['success'] 	= 0;
	$data['msg'] 		= 'Something Went Wrong!';

	global $wpdb;
	$sale_table 		=  $wpdb->prefix.'sale';

	$bill_date  		= $_POST['bill_date'];
	$center  			= $_POST['center'];
	$customer_id  		= $_POST['customer_id'];


	$wpdb->insert($sale_table, array(
	    'customer_id'  => esc_attr($customer_id),
	    'order_shop'   => esc_attr($center),
	    'invoice_date' => esc_attr($bill_date),
	    'made_by'      => esc_attr($current_nice_name),
	    'active'       => 1
	));
	if($bill_id = $wpdb->insert_id) {

		$invoice_id = 'INV'.$bill_id;
		$wpdb->update($sale_table, array( 'invoice_id' => $invoice_id ), array( 'id' => $bill_id) );
		$data['success'] = 1;
		$data['msg'] = 'Invoice Generated!';
		$data['invoice_id'] = $invoice_id;
		$data['bill_id'] = $bill_id;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_create_bill_invoice', 'create_bill_invoice' );
add_action( 'wp_ajax_nopriv_create_bill_invoice', 'create_bill_invoice' );



function update_bill(){
	$current_user 		= wp_get_current_user();
	$current_nice_name 	= $current_user->user_nicename;
	$data['success'] = 0;
	$data['billing_no'] = 0;
	$params = array();
	parse_str($_POST['bill_data'], $params);

	foreach ($params['group_retail'] as $r_key => $r_value) {

		//Combain lot and dummy lot and skip duplicate
		if($r_value['lot_parent'] && $r_value['type_bill'] == 'original') {
			$weight = ($r_value['lot_slab'] == 1) ? $r_value['slab_yes_total'] : $r_value['slab_no_total'];
			
			if(isset($data[$r_value['lot_parent']])) {
				$data[$r_value['lot_parent']] = (float)$data[$r_value['lot_parent']] + $weight;
			} else {
				$data[$r_value['lot_parent']] = (float)$weight;
			}
		}
	}

	global $wpdb;
	$lots_table = $wpdb->prefix. 'lots';
	$stock_table = $wpdb->prefix. 'stock';
	$sales_table = $wpdb->prefix. 'sale';
	$payment_history = $wpdb->prefix. 'payment_history';
	$installment_table = $wpdb->prefix. 'payment_installment';


	$lots_sale_detail_table = $wpdb->prefix. 'sale_detail';
	$stock_not_avail = array();

	$billing_date = $params['billing_date'];
	$billing_no = $params['billing_no'];
	$shop_name = $params['shop_name'];
	if($params['billing_customer_list'] == '' ) {

		$billing_customer = $params['billing_customer'];

	}
	else {

		$billing_customer = $params['billing_customer_list'];
	}
	
	$customer_type = $params['customer_type'];
	$cgst = $params['cgst'];
	$other_gst = $params['other_gst'];
	$actual_total = $params['actual_price'];
	$discount = $params['discount'];
	$final_total = $params['final_total'];

	$sale_unit_total = $params['total_pieces_input'];
	$courier_name = $params['courier_name'];
	$courier_unit_price = $params['courier_unit_input'];
	$courier_total = $params['courier_total'];

	$payment_done = ( $params['payment_done'] && $params['payment_done'] == 'on' ) ? 1 : 0; 

	//To check and form stock availablity result
	foreach ($data as $p_key => $p_value) {

		$query = "
		SELECT tt1.*, (tt1.stock_total - tt1.sale_total)as stock_bal  from 
		(

		select *,
		( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) as par_id,
		( SELECT  
		 ( case WHEN SUM(total_weight)  Then SUM(total_weight) ELSE 0 END ) 
		 from ${stock_table} s where s.active = 1 AND s.lot_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as stock_total, 
		    
		( SELECT 
		 ( case WHEN SUM(sale_weight)  Then SUM(sale_weight) ELSE 0 END ) 
		 from ${lots_sale_detail_table} sd where sd.active = 1 AND sd.bill_type = 'original' AND sd.lot_parent_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as sale_total
		from ${lots_table} as l WHERE id = ${p_key} AND active = 1 

		) as tt1";

		$d_data = $wpdb->get_row( $query, ARRAY_A );

		if($p_value > $d_data['stock_bal']) {
			$stock_not_avail[$p_key] = 'Stock Not Avail!';
		}
	}

	foreach ($params['group_retail'] as $s_key => $s_value) {

		$brand_display = 0;
		if(isset($s_value['brand_checkbox_input'])) {
			$brand_display = 1;
		}

		if($s_value['lot_number'])
		{
			//Combain lot and dummy lot and skip duplicate
			if($s_value['lot_parent'] && $s_value['type_bill_h'] == 'original') {
				

				if($s_value['lot_slab'] == 1) {
					$weight = $s_value['slab_yes_total'];
				} else {
					$weight = $s_value['slab_no_total'];
				}


				//Original lot
				if($s_value['lot_number'] == $s_value['lot_parent']) {
					$update_sale[] = array('bill_type' => 'original', 'bill_from' => $shop_name, 'lot_type' => 'real', 'lot_id' => $s_value['lot_number'], 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => $s_value['sale_type_h'], 'sale_weight' => $weight, 'unit_price' => $s_value['unit_price_original'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
				} else { //Dummy Lot
					$update_sale[] = array('bill_type' => 'original', 'bill_from' => $shop_name, 'lot_type' => 'dummy', 'lot_id' => $s_value['lot_number'], 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => $s_value['sale_type_h'], 'sale_weight' => $weight, 'unit_price' => $s_value['unit_price_original'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
				}


			} else {
				$update_sale[] = array('bill_type' => 'duplicate', 'bill_from' => $s_value['type_bill_s'], 'lot_type' => '-', 'lot_id' => $s_value['lot_number'], 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => '-', 'sale_weight' => $s_value['lot_duplicate_total'], 'unit_price' => $s_value['unit_price_duplicate'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
			}
		}

		
	}



	if( 1 == 1 && $billing_no && $billing_no!=0 ) {

		$data['success'] = 1;
		$data['billing_no'] = $billing_no;

		//Update Sales table
		$wpdb->update($sales_table, 
			array(
			    'customer_id' 			=> $billing_customer,
			    'order_shop' 			=> $shop_name,
			    'customer_type'			=> $customer_type,
			    'sale_unit_total' 		=> $sale_unit_total,
			    'courier_name' 			=> $courier_name,
			    'courier_unit_price' 	=> $courier_unit_price,
			    'courier_total' 		=> $courier_total,
			    'sale_value' 			=> $actual_total,
			    'sale_discount_price' 	=> $discount,
			    'sale_tax' 				=> 0.00,
			    'sale_total' 			=> $final_total,
			    'invoice_date' 			=> $billing_date,
			    'payment_done' 			=> $payment_done,
			    'last_update_by' 		=> $current_nice_name,

			), array( 
				'id' 					=> $billing_no 
			) 
		);




		//Remove old sale details
		$wpdb->update($lots_sale_detail_table, 
			array(
			    'active' => 0,
			), array( 
				'sale_id' => $billing_no 
			) 
		);

		foreach ($update_sale as $a_key => $a_value) {
			$wpdb->insert($lots_sale_detail_table, $a_value);
		}



		//payment_installment details

		//Remove old payment_history details
		$wpdb->update($payment_history, 
			array(
			    'active' => 0,
			), array( 
				'sale_id' => $billing_no 
			) 
		);

		//update new payment history
		$wpdb->insert($payment_history, array('sale_id' => $billing_no , 'payment_paid' => $params['cash_total_input']) );
		$payment_history_id = $wpdb->insert_id;
		
		//Remove old payment_installment details
		$wpdb->update($installment_table, 
			array(
			    'active' => 0,
			), array( 
				'sale_id' => $billing_no 
			) 
		);

		//update new payment_installment details
		if($params['payment_cash']) {
			foreach ($params['payment_cash'] as $pay_value) {
				if($pay_value == 'cash_content') {
					foreach ($params['cash_payment'] as $cash_value) {

						$wpdb->insert( $installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'cash_payment', 'description' => $cash_value['cash_description'], 'initial_total' => $cash_value['cash'], 'fee_total' => 0.00, 'sub_total' => $cash_value['cash'] ));

					}
				}
				if($pay_value == 'card_content') {
					foreach ($params['card_payment'] as $card_value) {

						$fee =  ((1.5/100)*$card_value['card']);
						$total = $card_value['card'] + $fee;
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'card_payment', 'description' => $card_value['cash_description'], 'initial_total' => $card_value['card'], 'fee_total' => $fee, 'sub_total' => $total ));	

					}
				}
				if($pay_value == 'neft_content') {
					foreach ($params['neft_payment'] as $neft_value) {
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'neft_content', 'description' => $neft_value['neft_description'], 'initial_total' => $neft_value['neft'], 'fee_total' => 0.00, 'sub_total' => $neft_value['neft'] ));
					}
				}
				if($pay_value == 'cheque_content') {
					foreach ($params['cheque_payment'] as $cheque_value) {
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'cheque_content', 'description' => $cheque_value['cheque_description'], 'initial_total' => $cheque_value['cheque'], 'fee_total' => 0.00, 'sub_total' => $cheque_value['cheque'] ));
						
					}
				}
				if($pay_value == 'credit_content') {
					foreach ($params['cheque_payment'] as $cheque_value) {
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'credit_content', 'description' => $cheque_value['cheque_description'], 'initial_total' => $cheque_value['cheque'], 'fee_total' => 0.00, 'sub_total' => $cheque_value['cheque'] ));
						
					}
				}
			}
		}

	}

	echo json_encode($data);
	die();

}
add_action( 'wp_ajax_update_bill', 'update_bill' );
add_action( 'wp_ajax_nopriv_update_bill', 'update_bill' );







function update_bill_last(){
	$current_user 		= wp_get_current_user();
	$current_nice_name 	= $current_user->user_nicename;

	$params = array();
	parse_str($_POST['bill_data'], $params);

	$data['success'] = 0;
	$data['billing_no'] = 0;
	$payment_done = ( $params['payment_done'] && $params['payment_done'] == 'on' ) ? 1 : 0; 

	foreach ($params['group_retail'] as $r_key => $r_value) {

		//Combain lot and dummy lot and skip duplicate
		if($r_value['lot_parent'] && $r_value['type_bill'] == 'original') {
			$weight = ($r_value['lot_slab'] == 1) ? $r_value['slab_yes_total'] : $r_value['slab_no_total'];
			
			if(isset($data[$r_value['lot_parent']])) {
				$data[$r_value['lot_parent']] = (float)$data[$r_value['lot_parent']] + $weight;
			} else {
				$data[$r_value['lot_parent']] = (float)$weight;
			}
		}
	}


	global $wpdb;
	$lots_table = $wpdb->prefix. 'lots';
	$stock_table = $wpdb->prefix. 'stock';
	$sales_table = $wpdb->prefix. 'sale';
	$lots_sale_detail_table = $wpdb->prefix. 'sale_detail';
	$payment_history = $wpdb->prefix. 'payment_history';
	$installment_table = $wpdb->prefix. 'payment_installment';
	$stock_not_avail = array();

	$billing_date = $params['billing_date'];
	$billing_no = $params['billing_no'];
	$shop_name = $params['shop_name'];
	$billing_customer = $params['billing_customer'];
	$customer_type = $params['customer_type'];
	$cgst = $params['cgst'];
	$other_gst = $params['other_gst'];

	$actual_total = $params['actual_price'];
	$discount = $params['discount'];
	$final_total = $params['final_total'];

	$sale_unit_total = $params['total_pieces_input'];
	$courier_name = $params['courier_name'];
	$courier_unit_price = $params['courier_unit_input'];
	$courier_total = $params['courier_total'];

	$payment_done = ( $params['payment_done'] && $params['payment_done'] == 'on' ) ? 1 : 0; 

	//To check and form stock availablity result
	foreach ($data as $p_key => $p_value) {

		$query = "
		SELECT tt1.*, (tt1.stock_total - tt1.sale_total)as stock_bal  from 
		(

		select *,
		( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) as par_id,
		( SELECT  
		 ( case WHEN SUM(total_weight)  Then SUM(total_weight) ELSE 0 END ) 
		 from ${stock_table} s where s.active = 1 AND s.lot_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as stock_total, 
		    
		( SELECT 
		 ( case WHEN SUM(sale_weight)  Then SUM(sale_weight) ELSE 0 END ) 
		 from ${lots_sale_detail_table} sd where sd.active = 1 AND sd.bill_type = 'original' AND sd.lot_parent_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as sale_total
		from ${lots_table} as l WHERE id = ${p_key} AND active = 1 

		) as tt1";

		$d_data = $wpdb->get_row( $query, ARRAY_A );

		if($p_value > $d_data['stock_bal']) {
			$stock_not_avail[$p_key] = 'Stock Not Avail!';
		}
	}

//echo "<pre>"; var_dump($stock_not_avail);

	foreach ($params['group_retail'] as $s_key => $s_value) {

		$brand_display = 0;
		if(isset($s_value['brand_checkbox_input'])) {
			$brand_display = 1;
		}

		if( ( $s_value['lot_number'] || $s_value['lot_number2'] ) && $s_value['lot_parent']  != '' )
		{
			if(!$s_value['lot_number']) {
				$final_lot_number = $s_value['lot_number2'];
			} else {
				$final_lot_number = $s_value['lot_number'];
			}

			//Combain lot and dummy lot and skip duplicate
			if($s_value['lot_parent'] && $s_value['type_bill_h'] == 'original') {
				

				if($s_value['lot_slab'] == 1) {
					$weight = $s_value['slab_yes_total'];
				} else {
					$weight = $s_value['slab_no_total'];
				}


				//Original lot
				if( ($s_value['lot_number'] == $s_value['lot_parent']) OR ($s_value['lot_number2'] == $s_value['lot_parent']) ) {
					$update_sale[] = array('bill_type' => 'original', 'bill_from' => $shop_name, 'lot_type' => 'real', 'lot_id' => $final_lot_number, 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => $s_value['sale_type_h'], 'sale_weight' => $weight, 'unit_price' => $s_value['unit_price_original'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
				} else { //Dummy Lot
					$update_sale[] = array('bill_type' => 'original', 'bill_from' => $shop_name, 'lot_type' => 'dummy', 'lot_id' => $final_lot_number, 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => $s_value['sale_type_h'], 'sale_weight' => $weight, 'unit_price' => $s_value['unit_price_original'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
				}


			} else {
				$update_sale[] = array('bill_type' => 'duplicate', 'bill_from' => $s_value['type_bill_s'], 'lot_type' => '-', 'lot_id' => $final_lot_number, 'lot_parent_id' => $s_value['lot_parent'], 'sale_type' => '-', 'sale_weight' => $s_value['lot_duplicate_total'], 'unit_price' => $s_value['unit_price_duplicate'],'cgst' => $s_value['cgst'],'other_gst' => $s_value['other_gst'], 'sale_value' => $s_value['total_price'], 'sale_id' => $billing_no, 'made_by' => $current_nice_name, 'price_orig_hidden' => $s_value['price_orig_hidden'], 'brand_display' => $brand_display );
			}
		}
	}

	//Returned item array data
/*	foreach ($params['group_return'] as $s_key => $s_value) {
		var_dump($s_value['sale_detail_id']);
	}
die();*/



	if(1 == 1 && $billing_no && $billing_no!=0) {

		$data['success'] = 1;
		$data['billing_no'] = $billing_no;

		//Update Sales table
		$wpdb->update($sales_table, 
			array(
			    'customer_id' => $billing_customer,
			    'order_shop' => $shop_name,
			    'customer_type' => $customer_type,
			    'sale_unit_total' => $sale_unit_total,
			    'courier_name' => $courier_name,
			    'courier_unit_price' => $courier_unit_price,
			    'courier_total' => $courier_total,
			    'sale_value' => $actual_total,
			    'sale_discount_price' => $discount,
			    'sale_tax' => 0.00,
			    'sale_total' => $final_total,
			    'invoice_date' => $billing_date,
			    'payment_done' => $payment_done,
			    'last_update_by' => get_current_user_id(),

			), array( 
				'id' => $billing_no 
			) 
		);

		//Remove old sale details
		$wpdb->update($lots_sale_detail_table, 
			array(
			    'active' => 0,
			), array( 
				'sale_id' => $billing_no 
			) 
		);

		//Update return item
		if( isset($params['group_return']) && $params['group_return'] && count($params['group_return'])>0 ) {
			foreach ($params['group_return'] as $r_value) {
/*var_dump($lots_sale_detail_table);*/
				$wpdb->update($lots_sale_detail_table, 
					array(
					    'item_status' => 'return',
					    'made_by' => $current_nice_name,
					), array( 
						'id' => $r_value['sale_detail_id']
					) 
				);
			}
		}

		//Insert new sale detail
		foreach ($update_sale as $a_key => $a_value) {
			$wpdb->insert($lots_sale_detail_table, $a_value);
		}




		//payment_installment details

		//Remove old payment_history details
		$wpdb->update($payment_history, 
			array(
			    'active' => 0,
			), array( 
				'sale_id' => $billing_no 
			) 
		);

		//update new payment history
		$wpdb->insert($payment_history, array('sale_id' => $billing_no , 'payment_paid' => $params['cash_total_input']) );
		$payment_history_id = $wpdb->insert_id;
		
		//Remove old payment_installment details
		$wpdb->update($installment_table,
			array(
			    'active' => 0,
			), array(
				'sale_id' => $billing_no
			)
		);

		//update new payment_installment details
		if($params['payment_cash']) {
			foreach ($params['payment_cash'] as $pay_value) {

				if($pay_value == 'cash_content') {
					foreach ($params['cash_payment'] as $cash_value) {

						$wpdb->insert( $installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'cash_payment', 'description' => $cash_value['cash_description'], 'initial_total' => $cash_value['cash'], 'fee_total' => 0.00, 'sub_total' => $cash_value['cash'] ));
					}
				}
				if($pay_value == 'card_content') {
					foreach ($params['card_payment'] as $card_value) {

						$fee =  ((1.5/100)*$card_value['card']);
						$total = $card_value['card'] + $fee;
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'card_payment', 'description' => $card_value['cash_description'], 'initial_total' => $card_value['card'], 'fee_total' => $fee, 'sub_total' => $total ));	
					}
				}
				if($pay_value == 'neft_content') {
					foreach ($params['neft_payment'] as $neft_value) {
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'neft_content', 'description' => $neft_value['neft_description'], 'initial_total' => $neft_value['neft'], 'fee_total' => 0.00, 'sub_total' => $neft_value['neft'] ));
					}
				}
				if($pay_value == 'cheque_content') {
					foreach ($params['cheque_payment'] as $cheque_value) {
						$wpdb->insert($installment_table, array('sale_id' => $billing_no, 'payment_history_id' => $payment_history_id, 'payment_method' => 'cheque_content', 'description' => $cheque_value['cheque_description'], 'initial_total' => $cheque_value['cheque'], 'fee_total' => 0.00, 'sub_total' => $cheque_value['cheque'] ));
					}
				}
			}
		}

	}

	echo json_encode($data);
	die();

}
add_action( 'wp_ajax_update_bill_last', 'update_bill_last' );
add_action( 'wp_ajax_nopriv_update_bill_last', 'update_bill_last' );









function getBillDetail($bill_no = 0){
	$data['success'] = 0;
	global $wpdb;
	$sale_detail_table = 	$wpdb->prefix.'sale_detail';
	$sales_table = 	$wpdb->prefix.'sale';
	$stock_table = 	$wpdb->prefix.'stock';
	$customer_table = $wpdb->prefix.'customers';
	$payment_history = $wpdb->prefix.'payment_history';
	$payment_installment = $wpdb->prefix.'payment_installment';


	$bill_query              = "SELECT * FROM ${sales_table} WHERE id = '${bill_no}' OR invoice_id = '${bill_no}'";
	$data['bill_data'] = $wpdb->get_row($bill_query);

	if($data['bill_data']) {

		$data['success'] = 1;
		$customer_id = isset($data['bill_data']->customer_id) ? $data['bill_data']->customer_id : 0;
		$data['customer_data'] =  getCustomerDetail($customer_id);
		

		$bill_id = $data['bill_data']->id;
		$bill_detail_query = "SELECT *, sdo.id as sale_detail_id FROM wp_sale_detail sdo

JOIN (

SELECT tt1.*, (tt1.stock_total - tt1.sale_total) as stock_bal from ( select *, ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) as par_id, ( SELECT ( case WHEN SUM(total_weight) Then SUM(total_weight) ELSE 0 END ) from wp_stock s where s.active = 1 AND s.lot_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as stock_total, ( SELECT ( case WHEN SUM(sale_weight) Then SUM(sale_weight) ELSE 0 END ) from wp_sale_detail sd where sd.active = 1 AND sd.bill_type = 'original' AND sd.lot_parent_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as sale_total from wp_lots as l WHERE  active = 1 ) as tt1
) as lt ON lt.par_id = sdo.lot_parent_id WHERE sdo.sale_id = ${bill_id} AND sdo.lot_id = lt.id AND sdo.active=1";


	$data['bill_detail_data'] = $wpdb->get_results($bill_detail_query);
	$data['payment_history'] = $wpdb->get_row("SELECT * FROM ${payment_history} WHERE sale_id = ${bill_no} AND active = 1");


	$data['cash_payment'] = $wpdb->get_results("SELECT * FROM ${payment_installment} WHERE sale_id = ${bill_no} AND payment_method ='cash_payment' AND active = 1");
	$data['card_payment'] = $wpdb->get_results("SELECT * FROM ${payment_installment} WHERE sale_id = ${bill_no} AND payment_method ='card_payment' AND active = 1");
	$data['neft_content'] = $wpdb->get_results("SELECT * FROM ${payment_installment} WHERE sale_id = ${bill_no} AND payment_method ='neft_content' AND active = 1");
	$data['cheque_content'] = $wpdb->get_results("SELECT * FROM ${payment_installment} WHERE sale_id = ${bill_no} AND payment_method ='cheque_content' AND active = 1");
	} else {
		$data['msg'] = 'Bill Not Found';
	}
	return $data;
}

function getBillReturnDetail($bill_no = 0) {
	$data['success'] = 0;
	global $wpdb;
	$sale_detail_table = 	$wpdb->prefix.'sale_detail';
	$sales_table = 	$wpdb->prefix.'sale';
	$stock_table = 	$wpdb->prefix.'stock';
	$customer_table = $wpdb->prefix.'customers';


	$bill_query              = "SELECT * FROM ${sales_table} WHERE id = '${bill_no}' OR invoice_id = '${bill_no}'";
	$bill_data = $wpdb->get_row($bill_query);

	if($bill_data) {

		$data['success'] = 1;
		

		$bill_id = $bill_data->id;
		$bill_detail_query = "SELECT *, sdo.id as sale_detail_id FROM wp_sale_detail sdo

JOIN (

SELECT tt1.*, (tt1.stock_total - tt1.sale_total)as stock_bal from ( select *, ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) as par_id, ( SELECT ( case WHEN SUM(total_weight) Then SUM(total_weight) ELSE 0 END ) from wp_stock s where s.active = 1 AND s.lot_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as stock_total, ( SELECT ( case WHEN SUM(sale_weight) Then SUM(sale_weight) ELSE 0 END ) from wp_sale_detail sd where sd.active = 1 AND sd.bill_type = 'original' AND sd.lot_parent_id = ( case WHEN l.parent_id = 0 Then l.id ELSE l.parent_id END ) ) as sale_total from wp_lots as l WHERE  active = 1 ) as tt1
    
) as lt ON lt.par_id = sdo.lot_parent_id WHERE sdo.sale_id = ${bill_id} AND sdo.lot_id = lt.id AND sdo.item_status = 'return'";

	$data['bill_detail_data'] = $wpdb->get_results($bill_detail_query);

	} else {
		$data['msg'] = 'Bill Not Found';
	}

	return $data;
}


function getCustomerDetail($customer_id = 0) {
	global $wpdb;
	$customer_table = $wpdb->prefix.'customers';
	$customer_query = "SELECT * FROM ${customer_table} WHERE id = ${customer_id}";
	return $wpdb->get_row($customer_query);
}


function mark_attendance() {
	$data['success'] = 0;

	global $wpdb;
	$attendance_table = $wpdb->prefix.'employee_attendance';


	$date = $_POST['attendance_date'];
	$emp_id = $_POST['emp_id'];
	$attendance = $_POST['attendance'];
	$wpdb->update($attendance_table, array(
	    'active' => 0,
	), array( 'emp_id' => $emp_id, 'attendance_date' => $date ) );

	if($attendance != '-') {
		$wpdb->insert($attendance_table, array(
		    'emp_id' => esc_attr($emp_id),
		    'emp_attendance' => esc_attr($attendance),
		    'attendance_date' => esc_attr($date),
		    'active' => 1,
		));
	}

	$data['success'] = 1;
	$data['attendance'] = $attendance;

	echo json_encode($data);
	die();

}
add_action( 'wp_ajax_mark_attendance', 'mark_attendance' );
add_action( 'wp_ajax_nopriv_mark_attendance', 'mark_attendance' );

function in_out_attendance() {
	$data['success'] = 0;

	global $wpdb;
	$attendance_table = $wpdb->prefix.'employee_attendance';


	$date = $_POST['attendance_date'];
	$emp_id = $_POST['emp_id'];
	$in_time = $_POST['in_time'];
	$out_time = $_POST['out_time'];
	$next_in_time = $_POST['next_in_time'];
	$next_out_time = $_POST['next_out_time'];
	
	$wpdb->update($attendance_table, array(
	    'emp_intime' => $in_time,
	    'emp_outtime' => $out_time,
	    'emp_nextintime' => $next_in_time,
	    'emp_nextouttime' => $next_out_time,
	    'emp_attendance' => '1',

	), array( 'emp_id' => $emp_id, 'attendance_date' => $date, 'active' =>'1', ) );

	$data['success'] = 1;
	$data['attendance'] = $attendance;

	echo json_encode($data);
	die();

}
add_action( 'wp_ajax_in_out_attendance', 'in_out_attendance' );
add_action( 'wp_ajax_nopriv_in_out_attendance', 'in_out_attendance' );








function get_salary_create_form_popup(){
	include('ajax/get_salary_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_salary_create_form_popup', 'get_salary_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_salary_create_form_popup', 'get_salary_create_form_popup' );


function edit_salary_create_form_popup(){
	include('ajax/edit_salary_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_salary_create_form_popup', 'edit_salary_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_salary_create_form_popup', 'edit_salary_create_form_popup' );



function get_employee_by_id($id=0) {
	global $wpdb;
	$employee_table = $wpdb->prefix. 'employees';
	$search_term = $_POST['search_key'];

	$query = "SELECT * from ${employee_table}  WHERE id = ${id} AND active = 1";

	if( $data = $wpdb->get_row( $query, ARRAY_A ) ) {
		return $data;
	} else {
		return false;
	}

}

function get_employee_data() {
	global $wpdb;
	$data['success'] = 0;
	$employee_table = $wpdb->prefix. 'employees';
	$search_term = $_POST['search_key'];

	$query = "SELECT * from ( SELECT *, CONCAT('EMP', id) as employee_no from ${employee_table} ) e WHERE ( e.emp_name like '${search_term}%' OR e.emp_mobile like '${search_term}%' OR e.employee_no like '${search_term}%' ) AND e.active = 1";

	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_employee_data', 'get_employee_data' );
add_action( 'wp_ajax_nopriv_get_employee_data', 'get_employee_data' );




//echo convertToHoursMins(250, '%02d hours %02d minutes');


function post_salary_create_popup(){
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$salary_table 		= $wpdb->prefix. 'employee_salary';
	$employee_table 	= $wpdb->prefix. 'employees';


	$original_date = $params['salary_date'];

	$time_original = strtotime($original_date);
	$time_add      = $time_original + (3600*24); //add seconds of one day

	$new_date      = date("Y-m-d", $time_add);

	echo $new_date;




	if($params['pay_in'] == 'salary') {

		$sal_data['emp_id'] = esc_attr($params['emp_name']);
		$sal_data['sal_status'] = esc_attr($params['pay_in']);	
		$sal_data['sal_update_date'] = esc_attr($params['salary_date']);
		$sal_data['amount'] = esc_attr($params['salary_pay']);
		$sal_data['remark'] = 'sal';

		$wpdb->insert($salary_table, $sal_data);
		$wpdb->update($employee_table,array( 'emp_nextpaydate' => esc_attr($new_date)), array('id' => $params['emp_name']));

		$sal_adv_data['emp_id'] = $sal_data['emp_id'];
		$sal_adv_data['sal_status'] = 'advance';
		$sal_adv_data['sal_update_date'] = $sal_data['sal_update_date'];
		$sal_adv_data['amount'] = esc_attr($params['adv_hand']);
		$sal_adv_data['remark'] = 'adv_prv';

		$wpdb->insert($salary_table, $sal_adv_data);

		
		




		/*$in_data['from_advance'] = 0;
		if(isset($params['sal_from_adv']) && $params['sal_from_adv'] == 'on') {
			$in_data['from_advance'] = 1;
		}*/


	} else {

		$adv_data['emp_id'] = esc_attr($params['emp_name']);
		$adv_data['sal_status'] = esc_attr($params['pay_in']);	
		$adv_data['sal_update_date'] = esc_attr($params['salary_date']);
		$adv_data['amount'] = esc_attr($params['salary_advance']);	
		$adv_data['remark'] = 'adv';
		
		$wpdb->insert($salary_table, $adv_data);
		
		



		


	}

	if($wpdb->insert_id) {
		include( get_template_directory().'/inc/admin/list_template/list_salary.php' );
		die();
	} else {
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}
add_action( 'wp_ajax_post_salary_create_popup', 'post_salary_create_popup' );
add_action( 'wp_ajax_nopriv_post_salary_create_popup', 'post_salary_create_popup' );





function get_petty_cash_create_form_popup(){
	include('ajax/get_petty_cash_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_petty_cash_create_form_popup', 'get_petty_cash_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_petty_cash_create_form_popup', 'get_petty_cash_create_form_popup' );

function edit_petty_cash_create_form_popup(){
	include('ajax/edit_petty_cash_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_petty_cash_create_form_popup', 'edit_petty_cash_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_petty_cash_create_form_popup', 'edit_petty_cash_create_form_popup' );

function get_purchase_create_form_popup(){
	include('ajax/get_purchase_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_purchase_create_form_popup', 'get_purchase_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_purchase_create_form_popup', 'get_purchase_create_form_popup' );

function edit_purchase_create_form_popup(){
	include('ajax/edit_purchase_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_purchase_create_form_popup', 'edit_purchase_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_purchase_create_form_popup', 'edit_purchase_create_form_popup' );



function get_income_create_form_popup(){
	include('ajax/get_income_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_get_income_create_form_popup', 'get_income_create_form_popup' );
add_action( 'wp_ajax_nopriv_get_income_create_form_popup', 'get_income_create_form_popup' );

function edit_income_create_form_popup(){
	include('ajax/edit_income_create_form_popup.php');
	die();
}
add_action( 'wp_ajax_edit_income_create_form_popup', 'edit_income_create_form_popup' );
add_action( 'wp_ajax_nopriv_edit_income_create_form_popup', 'edit_income_create_form_popup' );





function post_petty_cash_create_popup(){
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);


	$customer_table = $wpdb->prefix. 'petty_cash';
	$wpdb->insert($customer_table, array(
	    'cash_date' => esc_attr($params['cash_date']),
	    'cash_amount' => esc_attr($params['cash_amount']),
	    'cash_description' => esc_attr($params['cash_description']),
	));
	if($wpdb->insert_id) {
		include( get_template_directory().'/inc/admin/list_template/list_petty_cash.php' );
		die();
	} else {
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}


add_action( 'wp_ajax_post_petty_cash_create_popup', 'post_petty_cash_create_popup' );
add_action( 'wp_ajax_nopriv_post_petty_cash_create_popup', 'post_petty_cash_create_popup' );

function post_purchase_create_popup(){
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);


	$customer_table = $wpdb->prefix.'purchase_table';
	$wpdb->insert($customer_table, array(
	    'cash_date' => esc_attr($params['purchase_cash_date']),
	    'cash_amount' => esc_attr($params['purchase_cash_amount']),
	    'cash_cheque' => esc_attr($params['purchase_cash_cheque']),
	));
	if($wpdb->insert_id) {
	 
		include( get_template_directory().'/inc/admin/list_template/list_purchase.php' );
		die();
	} else {
		var_dump($data);
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}


add_action( 'wp_ajax_post_purchase_create_popup', 'post_purchase_create_popup' );
add_action( 'wp_ajax_nopriv_post_purchase_create_popup', 'post_purchase_create_popup' );


function post_income_create_popup() {
	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$customer_table = $wpdb->prefix. 'income_list';
	$wpdb->insert($customer_table, array(
	    'cash_date' => esc_attr($params['cash_date']),
	    'cash_amount' => esc_attr($params['cash_amount']),
	    'cash_description' => esc_attr($params['cash_description']),
	));
	if($wpdb->insert_id) {
		include( get_template_directory().'/inc/admin/list_template/list_income.php' );
		die();
	} else {
		echo json_encode($data, JSON_PRETTY_PRINT);
		die();
	}

}
add_action( 'wp_ajax_post_income_create_popup', 'post_income_create_popup' );
add_action( 'wp_ajax_nopriv_post_income_create_popup', 'post_income_create_popup' );


function getPettyCash($id = 0) {
	global $wpdb;

	$petty_cash_table = $wpdb->prefix. 'petty_cash';
	$query = "SELECT * FROM {$petty_cash_table} WHERE id=".$id;

	return $wpdb->get_row( $query );
}

function getPurchase($id = 0) {
	global $wpdb;

	$purchase_table = $wpdb->prefix. 'purchase_table';
	$query = "SELECT * FROM {$purchase_table} WHERE id=".$id;

	return $wpdb->get_row( $query );
}


function getIncome($id = 0) {
	global $wpdb;

	$income_list_table = $wpdb->prefix. 'income_list';
	$query = "SELECT * FROM {$income_list_table} WHERE id=".$id;

	return $wpdb->get_row( $query );
}



function petty_cash_update_submit_popup($stock_id = 0) {

	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$pretty_cash_table = $wpdb->prefix. 'petty_cash';
	if( $wpdb->update($pretty_cash_table, array(
	    'cash_date' => esc_attr($params['cash_date']),
	    'cash_amount' => esc_attr($params['cash_amount']),
	    'cash_description' => esc_attr($params['cash_description']),
	), array('id' => $params['id'])) ) {




		$data['roll_id'] = ( isset($params['roll_id']) && $params['roll_id'] != '') ? $params['roll_id'] : '';
		$data['success'] = 1;
		$data['id'] = $params['id'];


		$content = '';
		$content .= '<td>'.$params['roll_id'].'</td>';
		$content .= '<td>'.date('Y-m-d', strtotime($params['cash_date'])).'</td>';
		$content .= '<td>'.$params['cash_description'].'</td>';
		$content .= '<td>'.$params['cash_amount'].'</td>';
		$content .= '<td class="center">';
		$content .= '<span>';
		$content .= '<a class="action-icons c-edit edit_petty_cash" title="Edit" data-roll="'.$params['roll_id'].'" data-id="'.$params['id'].'">Edit</a>';
		$content .= '</span>';
		$content .= '<span><a class="action-icons c-delete lot_delete" href="#" title="delete" data-id="'.$params['id'].'" data-roll="'.$params['roll_id'].'">Delete</a></span>';
		$content .= '</td>';

		$data['content'] = $content;


	}

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_petty_cash_update_submit_popup', 'petty_cash_update_submit_popup' );
add_action( 'wp_ajax_nopriv_petty_cash_update_submit_popup', 'petty_cash_update_submit_popup' );


function purchase_update_submit_popup($stock_id = 0) {

	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$pretty_cash_table = $wpdb->prefix. 'purchase_table';
	if( $wpdb->update($pretty_cash_table, array(
	    'cash_date' => esc_attr($params['purchase_cash_date']),
	    'cash_amount' => esc_attr($params['purchase_cash_amount']),
	    'cash_cheque' => esc_attr($params['purchase_cash_cheque']),
	), array('id' => $params['id'])) ) {




		$data['roll_id'] = ( isset($params['roll_id']) && $params['roll_id'] != '') ? $params['roll_id'] : '';
		$data['success'] = 1;
		$data['id'] = $params['id'];


		$content = '';
		$content .= '<td>'.$params['roll_id'].'</td>';
		$content .= '<td>'.date('Y-m-d', strtotime($params['purchase_cash_date'])).'</td>';
		$content .= '<td>'.$params['purchase_cash_cheque'].'</td>';
		$content .= '<td>'.$params['purchase_cash_amount'].'</td>';
		$content .= '<td class="center">';
		$content .= '<span>';
		$content .= '<a class="action-icons c-edit edit_purchase" title="Edit" data-roll="'.$params['roll_id'].'" data-id="'.$params['id'].'">Edit</a>';
		$content .= '</span>';
		$content .= '<span><a class="action-icons c-delete lot_delete" href="#" title="delete" data-id="'.$params['id'].'" data-roll="'.$params['roll_id'].'">Delete</a></span>';
		$content .= '</td>';

		$data['content'] = $content;


	}

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_purchase_update_submit_popup', 'purchase_update_submit_popup' );
add_action( 'wp_ajax_nopriv_purchase_update_submit_popup', 'purchase_update_submit_popup' );



function income_update_submit_popup($stock_id = 0) {

	global $wpdb;
	$data['success'] = 0;
	$params = array();
	parse_str($_POST['data'], $params);

	$pretty_cash_table = $wpdb->prefix. 'income_list';
	if( $wpdb->update($pretty_cash_table, array(
	    'cash_date' => esc_attr($params['cash_date']),
	    'cash_amount' => esc_attr($params['cash_amount']),
	    'cash_description' => esc_attr($params['cash_description']),
	), array('id' => $params['id'])) ) {




		$data['roll_id'] = ( isset($params['roll_id']) && $params['roll_id'] != '') ? $params['roll_id'] : '';
		$data['success'] = 1;
		$data['id'] = $params['id'];


		$content = '';
		$content .= '<td>'.$params['roll_id'].'</td>';
		$content .= '<td>'.date('Y-m-d', strtotime($params['cash_date'])).'</td>';
		$content .= '<td>'.$params['cash_description'].'</td>';
		$content .= '<td>'.$params['cash_amount'].'</td>';
		$content .= '<td class="center">';
		$content .= '<span>';
		$content .= '<a class="action-icons c-edit edit_petty_cash" title="Edit" data-roll="'.$params['roll_id'].'" data-id="'.$params['id'].'">Edit</a>';
		$content .= '</span>';
		$content .= '<span><a class="action-icons c-delete lot_delete" href="#" title="delete" data-id="'.$params['id'].'" data-roll="'.$params['roll_id'].'">Delete</a></span>';
		$content .= '</td>';

		$data['content'] = $content;


	}

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_income_update_submit_popup', 'income_update_submit_popup' );
add_action( 'wp_ajax_nopriv_income_update_submit_popup', 'income_update_submit_popup' );





function searchLotNumber() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$search_term = $_POST['search_key'];

	$query = "SELECT * FROM {$lots_table} WHERE lot_number like '%${search_term}%' AND active = 1";

	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_searchLotNumber', 'searchLotNumber' );
add_action( 'wp_ajax_nopriv_searchLotNumber', 'searchLotNumber' );


function searchBrandName() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$search_term = $_POST['search_key'];

	$query = "SELECT brand_name FROM {$lots_table} WHERE active = 1 AND brand_name like '%${search_term}%' GROUP BY brand_name";
	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_searchBrandName', 'searchBrandName' );
add_action( 'wp_ajax_nopriv_searchBrandName', 'searchBrandName' );

function searchStockName() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$search_term = $_POST['search_key'];

	$query = "SELECT product_name FROM {$lots_table} WHERE active = 1 AND product_name like '%${search_term}%' GROUP BY product_name";
	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_searchStockName', 'searchStockName' );
add_action( 'wp_ajax_nopriv_searchStockName', 'searchStockName' );




function stock_search_filter() {
	global $wpdb;
	$data['success'] = 0;
	$lots_table = $wpdb->prefix. 'lots';
	$sale_detail = $wpdb->prefix.'sale_detail';
	$stock_detail = $wpdb->prefix.'stock';
	$search_term = $_POST['search_key'];

    $con = false;
    $condition = '';
    if( isset($_POST['lot_id']) && $_POST['lot_id'] != '' && $_POST['lot_id']!='-') {
    	if($con == false) {
    		$condition .= "WHERE lot.id = ".$_POST['lot_id']." ";
    	} else {
    		$condition .= "AND lot.id = ".$_POST['lot_id']." ";
    	}
    	$con = true;
    }
    if( isset($_POST['brand_name']) && $_POST['brand_name']!='' && $_POST['brand_name']!='-') {
   		if($con == false) {
    		$condition .= "WHERE lot.brand_name = '".$_POST['brand_name']."' ";
    	} else {
    		$condition .= "AND lot.brand_name = '".$_POST['brand_name']."' ";
    	}
    	$con = true;
    }
    if( isset($_POST['stock_name']) && $_POST['stock_name']!='' && $_POST['stock_name']!='-') {
   		if($con == false) {
    		$condition .= "WHERE lot.product_name = '".$_POST['stock_name']."' ";
    	} else {
    		$condition .= "AND lot.product_name = '".$_POST['stock_name']."' ";
    	}
    	$con = true;
    }


	$query = "SELECT lot.*, (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  as sale_tot, (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) stock_tot,
    
    ( (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) - (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  ) as bal_stock
    
    
    FROM 
    (
        SELECT l.id, l.lot_number, l.brand_name, l.product_name,  
        (CASE 
            WHEN l.parent_id = 0 
            THEN l.id
            ELSE l.parent_id
         END ) as parent_id
        FROM ${lots_table} l WHERE l.active = 1
    ) 
    lot LEFT JOIN 
    (
        SELECT s.lot_parent_id as sale_lot_id, SUM(s.sale_weight) as sale_total FROM ${sale_detail} s WHERE s.active = 1 AND s.bill_type = 'original' AND item_status = 'open' GROUP BY s.lot_parent_id
    ) 
    sale ON lot.parent_id = sale.sale_lot_id LEFT JOIN 
    (
        SELECT s1.lot_id as stock_lot_id, SUM(s1.total_weight) as stock_total FROM ${stock_detail} s1 WHERE s1.active = 1 GROUP BY s1.lot_id    
    ) 
    stock ON lot.parent_id = stock.stock_lot_id ".$condition;

	if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
		$data['success'] = 1;
	}

	echo json_encode($data);
	die();


}
add_action( 'wp_ajax_stock_search_filter', 'stock_search_filter' );
add_action( 'wp_ajax_nopriv_stock_search_filter', 'stock_search_filter' );

/*    SELECT lot.*, (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  as stock_tot, (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) stock_tot,
    
    ( (CASE WHEN stock.stock_total THEN stock.stock_total ELSE 0 END) - (CASE WHEN sale.sale_total THEN sale.sale_total ELSE 0 END)  ) as stock_total
    
    
    FROM 
    (
        SELECT l.id, l.lot_number, l.brand_name, l.product_name,  
        (CASE 
            WHEN l.parent_id = 0 
            THEN l.id
            ELSE l.parent_id
         END ) as parent_id
        FROM wp_lots l WHERE l.active = 1
    ) 
    lot LEFT JOIN 
    (
        SELECT s.lot_parent_id as sale_lot_id, SUM(s.sale_weight) as sale_total FROM wp_sale_detail s WHERE s.active = 1 AND s.bill_type = 'original' AND item_status = 'open' GROUP BY s.lot_parent_id
    ) 
    sale ON lot.parent_id = sale.sale_lot_id LEFT JOIN 
    (
        SELECT s1.lot_id as stock_lot_id, SUM(s1.total_weight) as stock_total FROM wp_stock s1 WHERE s1.active = 1 GROUP BY s1.lot_id    
    ) 
    stock ON lot.parent_id = stock.stock_lot_id
*/


function src_delete_data() {
	global $wpdb;
	$table_post = $_POST['data_tb'];
	$data_id = $_POST['data_id'];
	$data['success'] = 1;
	$table = $wpdb->prefix.$table_post;


	$wpdb->update( 
		$table, 
		array( 
			'active' => 0,
		), 
		array( 'id' => $data_id ), 
		array( 
			'%d'
		), 
		array( '%d' ) 
	);

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();

}
add_action( 'wp_ajax_src_delete_data', 'src_delete_data' );
add_action( 'wp_ajax_nopriv_src_delete_data', 'src_delete_data' );





function lot_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_lots.php' );
	die();
}
add_action( 'wp_ajax_lot_list_filter', 'lot_list_filter' );
add_action( 'wp_ajax_nopriv_lot_list_filter', 'lot_list_filter' );

function stock_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_stocks.php' );
	die();
}
add_action( 'wp_ajax_stock_list_filter', 'stock_list_filter' );
add_action( 'wp_ajax_nopriv_stock_list_filter', 'stock_list_filter' );

function customer_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_customers.php' );
	die();
}
add_action( 'wp_ajax_customer_list_filter', 'customer_list_filter' );
add_action( 'wp_ajax_nopriv_customer_list_filter', 'customer_list_filter' );

function employee_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_employee.php' );
	die();
}
add_action( 'wp_ajax_employee_list_filter', 'employee_list_filter' );
add_action( 'wp_ajax_nopriv_employee_list_filter', 'employee_list_filter' );

function attendance_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_attendance.php' );
	die();
}
add_action( 'wp_ajax_attendance_list_filter', 'attendance_list_filter' );
add_action( 'wp_ajax_nopriv_attendance_list_filter', 'attendance_list_filter' );

function attendance_list_filter_dividual() {
	include( get_template_directory().'/inc/admin/employee/attendance_detail.php' );
	die();
}
add_action( 'wp_ajax_attendance_list_filter_dividual', 'attendance_list_filter_dividual' );
add_action( 'wp_ajax_nopriv_attendance_list_filter_dividual', 'attendance_list_filter_dividual' );


function salary_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_salary.php' );
	die();
}
add_action( 'wp_ajax_salary_list_filter', 'salary_list_filter' );
add_action( 'wp_ajax_nopriv_salary_list_filter', 'salary_list_filter' );


function bill_list_filter() {
	include( get_template_directory().'/inc/admin/billing_template/billing_list.php' );
	die();
}
add_action( 'wp_ajax_bill_list_filter', 'bill_list_filter' );
add_action( 'wp_ajax_nopriv_bill_list_filter', 'bill_list_filter' );


function petty_cash_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_petty_cash.php' );
	die();
}
add_action( 'wp_ajax_petty_cash_list_filter', 'petty_cash_list_filter' );
add_action( 'wp_ajax_nopriv_petty_cash_list_filter', 'petty_cash_list_filter' );


function purchase_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_purchase.php' );
	die();
}
add_action( 'wp_ajax_purchase_list_filter', 'purchase_list_filter' );
add_action( 'wp_ajax_nopriv_purchase_list_filter', 'purchase_list_filter' );

function income_list_filter() {
	include( get_template_directory().'/inc/admin/list_template/list_income.php' );
	die();
}
add_action( 'wp_ajax_income_list_filter', 'income_list_filter' );
add_action( 'wp_ajax_nopriv_income_list_filter', 'income_list_filter' );

function stock_report_list() {
	include( get_template_directory().'/inc/admin/report/list-template/list-stock-detail.php' );
	die();
}
add_action( 'wp_ajax_stock_report_list', 'stock_report_list' );
add_action( 'wp_ajax_nopriv_stock_report_list', 'stock_report_list' );

function stock_sale_filter_list() {
	include( get_template_directory().'/inc/admin/report/list-template/list-sale-detail.php' );
	die();
}
add_action( 'wp_ajax_stock_sale_filter_list', 'stock_sale_filter_list' );
add_action( 'wp_ajax_nopriv_stock_sale_filter_list', 'stock_sale_filter_list' );



function getBillStatus($bill_id) {
	global $wpdb;

	$sale_table = $wpdb->prefix.'sale';
	$query = "SELECT invoice_status FROM {$sale_table} WHERE id=".$bill_id;
	if($res = $wpdb->get_row( $query, OBJECT )) {
		return $res->invoice_status;
	}
	return false;
}

function update_delivery_status_create_form_popup($stock_id = 0) {

	global $wpdb;
	$bill_id = $_POST['bill_id'];
	$bill_status = getBillStatus($bill_id);

	$pending_status = '';
	$process_status = '';
	$delivered_status = '';

	if($bill_status == 'pending') {
		$pending_status = 'selected';
	}
	if($bill_status == 'process') {
		$process_status = 'selected';
	}
	if($bill_status == 'delivered') {
		$delivered_status = 'selected';
	}



	echo "<div style='margin-top: 15px;'>";
	echo "<input type='hidden' id='bill_id_hidden' value='".$bill_id."'>";
	echo "<div style='float:left;width:50%;'>Status</div>";
	echo "</div>";
	echo "<div style='float:left;width:50%;'>";
	echo "<select style='width:100%;' class='sale_status'>";
	echo "<option ".$pending_status." value='pending'>Waiting</option>";
	echo "<option ".$process_status." value='process'>Process</option>";
	echo "<option ".$delivered_status." value='delivered'>Delivered</option>";
	echo "</select>";
	echo "</div>";
	echo "<div style='clear:both;'></div>";
	echo "<div class='button_sub' style='margin-top: 10px;width:inherit;'>";
	echo "<button type='submit' id='update_sale_status' class='submit-button' style='margin-right: 0;float: right;'>Submit</button>";
	echo "</div>";
	echo "</div>";
	die();

}
add_action( 'wp_ajax_update_delivery_status_create_form_popup', 'update_delivery_status_create_form_popup' );
add_action( 'wp_ajax_nopriv_update_delivery_status_create_form_popup', 'update_delivery_status_create_form_popup' );



function update_sale_status() {

	global $wpdb;
	$sale_status = $_POST['sale_status'];
	$sale_id = $_POST['sale_id'];
	$sale_table = $wpdb->prefix. 'sale';
	$data['success'] = 0;

	if($sale_status == 'pending' || $sale_status == 'process' || $sale_status == 'delivered') {

		$wpdb->update( 
			$sale_table, 
			array( 
				'invoice_status' => strtolower($sale_status),
			), 
			array( 'id' => $sale_id ), 
			array( 
				'%s'
			), 
			array( '%d' ) 
		);


		if($sale_status == 'pending') {
			$data['invoice_status'] = '<span class="c-pending">Waiting</span>';
		}
		if($sale_status == 'process') {
			$data['invoice_status'] = '<span class="c-process">Process</span>';
		}
		if($sale_status == 'delivered') {
			$data['invoice_status'] = '<span class="c-delivered">Delivered</span>';
		}

		$data['success'] = 1;
	}

	echo json_encode($data, JSON_PRETTY_PRINT);
	die();
}
add_action( 'wp_ajax_update_sale_status', 'update_sale_status' );
add_action( 'wp_ajax_nopriv_update_sale_status', 'update_sale_status' );




function convertToHoursMins($time, $format = '%02d:%02d') {
    if ($time < 1) {
        return;
    }
    $data['hours'] = floor($time / 60);
    $data['minutes'] = ($time % 60);

    return $data;
}



function get_salery_pay_details($emp_id = 0, $pay_date = 0 ) {



	global $wpdb;
	$working_hours['hours'] = 00;
	$working_hours['minutes'] = 00;

	$data['success'] = 0;
	$employee_table 			= $wpdb->prefix.'employees';
	$employee_attendence_table 	= $wpdb->prefix.'employee_attendance';
	$employee_salary_table 		= $wpdb->prefix.'employee_salary';

	
	if( isset($_POST['employee_id'] ) && isset( $_POST['pay_date'] ) ) {
		$emp_id = ( isset($_POST['employee_id'] ) ) ? $_POST['employee_id'] : 0;
		$pay_date = ( isset($_POST['pay_date'] ) ) ? $_POST['pay_date'] : date("Y-m-d");
	} else {
		$emp_id = ( $emp_id != 0 ) ? $emp_id : 0;
		$pay_date = ( $pay_date != 0 ) ? $pay_date : date("Y-m-d");
	}


	


	//$query = "SELECT SUM( TIMESTAMPDIFF(MINUTE, time('00:00:00'), full.working_hours) ) as total_minuts FROM ( SELECT ADDTIME( TIMEDIFF(ea.emp_outtime,ea.emp_intime), TIMEDIFF(ea.emp_nextouttime,ea.emp_nextintime) ) as working_hours,   ea.emp_id, ea.attendance_date FROM wp_employee_attendance as ea WHERE ea.active = 1 and ea.emp_attendance = 1 AND ea.emp_id = 1 AND date(ea.attendance_date) >= ( SELECT date(e.emp_nextpaydate) as salary_from FROM wp_employees as e WHERE e.id = 1 ) AND date(ea.attendance_date) <= date('2017-08-31') ) as full";
	$query = "SELECT * FROM {$employee_table} as e left join ( SELECT SUM( TIMESTAMPDIFF(MINUTE, time('00:00:00'), full.working_hours) ) as total_minuts,full.emp_id FROM ( SELECT ADDTIME( TIMEDIFF(ea.emp_outtime,ea.emp_intime), TIMEDIFF(ea.emp_nextouttime,ea.emp_nextintime) ) as working_hours,   ea.emp_id, ea.attendance_date FROM {$employee_attendence_table} as ea WHERE ea.active = 1 and ea.emp_attendance = 1 AND ea.emp_id = '$emp_id' AND date(ea.attendance_date) >= ( SELECT date(e.emp_nextpaydate) as salary_from FROM wp_employees as e WHERE e.id = '$emp_id' ) AND date(ea.attendance_date) <= '$pay_date' ) as full)  as final on e.id = final.emp_id WHERE e.id ='$emp_id'";


	$minutes_data = $wpdb->get_row($query);
	$total_minuts = (isset($minutes_data->total_minuts) && $minutes_data->total_minuts ) ? $minutes_data->total_minuts : 0;
	$working_hours = convertToHoursMins( $total_minuts );

	$amount = $minutes_data->emp_salary;
	$divide_hours = ($working_hours['hours']/60);
	$divide_minutes = ($working_hours['minutes']/60);
	$salary_in_minutes = $divide_hours + $divide_minutes;
	
	$data['salary'] = ($amount/60) * $total_minuts;
	$data['workingDaysFromLastPaid'] = $working_hours['hours'].' Hours  '.$working_hours['minutes'].' Minutes';
	$data['salary_per_day'] = $amount;

	$data['success'] = 1;

	

	
	$adv_paid_query = "SELECT * FROM ( SELECT e.id as emp_id, e.emp_salary, e.emp_joining, e.emp_current_status,es.remark, ( CASE WHEN es.sal_status IS NULL THEN 'fresh' ELSE es.sal_status END ) AS sal_status, ( CASE WHEN es.sal_update_date IS NULL THEN e.emp_joining ELSE es.sal_update_date END ) AS sal_update_date, ( CASE WHEN es.amount IS NULL THEN 0.00 ELSE es.amount END ) AS amount, ( CASE WHEN es.active IS NULL THEN 1 ELSE es.active END ) AS active from ".$employee_salary_table." as es RIGHT JOIN ".$employee_table." as e ON e.id = es.emp_id WHERE e.active = 1 AND e.id= ".$emp_id." ) as tot WHERE ( tot.sal_status ='advance' OR tot.sal_status = 'fresh' ) AND tot.remark != 'adv_prv' ORDER BY tot.sal_update_date DESC ";

	$adv_pay_data = $wpdb->get_results( $adv_paid_query );



	if(count($adv_pay_data) == 1) {

		$data['adv_last_paid_amount'] = 0.00;
		$data['adv_last_paid_date'] = $adv_pay_data[0]->sal_update_date;

		if($pay_data[0]->active != 0 ) {
			$data['adv_last_paid_amount'] = $adv_pay_data[0]->amount;
		}

	} else {

		$data['adv_last_paid_amount'] = 0.00;
		foreach ($adv_pay_data as $a_key => $a_value) {

			$advdiff =  strtotime($a_value->sal_update_date) - strtotime($data['last_paid_date']);
			$advDiffDays = floor($advdiff / (60 * 60 * 24));

			$data['adv_last_paid_date'] = $a_value->emp_joining;
			if($a_value->active == 1 && $advDiffDays >= 0) {

				$data['adv'][$a_key]['adv_last_paid_amount'] = $a_value->amount;
				$data['adv'][$a_key]['adv_last_paid_date'] = $a_value->sal_update_date;

				$data['adv_last_paid_amount'] = $data['adv_last_paid_amount'] + $a_value->amount;

			}
		}
	}

	if(isset( $_POST['ajax'] ) && $_POST['ajax'] == 'ajax') {
		echo json_encode($data);
		die();
	} else {
		return $data;
	}





	// if( isset($_POST['employee_id'] ) && isset( $_POST['pay_date'] ) ) {
	// 	$emp_id = ( isset($_POST['employee_id'] ) ) ? $_POST['employee_id'] : 0;
	// 	$pay_date = ( isset($_POST['pay_date'] ) ) ? $_POST['pay_date'] : date("Y-m-d");
	// } else {
	// 	$emp_id = ( $emp_id != 0 ) ? $emp_id : 0;
	// 	$pay_date = ( $pay_date != 0 ) ? $pay_date : date("Y-m-d");
	// }



// 	//Payment Salary

	//$paid_query = "SELECT * FROM ( SELECT e.id as emp_id, e.emp_salary, e.emp_joining, e.emp_current_status, ( CASE WHEN es.sal_status IS NULL THEN 'fresh' ELSE es.sal_status END ) AS sal_status, ( CASE WHEN es.sal_update_date IS NULL THEN e.emp_joining ELSE es.sal_update_date END ) AS sal_update_date, ( CASE WHEN es.amount IS NULL THEN 0.00 ELSE es.amount END ) AS amount, ( CASE WHEN es.active IS NULL THEN 1 ELSE es.active END ) AS active from ".$employee_salary_table." as es RIGHT JOIN ".$employee_table." as e ON e.id = es.emp_id WHERE e.active = 1 AND e.id= ".$emp_id." ) as tot WHERE ( tot.sal_status ='salary' OR tot.sal_status = 'fresh' ) ORDER BY tot.sal_update_date DESC ";

// 	// var_dump($paid_query);
// 	$pay_data = $wpdb->get_results( $paid_query );

// 	if(count($pay_data) == 1) {

// 		$data['last_paid_amount'] = 0.00;
// 		$data['salary_per_day'] = $pay_data[0]->emp_salary;
// 		$data['last_paid_date'] = $pay_data[0]->sal_update_date;

// 		if($pay_data[0]->active != 0 ) {
// 			$data['last_paid_amount'] = $pay_data[0]->amount;
// 		}

// 	} else {

// 		$data['last_paid_amount'] = 0.00;
// 		foreach ($pay_data as $p_value) {

// 			$data['salary_per_day'] = $p_value->emp_salary;
// 			$data['last_paid_date'] = $p_value->emp_joining;

// 			if($p_value->active == 1) {

// 				$data['last_paid_amount'] = $p_value->amount;
// 				$data['salary_per_day'] = $p_value->emp_salary;
// 				$data['last_paid_date'] = $p_value->sal_update_date;

// 				break;
// 			}
// 		}
// 	}


// 	//Payment Advance




// 	$datediff = strtotime($pay_date) - strtotime($data['last_paid_date']);


// 	$data['workingDaysFromLastPaid'] = floor($datediff / (60 * 60 * 24));
// 	$data['working_salary'] = $data['workingDaysFromLastPaid'] * $data['salary_per_day'];

// 	$data['success'] = 1;

// 	if(isset( $_POST['ajax'] ) && $_POST['ajax'] == 'ajax') {
// 		echo json_encode($data);
// 		die();
// 	} else {
// 		return $data;
// 	}



}
add_action( 'wp_ajax_get_salery_pay_details', 'get_salery_pay_details' );
add_action( 'wp_ajax_nopriv_get_salery_pay_details', 'get_salery_pay_details' );

//select SEC_TO_TIME(SUM(working_hours)) AS totaltiming from ( SELECT *,TIMEDIFF(`emp_outtime`,`emp_intime`) as working_hours FROM `wp_employee_attendance` WHERE `emp_id`=1 and `active`=1 and `emp_attendance`=1 ) as wrking_timing




function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}

function getToken()
{	
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    $max = strlen($codeAlphabet); // edited

    for ($i=0; $i < 50; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }

    return $token;
}


function get_customer_list() {


	global $wpdb;
	$id = $_POST['id'];
	$table =  $wpdb->prefix.'customers';
    $query              = "SELECT * FROM ${table} WHERE active = 1 AND retailer_id = '$id'";
	
	$data['result'] = $wpdb->get_results($query);
	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_get_customer_list', 'get_customer_list' );
add_action( 'wp_ajax_nopriv_get_customer_list', 'get_customer_list' );