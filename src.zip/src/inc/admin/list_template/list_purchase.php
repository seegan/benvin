<?php

 	/*Updated for filter 11/10/16*/
	if(isset($_POST['action']) && $_POST['action'] == 'purchase_list_filter') {
		$cpage = 1;
		$ppage = $_POST['per_page'];
		$purchase_entry_amount = $_POST['purchase_entry_amount'];
		$purchase_entry_cheque = $_POST['purchase_entry_cheque'];
		$purchase_entry_date_from = $_POST['purchase_entry_date_from'];
		$purchase_entry_date_to = $_POST['purchase_entry_date_to'];
	} else {
		$cpage = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
		$ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
		$purchase_entry_amount = isset( $_GET['purchase_entry_amount'] ) ? $_GET['purchase_entry_amount']  : '';
		$purchase_entry_cheque = isset( $_GET['purchase_entry_cheque'] ) ? $_GET['purchase_entry_cheque']  : '';
		$purchase_entry_date_from = isset( $_GET['purchase_entry_date_from'] ) ? $_GET['purchase_entry_date_from']  : '';
		$purchase_entry_date_to = isset( $_GET['purchase_entry_date_to'] ) ? $_GET['purchase_entry_date_to']  : '';
	}

	$amount_data = explode("-",$purchase_entry_amount);
	$price = isset($amount_data[0]) ? trim($amount_data[0]) : '';
	$price_to = isset($amount_data[1]) ? trim($amount_data[1]) : '';

    $con = false;
    $condition = '';


    if($price != '' && $price_to == '') {
   		if($con == false) {
    		$condition .= " AND cash_amount	 = ".$price." ";
    	} else {
    		$condition .= " AND cash_amount	 = ".$price." ";
    	}
    	$con = true;
    }

    if($price != '' && $price_to != '') {
   		if($con == false) {
    		$condition .= " AND ( cash_amount	 >= ".$price." AND cash_amount	 <= ".$price_to.") ";
    	} else {
    		$condition .= " AND ( cash_amount	 >= ".$price." AND cash_amount	 <= ".$price_to.") ";
    	}
    	$con = true;
    }


    if($purchase_entry_cheque != '') {
   		if($con == false) {
    		$condition .= " AND cash_cheque LIKE '".$purchase_entry_cheque."%' ";
    	} else {
    		$condition .= " AND cash_cheque LIKE '".$purchase_entry_cheque."%' ";
    	}
    	$con = true;
    }

    if($purchase_entry_date_from != '' && $purchase_entry_date_to == '') {
   		if($con == false) {
    		$condition .= " AND DATE(cash_date) >= '".$purchase_entry_date_from."' ";
    	} else {
    		$condition .= " AND DATE(cash_date) >= '".$purchase_entry_date_from."' ";
    	}
    	$con = true;
    }
    if($purchase_entry_date_from == '' && $purchase_entry_date_to != '') {
   		if($con == false) {
    		$condition .= " AND DATE(cash_date) <= '".$purchase_entry_date_to."' ";
    	} else {
    		$condition .= " AND DATE(cash_date) <= '".$purchase_entry_date_to."' ";
    	}
    	$con = true;
    }
    if($purchase_entry_date_from != '' && $purchase_entry_date_to != '') {
   		if($con == false) {
    		$condition .= " AND ( DATE(cash_date) >= '".$purchase_entry_date_from."' AND DATE(cash_date) <= '".$purchase_entry_date_to."' ) ";
    	} else {
    		$condition .= " AND ( DATE(cash_date) >= '".$purchase_entry_date_from."' AND DATE(cash_date) <= '".$purchase_entry_date_to."' ) ";
    	}
    	$con = true;
    }
    /*End Updated for filter 11/10/16*/



	$result_args = array(
		'orderby_field' => 'id',
		'page' => $cpage ,
		'order_by' => 'DESC',
		'items_per_page' => $ppage,
		'condition' => $condition,
	);

	$purchase = purchase_list_pagination($result_args);

?>
	<table class="display">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Date</th>
				<th>Cheque Number</th>
				<th>Amount</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
		<?php
			if( count($purchase['result'])>0 ) {
				$start_count = $purchase['start_count'];
				foreach ($purchase['result'] as $purchase_value) {
					$start_count++;

		?>
			<tr id="employee-data-<?php echo $purchase_value->id; ?>">
				<td><?php echo $start_count; ?></td>
				<td><?php echo date('Y-m-d', strtotime($purchase_value->cash_date)); ?></td>
				<td><?php echo $purchase_value->cash_cheque; ?></td>
				<td><?php echo $purchase_value->cash_amount; ?></td>
				<td class="center">
					<span>
						<a class="action-icons c-edit edit_purchase" title="Edit" data-roll="<?php echo $start_count; ?>" data-id="<?php echo $purchase_value->id; ?>">Edit</a>
					</span>
					<span>
						<a class="action-icons c-delete lot_delete" href="#" data-action="purchase" title="delete" data-roll="<?php echo $start_count; ?>" data-id="<?php echo $purchase_value->id; ?>" data-roll="1">Delete</a>
					</span>
				</td>
			</tr>
		<?php
				}
			}
		?>
		</tbody>
	</table>

	<?php echo $purchase['pagination']; ?>