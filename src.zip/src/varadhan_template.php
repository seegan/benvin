<?php
/**
 * Template Name: Varadhan Template
 *
 * This is the template that displays full width page without sidebar
 *
 * 
 */

/**
 * XLS parsing uses php-excel-reader from http://code.google.com/p/php-excel-reader/
 */

    global $wpdb;
    $invoice_table              = $wpdb->prefix.'vardhanroyalenfield_insurance';
    header('Content-Type: text/plain');

    // if (isset($argv[1]))
    // {
    //     $Filepath = $argv[1];
    // }
    // elseif (isset($_GET['File']))
    // {
    //     $Filepath = $_GET['File'];
    // }
    // else
    // {
    //     if (php_sapi_name() == 'cli')
    //     {
    //         echo 'Please specify filename as the first argument'.PHP_EOL;
    //     }
    //     else
    //     {
    //         echo 'Please specify filename as a HTTP GET parameter "File", e.g., "varadhan-template/?File=test.xlsx"';
    //     }
    //     exit;
    // }
    $Filepath = get_template_directory().'/POLICY.xlsx';
    // Excel reader from http://code.google.com/p/php-excel-reader/
    require get_template_directory().'/spreadsheet-reader/php-excel-reader/excel_reader2.php';
    require get_template_directory().'/spreadsheet-reader/SpreadsheetReader.php';

    date_default_timezone_set('UTC');

    $StartMem = memory_get_usage();
    echo '---------------------------------'.PHP_EOL;
    echo 'Starting memory: '.$StartMem.PHP_EOL;
    echo '---------------------------------'.PHP_EOL;

    try
    {
        $Spreadsheet = new SpreadsheetReader($Filepath);
        $BaseMem = memory_get_usage();

        $Sheets = $Spreadsheet -> Sheets();

        echo '---------------------------------'.PHP_EOL;
        echo 'Spreadsheets:'.PHP_EOL;
        print_r($Sheets);
        echo '---------------------------------'.PHP_EOL;
        echo '---------------------------------'.PHP_EOL;

        foreach ($Sheets as $Index => $Name)
        {
            echo '---------------------------------'.PHP_EOL;
            echo '*** Sheet '.$Name.' ***'.PHP_EOL;
            echo '---------------------------------'.PHP_EOL;

            $Time = microtime(true);

            $Spreadsheet -> ChangeSheet($Index);

            foreach ($Spreadsheet as $Key => $Row)
            {
                echo $Key.': ';
                if ($Row)
                {
                    print_r($Row);

                    $f_date =  $Row['6'];
                    $from_date = date('Y/m/d', strtotime($f_date));

                    $t_date =$Row['7'];
                    $to_date = date('Y/m/d', strtotime($t_date));
                   
                    $invoice_data                           = array(
                    'reg_no'                                => $Row['1'],
                    'party_name'                            => $Row['2'],               
                    'party_mobile_no'                       => $Row['3'],                          
                    'party_email'                           => $Row['4'],                           
                    'bike_model'                            => $Row['5'],                           
                    'date_from'                             => $from_date,
                    'date_to'                               => $to_date,
                    'alert_before_days'                     => $Row['8'],
                    'active'                                => $Row['9'],
                    'pol_no'                                => $Row['10'],
                    'bank_name'                             => $Row['11'],
                    'premium_years'                         => $Row['12'],
                    'payment_type'                          => $Row['13'],
                    'followup_status'                       => $Row['14'],
                    'followed_by'                           => $Row['15'], 
                );

                    $wpdb->insert($invoice_table, $invoice_data);
                }
               
                $CurrentMem = memory_get_usage();
        
            }
        }
        
    }
    catch (Exception $E)
    {
        echo $E -> getMessage();
    }
?>