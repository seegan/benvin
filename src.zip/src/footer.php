    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo get_template_directory_uri(); ?>/incjs/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/inc/js/jquery.bxslider.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/inc/js/script.js"></script>


</body>

</html>