<?php return array (
  'sans-serif' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Helvetica',
    'bold' => DOMPDF_DIR . '/lib/fonts/Helvetica-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Helvetica-Oblique',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Helvetica-BoldOblique',
  ),
  'times' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Times-Roman',
    'bold' => DOMPDF_DIR . '/lib/fonts/Times-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Times-Italic',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Times-BoldItalic',
  ),
  'times-roman' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Times-Roman',
    'bold' => DOMPDF_DIR . '/lib/fonts/Times-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Times-Italic',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Times-BoldItalic',
  ),
  'courier' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Courier',
    'bold' => DOMPDF_DIR . '/lib/fonts/Courier-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Courier-Oblique',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Courier-BoldOblique',
  ),
  'helvetica' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Helvetica',
    'bold' => DOMPDF_DIR . '/lib/fonts/Helvetica-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Helvetica-Oblique',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Helvetica-BoldOblique',
  ),
  'symbol' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Symbol',
    'bold' => DOMPDF_DIR . '/lib/fonts/Symbol',
    'italic' => DOMPDF_DIR . '/lib/fonts/Symbol',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Symbol',
  ),
  'serif' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Times-Roman',
    'bold' => DOMPDF_DIR . '/lib/fonts/Times-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Times-Italic',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Times-BoldItalic',
  ),
  'monospace' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Courier',
    'bold' => DOMPDF_DIR . '/lib/fonts/Courier-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Courier-Oblique',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Courier-BoldOblique',
  ),
  'fixed' => 
  array (
    'normal' => DOMPDF_DIR . '/lib/fonts/Courier',
    'bold' => DOMPDF_DIR . '/lib/fonts/Courier-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/Courier-Oblique',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/Courier-BoldOblique',
  ),
) ?>