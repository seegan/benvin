<?php
/**
 * Template Name: SRC Invoice Download
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
$invoice_id = isset($_GET['invoice_id']) ? $_GET['invoice_id'] : 0;
$url = site_url( 'invoice/?id=' ).$invoice_id.'&download';
$content =   file_get_contents($url,0,null,null);
invoiceDownload($content, 'sampl.pdf');
?>