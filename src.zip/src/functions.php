<?php

add_action( 'admin_bar_menu', 'remove_wp_logo', 999 );

function remove_wp_logo( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
}

require get_template_directory() . '/inc/admin/functions.php';
require get_template_directory() . '/inc/admin/menu-functions.php';
require get_template_directory() . '/inc/admin/pagination-functions.php';

require get_template_directory() . '/inc/admin/admin-dashboard.php';
require get_template_directory() . '/inc/admin/report-functions.php';

/*$lot_details = get_lot(1);
echo "<pre>";
var_dump($lot_details);

die();*/
//Assign capabilities global
function src_global_var() {
    global $src_capabilities;

	$src_capabilities = array( 
		'dashboard' => 'Dashboard', 
		'customers' => 'Customers',  
		'stocks' => array(
			'name' => 'Stocks',
			'data' => array(
				'lot_list' => 'Lot(s) List',
				'stock_list' => 'Stock List', 
			),
		),
		'sales_others' => array(
			'name' => 'Sales & Others',
			'data' => array(
				'purchase_sales' => 'Purchase & Sales', 
				'petty_cash' => 'Petty Cash', 
				'income_list' => 'Income List', 
			),
		),
		'employee' => array(
			'name' => 'Employee',
			'data' => array(
				'add_new_employee' => 'Add New Employee', 
				'employee_list' => 'Employee\'s List', 
				'attendance_list' => 'Attendance List', 
				'salary_list' => 'Salary List', 
			),
		),
		'admin_users' => array(
			'name' => 'Admin Users',
			'data' => array(
				'add_new_user' => 'Add New User', 
				'user_list' => 'User\'s List', 
			),

		),
		'sms_alert' => array(
			'name' => 'SMS Alert',
			'data' => array(
				'sms_to_customer' => 'SMS to Customer', 
				'sms_to_user' => 'SMS to User', 
			),
		),
		'reports' => 'Reports', 
		'settings' => 'Settings'
	);



	global $src_premissions;

	$src_premissions = array(
			'dashboard' => (is_super_admin()) ? 'manage_options' : 'dashboard',
			'customers' => (is_super_admin()) ? 'manage_options' : 'customers',
			'lot_list' => (is_super_admin()) ? 'manage_options' : 'lot_list',
			'stock_list' => (is_super_admin()) ? 'manage_options' : 'stock_list',
			'purchase_sales' => (is_super_admin()) ? 'manage_options' : 'purchase_sales',
			'petty_cash' => (is_super_admin()) ? 'manage_options' : 'petty_cash',
			'income_list' => (is_super_admin()) ? 'manage_options' : 'income_list',
			'purchase' => (is_super_admin()) ? 'manage_options' : 'purchase',
			'add_new_employee' => (is_super_admin()) ? 'manage_options' : 'add_new_employee',
			'employee_list' => (is_super_admin()) ? 'manage_options' : 'employee_list',
			'attendance_list' => (is_super_admin()) ? 'manage_options' : 'attendance_list',
			'salary_list' => (is_super_admin()) ? 'manage_options' : 'salary_list',
			'add_new_user' => (is_super_admin()) ? 'manage_options' : 'add_new_user',
			'user_list' => (is_super_admin()) ? 'manage_options' : 'user_list',
			'sms_to_customer' => (is_super_admin()) ? 'manage_options' : 'sms_to_customer',
			'sms_to_user' => (is_super_admin()) ? 'manage_options' : 'sms_to_user',
			'reports' => (is_super_admin()) ? 'manage_options' : 'reports',
			'settings' => (is_super_admin()) ? 'manage_options' : 'settings',
		);


}
add_action( 'init', 'src_global_var' );


//create role capabilities
function custom_role_administrator() {
	global $src_capabilities;
	$admin_role = get_role( 'administrator' );

	$data = '';
	foreach ($src_capabilities as $key => $c_value) {
		if( is_array($c_value) ) {
			foreach ($c_value['data'] as $key_val => $name_value) {
				$data[] =  $key_val;
			}
		} else {
			$data[] = $key;
		}
	}
	foreach( $data as $cap ) {
	        $admin_role->add_cap( $cap );
	}

	if(!get_role('customer')) {
		add_role( 'customer', 'Customer', array( 'read' => true, 'level_0' => true ) );
	}
	if(!get_role('employee')) {
	    add_role( 'employee', 'Employee', array( 'read' => true, 'level_0' => true ) );
	}
}
add_action('switch_theme', 'custom_role_administrator');












//invoiceDownload('dfdfd', 'test.pdf');

function invoiceDownload($str='', $outfile = '')
{

	$paper = DOMPDF_DEFAULT_PAPER_SIZE;
	require_once("wp-pdf-templates/dompdf/dompdf_config.inc.php"); 
	$dompdf = new DOMPDF();

	global $_dompdf_show_warnings, $_dompdf_debug, $_DOMPDF_DEBUG_TYPES;

	$options = array();

	$orientation = "portrait";
	$save_file = false; # Don't save the file


	$dompdf->load_html($str);
	$dompdf->set_paper($paper, $orientation);
	$dompdf->render();

	if ( $_dompdf_show_warnings ) {
		global $_dompdf_warnings;
		foreach ($_dompdf_warnings as $msg)
		echo $msg . "\n";
		echo $dompdf->get_canvas()->get_cpdf()->messages;
		flush();
	}


	if ( !headers_sent() ) {
	$dompdf->stream($outfile, $options);
	}

}